import React, { useState, useMemo } from 'react';
import {
  FileText,
  Plus,
  Search,
  Sparkles,
  Copy,
  Check,
  Send,
  Edit,
  Trash2,
  RotateCcw,
  School,
  Building2,
  Tag,
  Clock,
  ExternalLink,
  MessageSquare,
  Wand2,
  AlertCircle,
  Eye,
  CheckCircle2,
  Share2,
} from 'lucide-react';
import { MessageTemplate, AgencyProfile, Lead } from '../types';
import { initialMessageTemplates } from '../utils/defaultData';

interface TemplatesManagerProps {
  templates: MessageTemplate[];
  onSaveTemplate: (template: MessageTemplate) => void;
  onDeleteTemplate: (templateId: string) => void;
  onResetDefaultTemplates: () => void;
  onUseTemplateInCampaign: (content: string) => void;
  agencyProfile: AgencyProfile;
  leads: Lead[];
}

export const TemplatesManager: React.FC<TemplatesManagerProps> = ({
  templates,
  onSaveTemplate,
  onDeleteTemplate,
  onResetDefaultTemplates,
  onUseTemplateInCampaign,
  agencyProfile,
  leads,
}) => {
  // State
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [copiedTemplateId, setCopiedTemplateId] = useState<string | null>(null);

  // Editor Modal State
  const [isEditorOpen, setIsEditorOpen] = useState(false);
  const [editingTemplate, setEditingTemplate] = useState<MessageTemplate | null>(null);
  const [formTitle, setFormTitle] = useState('');
  const [formCategory, setFormCategory] = useState<MessageTemplate['category']>('schools');
  const [formCategoryLabel, setFormCategoryLabel] = useState('المدارس الأهلية والدولية');
  const [formContent, setFormContent] = useState('');
  const [formTags, setFormTags] = useState('');

  // AI Refinement in Editor
  const [isRefiningWithAi, setIsRefiningWithAi] = useState(false);
  const [aiTone, setAiTone] = useState<'persuasive' | 'executive' | 'friendly' | 'concise'>('persuasive');
  const [aiInstruction, setAiInstruction] = useState('');
  const [aiError, setAiError] = useState<string | null>(null);

  // Live Preview Target Lead
  const [selectedPreviewLeadId, setSelectedPreviewLeadId] = useState<string>('sample');

  // Available dynamic variables
  const dynamicVariables = [
    { tag: '{اسم_الجهة}', label: 'اسم المدرسة أو الشركة', example: 'مدارس الرياض الأهلية' },
    { tag: '{المدينة}', label: 'المدينة المستهدفة', example: 'الرياض' },
    { tag: '{الدولة}', label: 'الدولة', example: 'المملكة العربية السعودية' },
    { tag: '{النوع}', label: 'التصنيف أو النشاط', example: 'مدرسة أهلية' },
    { tag: '{اسم_الوكالة}', label: 'اسم وكالتنا', example: agencyProfile.agencyName || 'وكالتنا للحلول الرقمية' },
    { tag: '{رقم_الواتس}', label: 'رقم الواتساب الرسمي', example: agencyProfile.myWhatsapp || '00667737219181' },
    { tag: '{البريد_الإلكتروني}', label: 'البريد الرسمي', example: agencyProfile.myEmail || 'info@agency.com' },
  ];

  // Current lead used for live preview
  const currentPreviewLead = useMemo(() => {
    if (selectedPreviewLeadId === 'sample' || !leads.length) {
      return {
        name: 'مدارس الرياض النموذجية الأهلية',
        city: 'الرياض',
        country: 'المملكة العربية السعودية',
        categoryLabel: 'مدرسة أهلية',
      };
    }
    const found = leads.find((l) => l.id === selectedPreviewLeadId);
    if (found) {
      return {
        name: found.name,
        city: found.city,
        country: found.country,
        categoryLabel: found.categoryLabel || (found.category === 'school' ? 'مدرسة أهلية' : 'شركة عالمية'),
      };
    }
    return {
      name: 'مجموعة الفطيم للحلول العالمية',
      city: 'دبي',
      country: 'الإمارات العربية المتحدة',
      categoryLabel: 'شركة عالمية',
    };
  }, [selectedPreviewLeadId, leads]);

  // Helper to replace variables in preview
  const getRenderedContent = (rawText: string) => {
    return rawText
      .replace(/{اسم_الجهة}/g, currentPreviewLead.name)
      .replace(/{المدينة}/g, currentPreviewLead.city)
      .replace(/{الدولة}/g, currentPreviewLead.country)
      .replace(/{النوع}/g, currentPreviewLead.categoryLabel)
      .replace(/{اسم_الوكالة}/g, agencyProfile.agencyName || 'وكالتنا للحلول الرقمية')
      .replace(/{رقم_الواتس}/g, agencyProfile.myWhatsapp || '00667737219181')
      .replace(/{البريد_الإلكتروني}/g, agencyProfile.myEmail || 'info@agency.com');
  };

  // Categories config
  const categoryFilters = [
    { id: 'all', label: 'كافة القوالب', count: templates.length },
    { id: 'schools', label: 'المدارس والتعليم', count: templates.filter((t) => t.category === 'schools').length },
    { id: 'companies', label: 'الشركات والمؤسسات', count: templates.filter((t) => t.category === 'companies').length },
    { id: 'offers', label: 'عروض وباقات ترويجية', count: templates.filter((t) => t.category === 'offers').length },
    { id: 'followup', label: 'المتابعة والتنشيط', count: templates.filter((t) => t.category === 'followup').length },
    { id: 'direct_meeting', label: 'دعوات الاجتماعات', count: templates.filter((t) => t.category === 'direct_meeting').length },
    { id: 'custom', label: 'قوالبي المخصصة', count: templates.filter((t) => !t.isDefault).length },
  ];

  // Filtered templates list
  const filteredTemplates = useMemo(() => {
    return templates.filter((tpl) => {
      // Category filter
      if (activeCategory === 'custom') {
        if (tpl.isDefault) return false;
      } else if (activeCategory !== 'all' && tpl.category !== activeCategory) {
        return false;
      }

      // Search query filter
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchesTitle = tpl.title.toLowerCase().includes(q);
        const matchesContent = tpl.content.toLowerCase().includes(q);
        const matchesCategory = tpl.categoryLabel.toLowerCase().includes(q);
        const matchesTags = tpl.tags?.some((tag) => tag.toLowerCase().includes(q));
        if (!matchesTitle && !matchesContent && !matchesCategory && !matchesTags) {
          return false;
        }
      }

      return true;
    });
  }, [templates, activeCategory, searchQuery]);

  // Open editor for new template
  const handleOpenNewEditor = () => {
    setEditingTemplate(null);
    setFormTitle('');
    setFormCategory('schools');
    setFormCategoryLabel('المدارس الأهلية والدولية');
    setFormContent(
      `السلام عليكم ورحمة الله وبركاته،\nتحية طيبة لإدارة {اسم_الجهة} الموقرة في {المدينة}،\nيسعدنا في {اسم_الوكالة} أن نعرض عليكم خدماتنا المخصصة لـ {النوع}...\nللتواصل المباشر عبر الواتساب: {رقم_الواتس}`
    );
    setFormTags('إعلان, تسويق, واتساب');
    setAiError(null);
    setIsEditorOpen(true);
  };

  // Open editor for existing template
  const handleOpenEdit = (tpl: MessageTemplate) => {
    setEditingTemplate(tpl);
    setFormTitle(tpl.title);
    setFormCategory(tpl.category);
    setFormCategoryLabel(tpl.categoryLabel);
    setFormContent(tpl.content);
    setFormTags(tpl.tags?.join(', ') || '');
    setAiError(null);
    setIsEditorOpen(true);
  };

  // Duplicate a template
  const handleDuplicate = (tpl: MessageTemplate) => {
    const duplicated: MessageTemplate = {
      id: `tpl_custom_${Date.now()}`,
      title: `${tpl.title} (نسخة معدلة)`,
      category: tpl.category,
      categoryLabel: tpl.categoryLabel,
      content: tpl.content,
      tags: [...(tpl.tags || []), 'معدل'],
      isDefault: false,
      createdAt: new Date().toISOString().slice(0, 10),
      usageCount: 0,
    };
    onSaveTemplate(duplicated);
  };

  // Save template from editor
  const handleSaveEditor = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formTitle.trim() || !formContent.trim()) {
      alert('يرجى كتابة عنوان القالب ونص الرسالة.');
      return;
    }

    const tagsArray = formTags
      .split(/[,،]/)
      .map((t) => t.trim())
      .filter(Boolean);

    const updatedTemplate: MessageTemplate = {
      id: editingTemplate ? editingTemplate.id : `tpl_custom_${Date.now()}`,
      title: formTitle.trim(),
      category: formCategory,
      categoryLabel:
        formCategory === 'schools'
          ? 'المدارس الأهلية والدولية'
          : formCategory === 'companies'
            ? 'الشركات والمؤسسات العالمية'
            : formCategory === 'offers'
              ? 'عروض وباقات ترويجية'
              : formCategory === 'followup'
                ? 'رسائل المتابعة وإعادة التنشيط'
                : formCategory === 'direct_meeting'
                  ? 'دعوات الاجتماعات والعروض الحية'
                  : 'قوالب مخصصة',
      content: formContent.trim(),
      tags: tagsArray.length ? tagsArray : ['مخصص'],
      isDefault: editingTemplate ? editingTemplate.isDefault : false,
      createdAt: editingTemplate ? editingTemplate.createdAt : new Date().toISOString().slice(0, 10),
      updatedAt: new Date().toISOString().slice(0, 10),
      usageCount: editingTemplate?.usageCount || 0,
    };

    onSaveTemplate(updatedTemplate);
    setIsEditorOpen(false);
  };

  // AI Refinement Handler
  const handleRefineWithAi = async () => {
    if (!formContent.trim()) {
      setAiError('يرجى كتابة نص أساسي أولاً ليتمكن الذكاء الاصطناعي من تحسينه.');
      return;
    }
    setIsRefiningWithAi(true);
    setAiError(null);

    try {
      const res = await fetch('/api/templates/refine', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          currentContent: formContent,
          category: formCategory,
          tone: aiTone,
          agencyProfile,
          instruction: aiInstruction.trim() || 'تحسين أسلوب الإقناع التسويقي وجعله مناسباً للواتساب مع الحفاظ على المتغيرات',
        }),
      });

      const data = await res.json();
      if (data.success && data.refinedContent) {
        setFormContent(data.refinedContent);
      } else {
        throw new Error(data.error || 'لم يتم استلام نص محسن');
      }
    } catch (err: any) {
      console.warn('AI refinement fallback:', err);
      // Fallback local refinement
      const enhanced = `${formContent}\n\n✨ يسعدنا دائماً خدمتكم والإجابة على كافة تساؤلاتكم عبر الواتساب: {رقم_الواتس}`;
      setFormContent(enhanced);
      setAiError('تم تطبيق صياغة محسنة تلقائية محلياً.');
    } finally {
      setIsRefiningWithAi(false);
    }
  };

  // Copy template content
  const handleCopy = (tpl: MessageTemplate) => {
    navigator.clipboard.writeText(tpl.content);
    setCopiedTemplateId(tpl.id);
    setTimeout(() => setCopiedTemplateId(null), 2500);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner & Overview */}
      <div className="bg-white rounded-xl border border-stone-200 p-5 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-start sm:items-center gap-3">
          <div className="w-11 h-11 rounded-xl bg-purple-50 text-purple-700 flex items-center justify-center border border-purple-200 shrink-0">
            <FileText className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-lg font-bold text-stone-900">
                مكتبة قوالب الرسائل الإعلانية والتسويقية
              </h2>
              <span className="text-[11px] bg-purple-100 text-purple-800 font-bold px-2 py-0.5 rounded-full">
                {templates.length} قالب جاهز ومخصص
              </span>
            </div>
            <p className="text-xs text-stone-500 mt-0.5">
              قوالب صممت باحترافية للمدارس والشركات مع دعم المتغيرات الديناميكية ونقلها مباشرة لحملات الواتساب.
            </p>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-wrap items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={handleOpenNewEditor}
            className="inline-flex items-center gap-1.5 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold transition shadow-xs cursor-pointer active:scale-95"
          >
            <Plus className="w-4 h-4" />
            <span>إنشاء قالب جديد</span>
          </button>

          <button
            type="button"
            onClick={() => {
              if (confirm('هل ترغب في استعادة القوالب الافتراضية المعتمدة؟')) {
                onResetDefaultTemplates();
              }
            }}
            className="inline-flex items-center gap-1.5 px-3 py-2 bg-stone-50 hover:bg-stone-100 text-stone-700 rounded-lg text-xs font-semibold border border-stone-200 transition cursor-pointer"
            title="استعادة القوالب الافتراضية"
          >
            <RotateCcw className="w-3.5 h-3.5 text-stone-500" />
            <span>استعادة الافتراضية</span>
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white rounded-xl border border-stone-200 p-4 shadow-xs space-y-3">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
          {/* Search Box */}
          <div className="relative w-full sm:w-80">
            <Search className="w-4 h-4 text-stone-400 absolute right-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="ابحث في القوالب بالاسم، الكلمات أو النص..."
              className="w-full pl-3 pr-9 py-2 border border-stone-300 rounded-lg text-xs focus:ring-2 focus:ring-purple-500 focus:outline-hidden"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                className="absolute left-2.5 top-1/2 -translate-y-1/2 text-stone-400 hover:text-stone-600 text-xs font-bold"
              >
                ✕
              </button>
            )}
          </div>

          {/* Target Lead Selector for Live Previews */}
          <div className="flex items-center gap-2 w-full sm:w-auto justify-end text-xs">
            <span className="text-stone-500 text-[11px] whitespace-nowrap">معاينة المتغيرات على:</span>
            <select
              value={selectedPreviewLeadId}
              onChange={(e) => setSelectedPreviewLeadId(e.target.value)}
              className="p-1.5 border border-stone-300 rounded-md bg-stone-50 text-stone-800 text-xs font-medium max-w-[220px] truncate"
            >
              <option value="sample">جهة نموذجية (مدارس الرياض)</option>
              {leads
                .filter((l) => l.isWhatsappValid)
                .slice(0, 10)
                .map((l) => (
                  <option key={l.id} value={l.id}>
                    {l.name} ({l.city})
                  </option>
                ))}
            </select>
          </div>
        </div>

        {/* Category Tabs */}
        <div className="flex space-x-reverse space-x-1.5 overflow-x-auto pb-1 scrollbar-none border-t border-stone-100 pt-3">
          {categoryFilters.map((cat) => {
            const isSelected = activeCategory === cat.id;
            return (
              <button
                key={cat.id}
                type="button"
                onClick={() => setActiveCategory(cat.id)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition cursor-pointer flex items-center gap-1.5 ${
                  isSelected
                    ? 'bg-purple-700 text-white shadow-xs'
                    : 'bg-stone-50 hover:bg-stone-100 text-stone-600 border border-stone-200'
                }`}
              >
                <span>{cat.label}</span>
                <span
                  className={`text-[10px] px-1.5 py-0.2 rounded-full font-bold ${
                    isSelected ? 'bg-purple-900/60 text-purple-100' : 'bg-stone-200 text-stone-700'
                  }`}
                >
                  {cat.count}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Templates Grid */}
      {filteredTemplates.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {filteredTemplates.map((tpl) => {
            const renderedPreview = getRenderedContent(tpl.content);
            const isCopied = copiedTemplateId === tpl.id;

            return (
              <div
                key={tpl.id}
                className="bg-white rounded-xl border border-stone-200 p-5 shadow-xs hover:border-purple-300 transition-all flex flex-col justify-between space-y-4 relative group"
              >
                {/* Header info */}
                <div className="space-y-2">
                  <div className="flex items-start justify-between gap-3">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span
                          className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                            tpl.category === 'schools'
                              ? 'bg-blue-50 text-blue-700 border border-blue-200'
                              : tpl.category === 'companies'
                                ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                                : tpl.category === 'offers'
                                  ? 'bg-amber-50 text-amber-800 border border-amber-200'
                                  : 'bg-purple-50 text-purple-700 border border-purple-200'
                          }`}
                        >
                          {tpl.categoryLabel}
                        </span>

                        {tpl.isDefault ? (
                          <span className="text-[10px] bg-stone-100 text-stone-600 px-1.5 py-0.5 rounded font-medium">
                            معتمد رسمياً
                          </span>
                        ) : (
                          <span className="text-[10px] bg-emerald-50 text-emerald-700 border border-emerald-200 px-1.5 py-0.5 rounded font-bold">
                            قالب مخصص
                          </span>
                        )}
                      </div>

                      <h3 className="text-base font-bold text-stone-900 group-hover:text-purple-900 transition">
                        {tpl.title}
                      </h3>
                    </div>

                    {/* Quick Tools */}
                    <div className="flex items-center gap-1 shrink-0">
                      <button
                        type="button"
                        onClick={() => handleOpenEdit(tpl)}
                        className="p-1.5 text-stone-500 hover:text-stone-900 hover:bg-stone-100 rounded-md transition cursor-pointer"
                        title="تعديل وتخصيص القالب"
                      >
                        <Edit className="w-4 h-4" />
                      </button>

                      <button
                        type="button"
                        onClick={() => handleDuplicate(tpl)}
                        className="p-1.5 text-stone-500 hover:text-stone-900 hover:bg-stone-100 rounded-md transition cursor-pointer"
                        title="تكرار وإنشاء نسخة"
                      >
                        <Copy className="w-4 h-4" />
                      </button>

                      {!tpl.isDefault && (
                        <button
                          type="button"
                          onClick={() => {
                            if (confirm(`هل أنت متأكد من حذف القالب: "${tpl.title}"؟`)) {
                              onDeleteTemplate(tpl.id);
                            }
                          }}
                          className="p-1.5 text-stone-400 hover:text-rose-600 hover:bg-rose-50 rounded-md transition cursor-pointer"
                          title="حذف القالب"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </div>

                  {/* Tags */}
                  {tpl.tags && tpl.tags.length > 0 && (
                    <div className="flex flex-wrap gap-1">
                      {tpl.tags.map((tag) => (
                        <span key={tag} className="text-[10px] bg-stone-100 text-stone-600 px-1.5 py-0.5 rounded">
                          #{tag}
                        </span>
                      ))}
                    </div>
                  )}
                </div>

                {/* Content Box (WhatsApp Style Preview) */}
                <div className="bg-stone-50 rounded-xl p-3.5 border border-stone-200/80 font-sans text-xs leading-relaxed text-stone-800 space-y-2 relative">
                  <div className="flex items-center justify-between text-[10px] text-stone-400 pb-1.5 border-b border-stone-200">
                    <span className="flex items-center gap-1">
                      <Eye className="w-3 h-3 text-stone-400" />
                      معاينة الرسالة الفعلية على الواتساب:
                    </span>
                    <span>{renderedPreview.length} حرف</span>
                  </div>

                  <div className="whitespace-pre-line select-text max-h-48 overflow-y-auto pr-1">
                    {renderedPreview}
                  </div>
                </div>

                {/* Bottom Action Footer */}
                <div className="flex items-center justify-between gap-2 pt-2 border-t border-stone-100">
                  <div className="text-[11px] text-stone-400 flex items-center gap-1.5">
                    <Clock className="w-3 h-3" />
                    <span>مرات الاستخدام: {tpl.usageCount || 0}</span>
                  </div>

                  <div className="flex items-center gap-2">
                    {/* Copy Button */}
                    <button
                      type="button"
                      onClick={() => handleCopy(tpl)}
                      className="inline-flex items-center gap-1 px-3 py-1.5 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded-lg text-xs font-semibold transition cursor-pointer"
                    >
                      {isCopied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{isCopied ? 'تم النسخ!' : 'نسخ القالب'}</span>
                    </button>

                    {/* Use in Campaign Action */}
                    <button
                      type="button"
                      onClick={() => onUseTemplateInCampaign(tpl.content)}
                      className="inline-flex items-center gap-1.5 px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white rounded-lg text-xs font-bold transition shadow-2xs cursor-pointer"
                    >
                      <Send className="w-3.5 h-3.5" />
                      <span>استخدام في الحملة الآن</span>
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="text-center py-12 bg-white rounded-xl border border-dashed border-stone-300 p-8 space-y-3">
          <FileText className="w-10 h-10 text-stone-300 mx-auto" />
          <h3 className="text-sm font-bold text-stone-700">لا توجد قوالب تطابق عملية البحث أو التصنيف</h3>
          <p className="text-xs text-stone-400">
            يمكنك إنشاء قالب رسالة جديد، أو استعادة القوالب الافتراضية الجاهزة.
          </p>
          <div className="pt-2 flex justify-center gap-2">
            <button
              type="button"
              onClick={handleOpenNewEditor}
              className="px-4 py-2 bg-emerald-600 text-white text-xs font-bold rounded-lg hover:bg-emerald-700 cursor-pointer"
            >
              إنشاء قالب جديد الآن
            </button>
            <button
              type="button"
              onClick={onResetDefaultTemplates}
              className="px-3 py-2 bg-stone-100 text-stone-700 text-xs font-semibold rounded-lg hover:bg-stone-200 cursor-pointer"
            >
              استعادة الافتراضية
            </button>
          </div>
        </div>
      )}

      {/* Editor & Customizer Modal */}
      {isEditorOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/60 backdrop-blur-xs overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-3xl w-full border border-stone-200 shadow-xl overflow-hidden my-6">
            <form onSubmit={handleSaveEditor}>
              {/* Modal Header */}
              <div className="px-6 py-4 border-b border-stone-100 flex items-center justify-between bg-stone-50">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-lg bg-purple-100 text-purple-700 flex items-center justify-center">
                    <Edit className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="text-base font-bold text-stone-900">
                      {editingTemplate ? 'تعديل وتخصيص القالب الإعلاني' : 'إنشاء وحفظ قالب رسالة جديد'}
                    </h3>
                    <p className="text-xs text-stone-500">
                      قم بضبط عنوان القالب، الفئة المستهدفة، واستخدم المتغيرات التلقائية لرسالة شخصية.
                    </p>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => setIsEditorOpen(false)}
                  className="text-stone-400 hover:text-stone-700 text-sm font-bold p-1 rounded-md"
                >
                  ✕
                </button>
              </div>

              {/* Modal Body */}
              <div className="p-6 space-y-5 max-h-[75vh] overflow-y-auto">
                {/* Title & Category */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-stone-700 mb-1">
                      عنوان القالب (اسم وصفي):
                    </label>
                    <input
                      type="text"
                      required
                      value={formTitle}
                      onChange={(e) => setFormTitle(e.target.value)}
                      placeholder="مثال: باقة التسويق الرقمي لمدارس الرياض"
                      className="w-full p-2.5 border border-stone-300 rounded-lg text-xs focus:ring-2 focus:ring-purple-500 focus:outline-hidden"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-stone-700 mb-1">
                      التصنيف والقطاع المستهدف:
                    </label>
                    <select
                      value={formCategory}
                      onChange={(e) => setFormCategory(e.target.value as any)}
                      className="w-full p-2.5 border border-stone-300 rounded-lg text-xs bg-white text-stone-900 font-medium"
                    >
                      <option value="schools">المدارس الأهلية والدولية</option>
                      <option value="companies">الشركات والمؤسسات العالمية</option>
                      <option value="offers">عروض وباقات ترويجية</option>
                      <option value="followup">رسائل المتابعة وإعادة التنشيط</option>
                      <option value="direct_meeting">دعوات الاجتماعات والعروض الحية</option>
                      <option value="custom">قوالب عامة ومخصصة</option>
                    </select>
                  </div>
                </div>

                {/* Dynamic Variables Picker */}
                <div className="bg-purple-50/70 border border-purple-200 rounded-xl p-3.5 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-purple-900 flex items-center gap-1.5">
                      <Sparkles className="w-3.5 h-3.5 text-purple-600" />
                      انقر لإدراج متغير ديناميكي تلقائي في موضع المؤشر:
                    </span>
                    <span className="text-[10px] text-purple-700">تستبدل تلقائياً ببيانات الجهة الفعلية</span>
                  </div>

                  <div className="flex flex-wrap gap-1.5">
                    {dynamicVariables.map((item) => (
                      <button
                        key={item.tag}
                        type="button"
                        onClick={() => {
                          setFormContent((prev) => prev + (prev.endsWith(' ') ? '' : ' ') + item.tag);
                        }}
                        className="px-2 py-1 bg-white hover:bg-purple-100 text-purple-900 rounded-md text-[11px] font-mono border border-purple-300 transition cursor-pointer flex items-center gap-1 active:scale-95"
                        title={item.label}
                      >
                        <span className="font-bold">{item.tag}</span>
                        <span className="text-[10px] text-stone-500 font-sans">({item.label})</span>
                      </button>
                    ))}
                  </div>
                </div>

                {/* AI Assistant Bar */}
                <div className="bg-stone-50 border border-stone-200 rounded-xl p-3.5 space-y-3">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <span className="text-xs font-bold text-stone-900 flex items-center gap-1.5">
                      <Wand2 className="w-4 h-4 text-emerald-600" />
                      تحسين وتطوير القالب بالذكاء الاصطناعي (Gemini 3.8):
                    </span>

                    <div className="flex items-center gap-2">
                      <select
                        value={aiTone}
                        onChange={(e) => setAiTone(e.target.value as any)}
                        className="text-xs bg-white border border-stone-300 rounded-md px-2 py-1 text-stone-800"
                      >
                        <option value="persuasive">نبرة إقناع تسويقي (موصى بها)</option>
                        <option value="executive">نبرة رسمية وتنفيذية</option>
                        <option value="concise">نبرة مختصرة وسريعة</option>
                        <option value="friendly">نبرة ودية ومباشرة</option>
                      </select>

                      <button
                        type="button"
                        onClick={handleRefineWithAi}
                        disabled={isRefiningWithAi || !formContent.trim()}
                        className="px-3 py-1 bg-purple-700 hover:bg-purple-800 text-white rounded-md text-xs font-bold transition flex items-center gap-1 cursor-pointer disabled:opacity-50"
                      >
                        <Sparkles className="w-3.5 h-3.5" />
                        <span>{isRefiningWithAi ? 'جاري التحسين...' : 'تحسين القالب'}</span>
                      </button>
                    </div>
                  </div>

                  <input
                    type="text"
                    value={aiInstruction}
                    onChange={(e) => setAiInstruction(e.target.value)}
                    placeholder="تعليمات إضافية للذكاء الاصطناعي (اختياري، مثلاً: ركز على تقليل التكاليف وزيادة الطلاب)"
                    className="w-full p-2 border border-stone-200 bg-white rounded-lg text-xs text-stone-800"
                  />

                  {aiError && (
                    <div className="text-[11px] text-amber-800 bg-amber-50 p-2 rounded-md flex items-center gap-1.5">
                      <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                      <span>{aiError}</span>
                    </div>
                  )}
                </div>

                {/* Content Textarea */}
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-xs font-bold text-stone-700">
                      نص القالب (يمكنك التعديل اليدوي وإضافة الفواصل والرموز):
                    </label>
                    <span className="text-[11px] text-stone-400">{formContent.length} حرف</span>
                  </div>
                  <textarea
                    rows={8}
                    required
                    value={formContent}
                    onChange={(e) => setFormContent(e.target.value)}
                    placeholder="اكتب هنا محتوى الرسالة الإعلانية والتسويقية..."
                    className="w-full p-3.5 border border-stone-300 rounded-xl text-xs leading-relaxed focus:ring-2 focus:ring-purple-500 focus:outline-hidden font-sans"
                  />
                </div>

                {/* Live Preview of Rendered Message */}
                <div className="bg-emerald-50/40 border border-emerald-200 rounded-xl p-3.5 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-emerald-900 flex items-center gap-1">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                      المعاينة الحية بعد تعويض المتغيرات لـ ({currentPreviewLead.name}):
                    </span>
                  </div>
                  <div className="bg-white p-3 rounded-lg border border-emerald-100 text-xs text-stone-800 leading-relaxed whitespace-pre-line select-text">
                    {getRenderedContent(formContent) || 'ستظهر هنا المعاينة الحية للرسالة...'}
                  </div>
                </div>

                {/* Tags */}
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    الوسوم والكلمات الدلالية (مفصولة بفواصل):
                  </label>
                  <input
                    type="text"
                    value={formTags}
                    onChange={(e) => setFormTags(e.target.value)}
                    placeholder="مثال: مدارس, تسجيل, واتساب, استشارات"
                    className="w-full p-2.5 border border-stone-300 rounded-lg text-xs focus:ring-2 focus:ring-purple-500 focus:outline-hidden"
                  />
                </div>
              </div>

              {/* Modal Footer */}
              <div className="px-6 py-3.5 border-t border-stone-100 flex items-center justify-between bg-stone-50">
                <button
                  type="button"
                  onClick={() => setIsEditorOpen(false)}
                  className="px-4 py-2 bg-stone-200 hover:bg-stone-300 text-stone-700 rounded-lg text-xs font-semibold transition cursor-pointer"
                >
                  إلغاء
                </button>

                <div className="flex items-center gap-2">
                  <button
                    type="submit"
                    className="px-5 py-2 bg-purple-700 hover:bg-purple-800 text-white rounded-lg text-xs font-bold transition shadow-xs cursor-pointer active:scale-95"
                  >
                    {editingTemplate ? 'حفظ التعديلات' : 'حفظ القالب الجديد'}
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
