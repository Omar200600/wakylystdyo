import React, { useState } from 'react';
import {
  Bot,
  MessageCircle,
  Briefcase,
  Save,
  Sparkles,
  Send,
  Copy,
  Check,
  User,
  Phone,
  HelpCircle,
  Clock,
  ShieldCheck,
  Wand2,
  RefreshCw,
} from 'lucide-react';
import { AgencyProfile, ChatInteraction } from '../types';
import { generateWhatsAppChatUrl } from '../utils/phoneUtils';

interface AgencyProfileAndAutoReplyProps {
  agencyProfile: AgencyProfile;
  onSaveProfile: (profile: AgencyProfile) => void;
}

export const AgencyProfileAndAutoReply: React.FC<AgencyProfileAndAutoReplyProps> = ({
  agencyProfile,
  onSaveProfile,
}) => {
  const [profile, setProfile] = useState<AgencyProfile>(agencyProfile);
  const [isSavedAlert, setIsSavedAlert] = useState(false);

  // Auto-Responder Live Simulator State
  const [incomingMessage, setIncomingMessage] = useState(
    'السلام عليكم، نود الاستفسار عن باقاتكم لتطوير بوابتنا الإلكترونية وزيادة تسجيل الطلاب في مدارسنا، ما هي التفاصيل والأسعار؟'
  );
  const [senderName, setSenderName] = useState('مدير مجمع تعليمي');
  const [senderPhone, setSenderPhone] = useState('+966509988776');
  const [isGeneratingReply, setIsGeneratingReply] = useState(false);
  const [currentReply, setCurrentReply] = useState('');
  const [copiedSuccess, setCopiedSuccess] = useState(false);

  // Chat History Simulator
  const [chatLog, setChatLog] = useState<
    { sender: 'client' | 'ai'; text: string; timestamp: string }[]
  >([
    {
      sender: 'client',
      text: 'السلام عليكم ورحمة الله، وصلتنا رسالتكم بخصوص أتمتة الواتساب للمدارس، هل لديكم سابقة أعمال مماثلة؟',
      timestamp: '10:15 ص',
    },
    {
      sender: 'ai',
      text: `وعليكم السلام ورحمة الله وبركاته، أهلاً بحضرتك وبإدارة صرحكم التعليمي الموقر.
نعم بكل تأكيد، قمنا مؤخراً بتطوير منظومة الرد والأتمتة الذكية لـ 12 مدرسة أهلية ودولية ساهمت في استيعاب أكثر من 50 ألف استفسار لأولياء الأمور ورفعت معدلات التسجيل بنسبة 35%.
يسعدنا أن نرتب معكم جلسة تعريفية مجانية عبر زووم أو مكالمة هاتفية لعرض النظام وسابقة الأعمال بالتفصيل.
ممثلو وكالتنا جاهزون لخدمتكم دائماً عبر الواتساب الرسمي: ${agencyProfile.myWhatsapp || '00667737219181'}.`,
      timestamp: '10:16 ص',
    },
  ]);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    onSaveProfile(profile);
    setIsSavedAlert(true);
    setTimeout(() => setIsSavedAlert(false), 3000);
  };

  // Generate AI Reply using Gemini
  const handleGenerateReply = async () => {
    if (!incomingMessage.trim()) return;
    setIsGeneratingReply(true);

    try {
      const response = await fetch('/api/agency/ai-reply', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          incomingMessage,
          senderName,
          senderPhone,
          agencyProfile: profile,
        }),
      });

      const data = await response.json();
      if (data.success && data.reply) {
        setCurrentReply(data.reply);
        // Add to chat log
        const timeNow = new Date().toLocaleTimeString('ar-SA', {
          hour: '2-digit',
          minute: '2-digit',
        });
        setChatLog((prev) => [
          ...prev,
          { sender: 'client', text: incomingMessage, timestamp: timeNow },
          { sender: 'ai', text: data.reply, timestamp: timeNow },
        ]);
      }
    } catch (err) {
      console.error('Failed to generate AI auto-reply', err);
    } finally {
      setIsGeneratingReply(false);
    }
  };

  const handleCopyReply = () => {
    navigator.clipboard.writeText(currentReply);
    setCopiedSuccess(true);
    setTimeout(() => setCopiedSuccess(false), 2000);
  };

  const loadPresetTemplate = (type: 'digital_marketing' | 'tech_solutions' | 'consulting') => {
    if (type === 'digital_marketing') {
      setProfile((prev) => ({
        ...prev,
        agencyName: 'وكالة الإبداع للتسويق الرقمي وإدارة النمو',
        industry: 'التسويق الرقمي المتخصص للمدارس الأهلية والمؤسسات الكبرى',
        businessDetails: `وكالة رائدة في إدارة الحملات الإعلانية الممولة على جوجل وسناب شات وتيك توك وإنستغرام. نركز على استقطاب وتوليد العملاء المحتملين (Lead Generation)، زيادة أعداد الطلاب المسجلين بالمدارس، وصناعة المحتوى الإبداعي والتصاميم والفيديوهات الترويجية مع تقارير أداء أسبوعية واضحة.`,
        portfolioSummary: `• تحقيق أكثر من 3000 تسجيل مؤكد في مدارس رياض وجدة خلال عام واحد.
• خفض تكلفة اكتساب العميل (CAC) بنسبة 40% لـ 8 شركات عالمية.
• إدارة ميزانيات إعلانية تتجاوز 2 مليون ريال بنتائج قياسية.`,
        keyOfferings: 'حملات إعلانية مدفوعة، صناعة محتوى تسويقي، تصوير وإنتاج، استشارات تسويق',
      }));
    } else if (type === 'tech_solutions') {
      setProfile((prev) => ({
        ...prev,
        agencyName: 'وكالة الحلول التقنية والذكاء الاصطناعي',
        industry: 'تطوير البرمجيات وبوتات الواتساب والأتمتة السحابية',
        businessDetails: `نطور منصات وبوابات إلكترونية مخصصة، أنظمة إدارة المدارس والقبول (SIS/LMS)، برمجيات الربط مع الواتساب عبر API الرسمي للرد التلقائي على أولياء الأمور والعملاء على مدار 24 ساعة، مع لوحات تحكم تحليلية متقدمة.`,
        portfolioSummary: `• إطلاق 15 بوابة إلكترونية تفاعلية للمدارس الخاصة والجامعات.
• أتمتة خدمة العملاء لـ 10 شركات عالمية بمعالجة 100 ألف استفسار آلياً.
• تكامل كامل مع بوابات الدفع الإلكتروني المعتمدة.`,
        keyOfferings: 'بوتات واتساب ذكية، بوابات تسجيل إلكتروني، تطبيقات جوال، برمجيات مخصصة',
      }));
    } else {
      setProfile((prev) => ({
        ...prev,
        agencyName: 'مكتب الاستشارات وتطوير الأعمال الدولية',
        industry: 'استشارات تطوير الأعمال والشراكات الاستراتيجية',
        businessDetails: `نساعد المدارس الأهلية والشركات العالمية في التوسع بالسوق الخليجي والعربي، دراسة الجدوى وتطوير الهوية المؤسسية، وعقد شراكات مع كبرى الجهات الحكومية والخاصة.`,
        portfolioSummary: `• المساهمة في تأسيس وتطوير 6 مجمعات تعليمية دولية.
• قيادة صفقات استراتيجية مع كبرى الشركات الاستثمارية.`,
        keyOfferings: 'تطوير استراتيجيات التوسع، دراسات السوق، الشراكات المؤسسية',
      }));
    }
  };

  return (
    <div className="space-y-6">
      {/* Header Info */}
      <div className="bg-white rounded-xl border border-stone-200 p-6 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-50 text-emerald-800 text-xs font-semibold mb-2">
              <Bot className="w-3.5 h-3.5" />
              وكيل الرد التلقائي وإدارة ملف الوكالة
            </div>
            <h2 className="text-xl font-bold text-stone-900">
              بيانات العمل ومجال التجارة + وكيل الرد التلقائي برقمك المعتمد
            </h2>
            <p className="text-sm text-stone-600 mt-1 max-w-3xl">
              اكتب في هذه الخانة تفاصيل نشاطك وتجارتك وسابقة أعمالك بدقة؛ حيث سيعتمد عليها الوكيل الذكي للرد على رسائل المدارس والشركات نيابة عنك والتواصل معهم برقمك الواتس هذا:{' '}
              <span className="font-bold font-mono text-emerald-700 dir-ltr select-all">
                {profile.myWhatsapp || '00667737219181'}
              </span>
              .
            </p>
          </div>

          {/* Quick Presets */}
          <div className="flex flex-wrap items-center gap-1.5 self-start md:self-auto">
            <span className="text-xs text-stone-500">نماذج جاهزة:</span>
            <button
              type="button"
              onClick={() => loadPresetTemplate('tech_solutions')}
              className="text-xs bg-stone-100 hover:bg-stone-200 text-stone-800 px-2.5 py-1 rounded-md cursor-pointer transition"
            >
              حلول برمجية وواتساب
            </button>
            <button
              type="button"
              onClick={() => loadPresetTemplate('digital_marketing')}
              className="text-xs bg-stone-100 hover:bg-stone-200 text-stone-800 px-2.5 py-1 rounded-md cursor-pointer transition"
            >
              تسويق رقمي
            </button>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Business & Trade Configuration Form */}
        <div className="lg:col-span-7 space-y-4">
          <form onSubmit={handleSave} className="bg-white rounded-xl border border-stone-200 p-5 shadow-xs space-y-4">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3">
              <h3 className="text-sm font-bold text-stone-900 flex items-center gap-2">
                <Briefcase className="w-4 h-4 text-emerald-600" />
                <span>خانة توضيح العمل ومجال التجارة للوكيل الذكي</span>
              </h3>

              {isSavedAlert && (
                <span className="text-xs bg-emerald-100 text-emerald-800 px-2.5 py-0.5 rounded-full font-bold flex items-center gap-1 animate-bounce">
                  <Check className="w-3 h-3" />
                  تم الحفظ بنجاح!
                </span>
              )}
            </div>

            {/* Basic Info */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div>
                <label className="block font-semibold text-stone-700 mb-1">
                  اسم الوكالة / المؤسسة:
                </label>
                <input
                  type="text"
                  required
                  value={profile.agencyName}
                  onChange={(e) => setProfile({ ...profile, agencyName: e.target.value })}
                  placeholder="مثال: وكالة الإبداع للحلول المتكاملة"
                  className="w-full px-3 py-2 border border-stone-300 rounded-lg text-sm"
                />
              </div>

              <div>
                <label className="block font-semibold text-stone-700 mb-1 flex items-center justify-between">
                  <span>رقم الواتساب الرسمي المعتمد:</span>
                  <span className="text-[10px] text-emerald-700 font-bold">الرقم المحدد</span>
                </label>
                <input
                  type="text"
                  required
                  value={profile.myWhatsapp}
                  onChange={(e) => setProfile({ ...profile, myWhatsapp: e.target.value })}
                  placeholder="00667737219181"
                  className="w-full px-3 py-2 border border-emerald-300 bg-emerald-50/30 rounded-lg text-sm font-mono font-bold text-emerald-900 dir-ltr text-right"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div>
                <label className="block font-semibold text-stone-700 mb-1">
                  البريد الإلكتروني للوكالة:
                </label>
                <input
                  type="email"
                  value={profile.myEmail}
                  onChange={(e) => setProfile({ ...profile, myEmail: e.target.value })}
                  placeholder="contact@agency.com"
                  className="w-full px-3 py-2 border border-stone-300 rounded-lg text-sm dir-ltr text-right"
                />
              </div>

              <div>
                <label className="block font-semibold text-stone-700 mb-1">
                  مجال الصناعة والتخصص الرئيسي:
                </label>
                <input
                  type="text"
                  value={profile.industry}
                  onChange={(e) => setProfile({ ...profile, industry: e.target.value })}
                  placeholder="مثال: التسويق الرقمي والأتمتة والبرمجيات للمدارس والشركات"
                  className="w-full px-3 py-2 border border-stone-300 rounded-lg text-sm"
                />
              </div>
            </div>

            {/* MAIN TEXTAREA: Business Details & Scope */}
            <div>
              <label className="block font-semibold text-stone-800 text-xs mb-1.5 flex items-center justify-between">
                <span className="flex items-center gap-1.5 text-stone-900 font-bold">
                  <Wand2 className="w-3.5 h-3.5 text-emerald-600" />
                  شرح مفصل عن عملي ومجال تجارتي (دليل الوكيل الذكي):
                </span>
                <span className="text-[10px] text-stone-400">
                  يقرأه الذكاء الاصطناعي ليرد بدقة عنك
                </span>
              </label>
              <textarea
                value={profile.businessDetails}
                onChange={(e) => setProfile({ ...profile, businessDetails: e.target.value })}
                rows={6}
                className="w-full p-3.5 border border-stone-300 rounded-xl text-sm leading-relaxed focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                placeholder="وضح هنا بدقة كل ما تقدمه: مثلاً خدماتنا، ما يميزنا عن غيرنا، شروط التعامل، طريقة تقديم الاستشارة، كيفية تسعير الخدمات..."
              />
            </div>

            {/* Portfolio & Case Studies */}
            <div>
              <label className="block font-semibold text-stone-800 text-xs mb-1.5">
                عرض الأعمال وسابقة الإنجازات والنتائج (Portfolio):
              </label>
              <textarea
                value={profile.portfolioSummary}
                onChange={(e) => setProfile({ ...profile, portfolioSummary: e.target.value })}
                rows={3}
                className="w-full p-3.5 border border-stone-300 rounded-xl text-sm leading-relaxed focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                placeholder="أبرز النجاحات: مثلاً رفع تسجيل الطلاب بنسبة 35%، برمجة بوابات رقمية لـ 20 شركة، توفير حلول معتمدة..."
              />
            </div>

            {/* Key Offerings & Keywords */}
            <div>
              <label className="block font-semibold text-stone-800 text-xs mb-1">
                الخدمات الرئيسية المعروضة (كلمات مفتاحية):
              </label>
              <input
                type="text"
                value={profile.keyOfferings}
                onChange={(e) => setProfile({ ...profile, keyOfferings: e.target.value })}
                placeholder="أتمتة الواتساب، حملات تسويقية، تصميم مواقع، بوابات قبول، استشارات أعمال"
                className="w-full px-3 py-2 border border-stone-300 rounded-lg text-sm"
              />
            </div>

            {/* DEDICATED FIELD: Agency Ad Announcement with Join Form Link */}
            <div className="bg-emerald-50/50 p-4 rounded-xl border border-emerald-200 space-y-3">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-emerald-950 flex items-center gap-1.5">
                  <Wand2 className="w-3.5 h-3.5 text-emerald-700" />
                  <span>خانة لصق رسالة الإعلان عن الوكالة ورابط نموذج الانضمام:</span>
                </label>
                <span className="text-[10px] text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded-full font-bold">
                  للمدارس والشركات
                </span>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-stone-700 mb-1">
                  رابط وكالتي / نموذج تعبئة وانضمام المدارس والشركات:
                </label>
                <input
                  type="url"
                  value={profile.agencyFormUrl || ''}
                  onChange={(e) => setProfile({ ...profile, agencyFormUrl: e.target.value })}
                  placeholder="https://agency-portal.com/join-schools-companies أو رابط Google Forms"
                  className="w-full px-3 py-2 border border-stone-300 rounded-lg text-xs font-mono dir-ltr text-right bg-white"
                />
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-[11px] font-semibold text-stone-700">
                    نص الإعلان الرسمي عن الوكالة المتضمن للرابط:
                  </label>
                  <button
                    type="button"
                    onClick={() => {
                      setProfile({
                        ...profile,
                        agencyAdAnnouncement: `📢 إعلان رسمي وشراكة استراتيجية للمدارس والشركات:
السلام عليكم ورحمة الله وبركاته، تحية تقدير لإدارة {اسم_الجهة} في {المدينة}،
يسر {اسم_الوكالة} تقديم أحدث حلول الأتمتة والذكاء الاصطناعي وبوتات الواتساب لخدمة العملاء والطلاب 24/7.
نوفر خيارات مرنة تناسبكم: (شراء رخصة بيع كاملة وملكية دائمة، أو استئجار سحابي شهري/سنوي ميسر).

📋 لتعبئة نموذج طلب الانضمام والشراكة:
{رابط_النموذج}

📞 للتواصل والاستفسار المباشر عبر الواتساب:
{رقم_الواتس}`,
                      });
                    }}
                    className="text-[10px] text-emerald-700 hover:underline font-bold cursor-pointer"
                  >
                    + إدراج نص إعلاني مقترح
                  </button>
                </div>
                <textarea
                  value={profile.agencyAdAnnouncement || ''}
                  onChange={(e) => setProfile({ ...profile, agencyAdAnnouncement: e.target.value })}
                  rows={6}
                  className="w-full p-3 border border-stone-300 rounded-xl text-xs sm:text-sm leading-relaxed bg-white focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                  placeholder="الصق هنا رسالة إعلان الوكالة مع رابط النموذج ليستخدمها الوكيل في إرسال الحملات..."
                />
              </div>
            </div>

            {/* Submit Button */}
            <div className="flex items-center justify-end pt-3 border-t border-stone-100">
              <button
                type="submit"
                className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-lg text-sm flex items-center gap-2 cursor-pointer shadow-xs transition active:scale-95"
              >
                <Save className="w-4 h-4" />
                <span>حفظ بيانات العمل وتحديث الوكيل الذكي</span>
              </button>
            </div>
          </form>
        </div>

        {/* Right Column: AI Auto-Reply Simulator & Inbox */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-white rounded-xl border border-stone-200 p-5 shadow-xs space-y-4">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3">
              <h3 className="text-sm font-bold text-stone-900 flex items-center gap-2">
                <MessageCircle className="w-4 h-4 text-emerald-600" />
                <span>محاكي الرد التلقائي على رسائل العملاء</span>
              </h3>
              <span className="text-[10px] bg-emerald-50 text-emerald-800 px-2 py-0.5 rounded-full font-bold">
                مباشر
              </span>
            </div>

            {/* Test Input Area */}
            <div className="space-y-2 bg-stone-50 p-3.5 rounded-xl border border-stone-200 text-xs">
              <div className="flex items-center justify-between">
                <span className="font-bold text-stone-700">اختبر رد الوكيل الذكي:</span>
                <span className="text-[10px] text-stone-400">نيابة عن رقمك {profile.myWhatsapp || '00667737219181'}</span>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <input
                  type="text"
                  value={senderName}
                  onChange={(e) => setSenderName(e.target.value)}
                  placeholder="اسم العميل أو المدرسة"
                  className="px-2.5 py-1.5 border border-stone-300 rounded-md bg-white text-stone-800"
                />
                <input
                  type="text"
                  value={senderPhone}
                  onChange={(e) => setSenderPhone(e.target.value)}
                  placeholder="رقم هاتف العميل"
                  className="px-2.5 py-1.5 border border-stone-300 rounded-md bg-white text-stone-800 dir-ltr text-right"
                />
              </div>

              <div>
                <textarea
                  value={incomingMessage}
                  onChange={(e) => setIncomingMessage(e.target.value)}
                  rows={3}
                  placeholder="اكتب رسالة واردة يرسلها عميل أو مدرسة..."
                  className="w-full p-2.5 border border-stone-300 rounded-lg bg-white text-xs leading-relaxed focus:ring-1 focus:ring-emerald-500 focus:outline-hidden"
                />
              </div>

              <div className="flex flex-wrap items-center gap-1.5">
                <span className="text-[10px] text-stone-400">أسئلة تجريبية سريعة:</span>
                {[
                  'كم تكلفة باقة التسويق لديكم؟',
                  'هل لديكم ضمان على زيادة تسجيل الطلاب؟',
                  'كيف يتم ربط بوت الواتساب التلقائي؟',
                ].map((q) => (
                  <button
                    key={q}
                    type="button"
                    onClick={() => setIncomingMessage(q)}
                    className="text-[10px] bg-white border border-stone-200 hover:border-emerald-400 text-stone-700 px-2 py-0.5 rounded cursor-pointer transition"
                  >
                    {q}
                  </button>
                ))}
              </div>

              <button
                type="button"
                onClick={handleGenerateReply}
                disabled={isGeneratingReply}
                className="w-full py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-lg text-xs flex items-center justify-center gap-1.5 transition cursor-pointer shadow-xs active:scale-95 disabled:bg-stone-300"
              >
                {isGeneratingReply ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    <span>جاري توليد الرد الذكي نيابة عنك...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>توليد الرد الذكي نيابة عن الوكالة</span>
                  </>
                )}
              </button>
            </div>

            {/* Live Chat History Box */}
            <div className="space-y-2">
              <span className="text-xs font-semibold text-stone-700 block">
                سجل المحادثة الحية:
              </span>
              <div className="bg-stone-100 rounded-xl p-3 max-h-80 overflow-y-auto space-y-3 text-xs">
                {chatLog.map((chat, idx) => (
                  <div
                    key={idx}
                    className={`flex flex-col ${
                      chat.sender === 'client' ? 'items-start' : 'items-end'
                    }`}
                  >
                    <div
                      className={`max-w-[88%] p-3 rounded-xl leading-relaxed whitespace-pre-line ${
                        chat.sender === 'client'
                          ? 'bg-white text-stone-900 border border-stone-200 rounded-tr-none'
                          : 'bg-emerald-700 text-white rounded-tl-none shadow-xs'
                      }`}
                    >
                      <div className="text-[10px] font-bold mb-1 opacity-75">
                        {chat.sender === 'client' ? senderName || 'العميل' : `وكيل ${profile.agencyName}`}
                      </div>
                      {chat.text}
                      <div className="text-[9px] text-right mt-1 opacity-60">
                        {chat.timestamp}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Copy / WhatsApp Dispatch for latest reply */}
            {currentReply && (
              <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs space-y-2">
                <div className="flex items-center justify-between text-emerald-900 font-bold">
                  <span>تم تجهيز الرد الذكي بنجاح:</span>
                  <button
                    type="button"
                    onClick={handleCopyReply}
                    className="inline-flex items-center gap-1 text-emerald-800 hover:underline cursor-pointer"
                  >
                    {copiedSuccess ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                    <span>{copiedSuccess ? 'تم النسخ!' : 'نسخ الرد'}</span>
                  </button>
                </div>
                <div className="flex items-center gap-2">
                  <a
                    href={generateWhatsAppChatUrl(senderPhone || '00667737219181', currentReply)}
                    target="_blank"
                    rel="noreferrer"
                    className="flex-1 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-center font-bold transition flex items-center justify-center gap-1"
                  >
                    <MessageCircle className="w-3.5 h-3.5" />
                    <span>إرسال الرد عبر الواتساب مباشرة</span>
                  </a>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
