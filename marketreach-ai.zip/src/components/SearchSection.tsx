import React, { useState } from 'react';
import {
  Search,
  School,
  Building2,
  Globe2,
  Filter,
  CheckCircle2,
  AlertCircle,
  Loader2,
  Download,
  FileSpreadsheet,
  FileText,
  Sparkles,
  ArrowRight,
  ShieldCheck,
} from 'lucide-react';
import { Lead } from '../types';
import { exportLeadsToExcel, exportLeadsToWord } from '../utils/exportUtils';

interface SearchSectionProps {
  onAddLeads: (newLeads: Lead[]) => void;
  onNavigateToLeads: () => void;
}

const COUNTRY_OPTIONS = [
  { id: 'sa', name: 'المملكة العربية السعودية', code: '+966', defaultCities: ['الرياض', 'جدة', 'الدمام', 'مكة المكرمة'] },
  { id: 'ae', name: 'الإمارات العربية المتحدة', code: '+971', defaultCities: ['دبي', 'أبوظبي', 'الشارقة'] },
  { id: 'qa', name: 'دولة قطر', code: '+974', defaultCities: ['الدوحة', 'الريان', 'الوكرة'] },
  { id: 'kw', name: 'دولة الكويت', code: '+965', defaultCities: ['مدينة الكويت', 'حولي', 'الأحمدي'] },
  { id: 'om', name: 'سلطنة عُمان', code: '+968', defaultCities: ['مسقط', 'صلالة', 'صحار'] },
  { id: 'eg', name: 'جمهورية مصر العربية', code: '+20', defaultCities: ['القاهرة', 'الجيزة', 'الإسكندرية'] },
  { id: 'jo', name: 'المملكة الأردنية الهاشمية', code: '+962', defaultCities: ['عمان', 'إربد', 'الزرقاء'] },
];

export const SearchSection: React.FC<SearchSectionProps> = ({
  onAddLeads,
  onNavigateToLeads,
}) => {
  const [targetCategory, setTargetCategory] = useState<'schools' | 'companies' | 'all'>('schools');
  const [selectedCountry, setSelectedCountry] = useState('المملكة العربية السعودية');
  const [isCustomCountry, setIsCustomCountry] = useState(false);
  const [customCountryName, setCustomCountryName] = useState('');
  const [selectedCity, setSelectedCity] = useState('الرياض');
  const [customCity, setCustomCity] = useState('');
  const [keywords, setKeywords] = useState('مدارس أهلية نموذجية ودولية مع أرقام الواتساب والإيميلات');
  const [resultCount, setResultCount] = useState(10);
  const [filterInvalidAutomatically, setFilterInvalidAutomatically] = useState(true);

  const [isSearching, setIsSearching] = useState(false);
  const [searchStep, setSearchStep] = useState<string>('');
  const [searchResults, setSearchResults] = useState<Lead[]>([]);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const currentCountryObj = COUNTRY_OPTIONS.find((c) => c.name === selectedCountry);

  const handleRunSearch = async () => {
    setIsSearching(true);
    setErrorMessage(null);
    setSearchResults([]);

    const actualCountry = isCustomCountry ? customCountryName.trim() : selectedCountry;
    const actualCity = customCity.trim() || selectedCity;

    try {
      setSearchStep('1/3: الاتصال بمحركات البحث عبر Google Search Grounding...');

      const response = await fetch('/api/leads/search', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          category: targetCategory,
          country: actualCountry,
          city: actualCity,
          keywords: keywords,
          count: resultCount,
        }),
      });

      setSearchStep('2/3: استخراج بيانات الاتصال وتنسيق أرقام الواتساب والإيميلات...');

      const data = await response.json();

      if (!response.ok || !data.success) {
        throw new Error(data.error || 'تعذر جلب نتائج البحث من المحرك');
      }

      setSearchStep('3/3: تدقيق الأرقام وتصفية الأرقام غير الصالحة...');

      let fetchedLeads: Lead[] = data.leads || [];

      if (filterInvalidAutomatically) {
        // Keep valid WhatsApp numbers
        fetchedLeads = fetchedLeads.filter((l) => l.isWhatsappValid);
      }

      setSearchResults(fetchedLeads);
      onAddLeads(fetchedLeads);
    } catch (err: any) {
      console.error('Search error:', err);
      setErrorMessage(err.message || 'حدث خطأ غير متوقع أثناء البحث. يرجى التحقق وإعادة المحاولة.');
    } finally {
      setIsSearching(false);
      setSearchStep('');
    }
  };

  return (
    <div className="space-y-6">
      {/* Intro Header */}
      <div className="bg-white rounded-xl border border-stone-200 p-6 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-50 text-emerald-800 text-xs font-semibold mb-2">
              <Sparkles className="w-3.5 h-3.5" />
              وكيل التنقيب والبحث المتصل بمحركات البحث
            </div>
            <h2 className="text-xl font-bold text-stone-900">
              البحث في محركات البحث عن المدارس الأهلية والشركات العالمية
            </h2>
            <p className="text-sm text-stone-600 mt-1 max-w-3xl">
              اكتب الكلمات المفتاحية، اختر الدولة والمدينة، وسيقوم الوكيل الذكي بالبحث عبر محركات البحث، واستخراج أرقام الواتساب والإيميلات، وتصفية الأرقام التالفة والاحتفاظ بالأرقام الصالحة تلقائياً.
            </p>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => onNavigateToLeads()}
              className="inline-flex items-center gap-2 px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-800 rounded-lg text-sm font-medium transition cursor-pointer"
            >
              <span>عرض قاعدة البيانات الحالية</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Main Search Controls Grid */}
      <div className="bg-white rounded-xl border border-stone-200 p-6 shadow-xs space-y-6">
        {/* Step 1: Target Category */}
        <div>
          <label className="block text-sm font-semibold text-stone-800 mb-2">
            1. نوع الجهات المستهدفة بالبحث:
          </label>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <button
              type="button"
              onClick={() => {
                setTargetCategory('schools');
                setKeywords('مدارس أهلية ودولية نموذجية للتواصل واستخراج أرقام الواتساب');
              }}
              className={`p-3.5 rounded-xl border text-right transition flex items-start gap-3 cursor-pointer ${
                targetCategory === 'schools'
                  ? 'border-emerald-600 bg-emerald-50/70 text-emerald-950 font-bold ring-1 ring-emerald-600'
                  : 'border-stone-200 hover:border-stone-300 text-stone-700'
              }`}
            >
              <div className={`p-2 rounded-lg ${targetCategory === 'schools' ? 'bg-emerald-600 text-white' : 'bg-stone-100 text-stone-600'}`}>
                <School className="w-5 h-5" />
              </div>
              <div>
                <div className="text-sm font-bold">المدارس الأهلية والدولية</div>
                <div className="text-xs text-stone-500 font-normal mt-0.5">
                  مدارس خاصة، لغات، مجمعات تعليمية
                </div>
              </div>
            </button>

            <button
              type="button"
              onClick={() => {
                setTargetCategory('companies');
                setKeywords('شركات عالمية ومؤسسات استثمارية كبرى مع أرقام الواتساب والإيميل');
              }}
              className={`p-3.5 rounded-xl border text-right transition flex items-start gap-3 cursor-pointer ${
                targetCategory === 'companies'
                  ? 'border-emerald-600 bg-emerald-50/70 text-emerald-950 font-bold ring-1 ring-emerald-600'
                  : 'border-stone-200 hover:border-stone-300 text-stone-700'
              }`}
            >
              <div className={`p-2 rounded-lg ${targetCategory === 'companies' ? 'bg-emerald-600 text-white' : 'bg-stone-100 text-stone-600'}`}>
                <Building2 className="w-5 h-5" />
              </div>
              <div>
                <div className="text-sm font-bold">الشركات والمؤسسات العالمية</div>
                <div className="text-xs text-stone-500 font-normal mt-0.5">
                  شركات متعددة الجنسيات، تجارية، مكاتب رئيسية
                </div>
              </div>
            </button>

            <button
              type="button"
              onClick={() => {
                setTargetCategory('all');
                setKeywords('أفضل المدارس الأهلية والشركات الرائدة وتواصل الواتساب');
              }}
              className={`p-3.5 rounded-xl border text-right transition flex items-start gap-3 cursor-pointer ${
                targetCategory === 'all'
                  ? 'border-emerald-600 bg-emerald-50/70 text-emerald-950 font-bold ring-1 ring-emerald-600'
                  : 'border-stone-200 hover:border-stone-300 text-stone-700'
              }`}
            >
              <div className={`p-2 rounded-lg ${targetCategory === 'all' ? 'bg-emerald-600 text-white' : 'bg-stone-100 text-stone-600'}`}>
                <Globe2 className="w-5 h-5" />
              </div>
              <div>
                <div className="text-sm font-bold">كلاهما معاً (بحث شامل)</div>
                <div className="text-xs text-stone-500 font-normal mt-0.5">
                  مدارس أهلية وشركات تجارية متنوعة
                </div>
              </div>
            </button>
          </div>
        </div>

        {/* Step 2: Country & City Selection */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-semibold text-stone-800 mb-1.5 flex items-center justify-between">
              <span>2. فلتر اختيار الدولة:</span>
              <button
                type="button"
                onClick={() => setIsCustomCountry(!isCustomCountry)}
                className="text-xs text-emerald-700 hover:underline cursor-pointer"
              >
                {isCustomCountry ? 'اختيار من القائمة' : 'كتابة دولة مخصصة'}
              </button>
            </label>

            {!isCustomCountry ? (
              <select
                value={selectedCountry}
                onChange={(e) => {
                  setSelectedCountry(e.target.value);
                  const found = COUNTRY_OPTIONS.find((c) => c.name === e.target.value);
                  if (found && found.defaultCities.length > 0) {
                    setSelectedCity(found.defaultCities[0]);
                  }
                }}
                className="w-full px-3.5 py-2.5 rounded-lg border border-stone-300 bg-white text-stone-900 text-sm focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
              >
                {COUNTRY_OPTIONS.map((c) => (
                  <option key={c.id} value={c.name}>
                    {c.name} ({c.code})
                  </option>
                ))}
              </select>
            ) : (
              <input
                type="text"
                value={customCountryName}
                onChange={(e) => setCustomCountryName(e.target.value)}
                placeholder="اكتب اسم أي دولة (مثلاً: تركيا، بريطانيا، ماليزيا، البحرين...)"
                className="w-full px-3.5 py-2.5 rounded-lg border border-stone-300 bg-white text-stone-900 text-sm focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
              />
            )}
          </div>

          <div>
            <label className="block text-sm font-semibold text-stone-800 mb-1.5">
              المدينة أو المنطقة (اختياري / مخصص):
            </label>
            <div className="flex gap-2">
              {!isCustomCountry && currentCountryObj && (
                <select
                  value={selectedCity}
                  onChange={(e) => setSelectedCity(e.target.value)}
                  className="w-1/2 px-3.5 py-2.5 rounded-lg border border-stone-300 bg-white text-stone-900 text-sm focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
                >
                  {currentCountryObj.defaultCities.map((city) => (
                    <option key={city} value={city}>
                      {city}
                    </option>
                  ))}
                </select>
              )}
              <input
                type="text"
                value={customCity}
                onChange={(e) => setCustomCity(e.target.value)}
                placeholder={!isCustomCountry && currentCountryObj ? 'أو اكتب مدينة مخصصة' : 'اسم المدينة'}
                className="flex-1 px-3.5 py-2.5 rounded-lg border border-stone-300 bg-white text-stone-900 text-sm focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
              />
            </div>
          </div>
        </div>

        {/* Step 3: Keywords */}
        <div>
          <label className="block text-sm font-semibold text-stone-800 mb-1.5">
            3. الكلمات المفتاحية للبحث:
          </label>
          <input
            type="text"
            value={keywords}
            onChange={(e) => setKeywords(e.target.value)}
            placeholder="مثال: مدارس أهلية ثانوية بنين وبنات، شركات برمجيات وتجارة دولية..."
            className="w-full px-3.5 py-2.5 rounded-lg border border-stone-300 bg-white text-stone-900 text-sm focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
          />
          {/* Quick Keywords Chips */}
          <div className="flex flex-wrap gap-2 mt-2">
            <span className="text-xs text-stone-500 self-center">اقتراحات سريعة:</span>
            {[
              'مدارس أهلية كبرى بنين وبنات',
              'مدارس دولية وبرامج لغات',
              'شركات قابضة وتجارية عالمية',
              'مجموعات استثمارية في الخليج',
              'شركات تقنية ورقمية رائدة',
            ].map((chip) => (
              <button
                key={chip}
                type="button"
                onClick={() => setKeywords(chip)}
                className="text-xs bg-stone-100 hover:bg-stone-200 text-stone-700 px-2.5 py-1 rounded-full cursor-pointer transition"
              >
                {chip}
              </button>
            ))}
          </div>
        </div>

        {/* Step 4: Options & Filtering */}
        <div className="pt-2 border-t border-stone-100 flex flex-wrap items-center justify-between gap-4">
          <div className="flex flex-wrap items-center gap-6">
            <label className="flex items-center gap-2 cursor-pointer text-sm text-stone-700 font-medium">
              <input
                type="checkbox"
                checked={filterInvalidAutomatically}
                onChange={(e) => setFilterInvalidAutomatically(e.target.checked)}
                className="w-4 h-4 text-emerald-600 rounded-sm border-stone-300 focus:ring-emerald-500"
              />
              <span className="flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                تصفية تلقائية: الاحتفاظ بأرقام الواتساب الصالحة والمتسقة فقط
              </span>
            </label>

            <div className="flex items-center gap-2 text-sm text-stone-700">
              <span>عدد النتائج المستهدفة:</span>
              <select
                value={resultCount}
                onChange={(e) => setResultCount(Number(e.target.value))}
                className="px-2 py-1 border border-stone-300 rounded-md text-sm bg-white"
              >
                <option value={5}>5 جهات</option>
                <option value={8}>8 جهات</option>
                <option value={12}>12 جهة</option>
                <option value={15}>15 جهة</option>
                <option value={20}>20 جهة</option>
              </select>
            </div>
          </div>

          <button
            type="button"
            onClick={handleRunSearch}
            disabled={isSearching}
            className={`px-6 py-2.5 rounded-lg text-sm font-bold text-white flex items-center gap-2 transition cursor-pointer shadow-sm ${
              isSearching
                ? 'bg-stone-400 cursor-not-allowed'
                : 'bg-emerald-600 hover:bg-emerald-700 active:scale-[0.98]'
            }`}
          >
            {isSearching ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>جاري البحث الذكي والتصفية...</span>
              </>
            ) : (
              <>
                <Search className="w-4 h-4" />
                <span>بدء التنقيب واستخراج الأرقام الآن</span>
              </>
            )}
          </button>
        </div>

        {/* Live Loading Progress Box */}
        {isSearching && (
          <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-4 text-emerald-900 text-sm flex items-center gap-3 animate-pulse">
            <Loader2 className="w-5 h-5 text-emerald-600 animate-spin shrink-0" />
            <div>
              <div className="font-bold">وكيل الذكاء الاصطناعي يبحث حالياً في محركات البحث...</div>
              <div className="text-xs text-emerald-700 mt-0.5">{searchStep}</div>
            </div>
          </div>
        )}

        {/* Error Alert */}
        {errorMessage && (
          <div className="bg-rose-50 border border-rose-200 rounded-xl p-4 text-rose-900 text-sm flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
            <div>
              <div className="font-bold">فشل البحث:</div>
              <div className="text-xs text-rose-700 mt-0.5">{errorMessage}</div>
            </div>
          </div>
        )}
      </div>

      {/* Fresh Search Results Preview */}
      {searchResults.length > 0 && (
        <div className="bg-white rounded-xl border border-stone-200 p-6 shadow-xs space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-stone-100">
            <div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                <h3 className="text-lg font-bold text-stone-900">
                  تم استخراج وتصفية {searchResults.length} جهة صالحة بنجاح!
                </h3>
              </div>
              <p className="text-xs text-stone-500 mt-0.5">
                تمت إضافة هذه السجلات مباشرة إلى قاعدة بياناتك، وتم توحيد أرقام الواتساب دولياً.
              </p>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => exportLeadsToExcel(searchResults, `نتائج_بحث_${selectedCountry}.xlsx`)}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 rounded-lg text-xs font-semibold border border-emerald-200 transition cursor-pointer"
              >
                <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" />
                تصدير النتائج Excel
              </button>
              <button
                type="button"
                onClick={() => exportLeadsToWord(searchResults, `نتائج_بحث_${selectedCountry}.doc`)}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-blue-50 hover:bg-blue-100 text-blue-800 rounded-lg text-xs font-semibold border border-blue-200 transition cursor-pointer"
              >
                <FileText className="w-3.5 h-3.5 text-blue-600" />
                تصدير النتائج Word
              </button>
              <button
                type="button"
                onClick={onNavigateToLeads}
                className="inline-flex items-center gap-1.5 px-3.5 py-1.5 bg-stone-900 hover:bg-stone-800 text-white rounded-lg text-xs font-semibold transition cursor-pointer"
              >
                <span>الانتقال لقاعدة البيانات والحملات</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {searchResults.map((lead) => (
              <div
                key={lead.id}
                className="p-3.5 rounded-lg border border-stone-200 bg-stone-50/50 hover:bg-stone-50 transition text-sm space-y-2"
              >
                <div className="flex items-start justify-between gap-2">
                  <span className="font-bold text-stone-900 line-clamp-1">{lead.name}</span>
                  <span className={`text-[10px] px-2 py-0.5 rounded-full font-semibold ${
                    lead.category === 'school' ? 'bg-blue-100 text-blue-800' : 'bg-amber-100 text-amber-800'
                  }`}>
                    {lead.categoryLabel}
                  </span>
                </div>

                <div className="text-xs text-stone-500">
                  📍 {lead.country} - {lead.city}
                </div>

                <div className="bg-white p-2 rounded-md border border-stone-200 text-xs space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="text-stone-500">الواتساب:</span>
                    <span className="font-mono font-bold text-emerald-700 dir-ltr">
                      {lead.whatsappNumber || 'غير متوفر'}
                    </span>
                  </div>
                  {lead.email && (
                    <div className="flex items-center justify-between">
                      <span className="text-stone-500">الإيميل:</span>
                      <span className="font-mono text-stone-700 truncate max-w-[170px] dir-ltr">
                        {lead.email}
                      </span>
                    </div>
                  )}
                </div>

                {lead.notes && (
                  <p className="text-[11px] text-stone-500 line-clamp-2">
                    {lead.notes}
                  </p>
                )}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
