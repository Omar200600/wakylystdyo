import React, { useState, useMemo } from 'react';
import {
  Search,
  Filter,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  FileSpreadsheet,
  FileText,
  Trash2,
  Send,
  Sparkles,
  Plus,
  ExternalLink,
  MessageCircle,
  School,
  Building2,
  ShieldCheck,
  CheckSquare,
  Square,
  ChevronDown,
  Download,
  Check,
} from 'lucide-react';
import { Lead, AgencyProfile } from '../types';
import { exportLeadsToExcel, exportLeadsToCSV, exportLeadsToWord } from '../utils/exportUtils';
import { cleanAndValidatePhone, generateWhatsAppChatUrl } from '../utils/phoneUtils';

interface LeadsTableProps {
  leads: Lead[];
  onUpdateLead: (updated: Lead) => void;
  onDeleteLead: (id: string) => void;
  onDeleteMultipleLeads: (ids: string[]) => void;
  onBulkCleanInvalid: () => void;
  onQueueForCampaign: (leadIds: string[]) => void;
  onOpenPitchModal: (lead: Lead) => void;
  onAddManualLead: (lead: Lead) => void;
  agencyProfile: AgencyProfile;
}

export const LeadsTable: React.FC<LeadsTableProps> = ({
  leads,
  onUpdateLead,
  onDeleteLead,
  onDeleteMultipleLeads,
  onBulkCleanInvalid,
  onQueueForCampaign,
  onOpenPitchModal,
  onAddManualLead,
  agencyProfile,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterValidity, setFilterValidity] = useState<'all' | 'valid' | 'invalid'>('all');
  const [filterCategory, setFilterCategory] = useState<'all' | 'school' | 'company'>('all');
  const [filterStatus, setFilterStatus] = useState<'all' | 'contacted' | 'new' | 'replied'>('all');
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [exportFeedback, setExportFeedback] = useState<string | null>(null);

  // Manual Add Modal State
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [manualName, setManualName] = useState('');
  const [manualCategory, setManualCategory] = useState<'school' | 'company'>('school');
  const [manualCountry, setManualCountry] = useState('المملكة العربية السعودية');
  const [manualCity, setManualCity] = useState('الرياض');
  const [manualPhone, setManualPhone] = useState('');
  const [manualEmail, setManualEmail] = useState('');
  const [manualNotes, setManualNotes] = useState('');

  // Filtering
  const filteredLeads = useMemo(() => {
    return leads.filter((lead) => {
      const matchesSearch =
        lead.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        lead.city.toLowerCase().includes(searchTerm.toLowerCase()) ||
        lead.whatsappNumber.includes(searchTerm) ||
        lead.email.toLowerCase().includes(searchTerm.toLowerCase());

      const matchesValidity =
        filterValidity === 'all'
          ? true
          : filterValidity === 'valid'
            ? lead.isWhatsappValid
            : !lead.isWhatsappValid;

      const matchesCategory =
        filterCategory === 'all' ? true : lead.category === filterCategory;

      const matchesStatus =
        filterStatus === 'all'
          ? true
          : filterStatus === 'contacted'
            ? lead.status === 'contacted' || lead.status === 'replied' || lead.status === 'converted'
            : filterStatus === 'new'
              ? lead.status === 'new'
              : lead.status === 'replied';

      return matchesSearch && matchesValidity && matchesCategory && matchesStatus;
    });
  }, [leads, searchTerm, filterValidity, filterCategory, filterStatus]);

  const validCount = leads.filter((l) => l.isWhatsappValid).length;
  const invalidCount = leads.filter((l) => !l.isWhatsappValid).length;

  const handleSelectAll = () => {
    if (selectedIds.size === filteredLeads.length) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(filteredLeads.map((l) => l.id)));
    }
  };

  const handleToggleSelect = (id: string) => {
    const next = new Set(selectedIds);
    if (next.has(id)) {
      next.delete(id);
    } else {
      next.add(id);
    }
    setSelectedIds(next);
  };

  const handleSelectValidOnly = () => {
    const validOnly = new Set(filteredLeads.filter((l) => l.isWhatsappValid).map((l) => l.id));
    setSelectedIds(validOnly);
  };

  const handleSaveManual = (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualName.trim() || !manualPhone.trim()) return;

    const validation = cleanAndValidatePhone(manualPhone, manualCountry);
    const newLead: Lead = {
      id: `manual_${Date.now()}`,
      name: manualName.trim(),
      category: manualCategory,
      categoryLabel: manualCategory === 'school' ? 'مدرسة أهلية' : 'شركة عالمية',
      country: manualCountry,
      city: manualCity.trim() || 'الرياض',
      rawPhone: manualPhone.trim(),
      whatsappNumber: validation.normalized,
      isWhatsappValid: validation.isValid,
      validationReason: validation.reason,
      email: manualEmail.trim(),
      isEmailValid: Boolean(manualEmail && manualEmail.includes('@')),
      website: '',
      notes: manualNotes.trim(),
      status: 'new',
    };

    onAddManualLead(newLead);
    setIsAddModalOpen(false);
    setManualName('');
    setManualPhone('');
    setManualEmail('');
    setManualNotes('');
  };

  return (
    <div className="space-y-4">
      {/* Top Metric Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="bg-white p-4 rounded-xl border border-stone-200 shadow-xs">
          <div className="text-xs text-stone-500 font-medium">إجمالي جهات الاتصال</div>
          <div className="text-2xl font-black text-stone-900 mt-1">{leads.length}</div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-emerald-200 bg-emerald-50/20 shadow-xs">
          <div className="text-xs text-emerald-800 font-medium flex items-center justify-between">
            <span>أرقام واتساب صالحة</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl font-black text-emerald-700 mt-1">{validCount}</div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-amber-200 bg-amber-50/20 shadow-xs">
          <div className="text-xs text-amber-800 font-medium flex items-center justify-between">
            <span>أرقام غير متسقة / تالفة</span>
            <AlertTriangle className="w-4 h-4 text-amber-600" />
          </div>
          <div className="text-2xl font-black text-amber-700 mt-1">{invalidCount}</div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-stone-200 shadow-xs">
          <div className="text-xs text-stone-500 font-medium">تم التواصل معهم</div>
          <div className="text-2xl font-black text-blue-700 mt-1">
            {leads.filter((l) => l.status === 'contacted' || l.status === 'replied').length}
          </div>
        </div>
      </div>

      {/* Action Toolbar */}
      <div className="bg-white rounded-xl border border-stone-200 p-4 shadow-xs space-y-3">
        <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
          {/* Search Input */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-stone-400 absolute right-3 top-3" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="بحث باسم المدرسة، الشركة، المدينة، أو رقم الهاتف..."
              className="w-full pr-9 pl-4 py-2 rounded-lg border border-stone-300 text-sm focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
            />
          </div>

          {/* Filter Selectors */}
          <div className="flex flex-wrap items-center gap-2">
            <select
              value={filterValidity}
              onChange={(e) => setFilterValidity(e.target.value as any)}
              className="px-3 py-2 rounded-lg border border-stone-300 text-xs bg-white text-stone-800"
            >
              <option value="all">كل الحالات (صالحة وغير صالحة)</option>
              <option value="valid">أرقام الواتساب الصالحة فقط ({validCount})</option>
              <option value="invalid">الأرقام غير الصالحة فقط ({invalidCount})</option>
            </select>

            <select
              value={filterCategory}
              onChange={(e) => setFilterCategory(e.target.value as any)}
              className="px-3 py-2 rounded-lg border border-stone-300 text-xs bg-white text-stone-800"
            >
              <option value="all">كل التصنيفات</option>
              <option value="school">المدارس الأهلية</option>
              <option value="company">الشركات العالمية</option>
            </select>

            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value as any)}
              className="px-3 py-2 rounded-lg border border-stone-300 text-xs bg-white text-stone-800"
            >
              <option value="all">كل حالات التواصل</option>
              <option value="contacted">تم التواصل معهم (سجل الحملات)</option>
              <option value="replied">تم الرد وتفاعلوا</option>
              <option value="new">جهات جديدة لم يتصل بها بعد</option>
            </select>
          </div>
        </div>

        {/* Bulk Action Buttons & Export Suite */}
        <div className="flex flex-wrap items-center justify-between gap-2 pt-3 border-t border-stone-100">
          <div className="flex flex-wrap items-center gap-2">
            {/* Clean invalid numbers button */}
            {invalidCount > 0 && (
              <button
                type="button"
                onClick={onBulkCleanInvalid}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-amber-50 hover:bg-amber-100 text-amber-900 rounded-lg text-xs font-bold border border-amber-300 transition cursor-pointer"
                title="حذف الأرقام غير الصالحة والاحتفاظ بالأرقام المتسقة فقط"
              >
                <ShieldCheck className="w-4 h-4 text-amber-700" />
                <span>تصفية وحذف الأرقام غير الصالحة ({invalidCount})</span>
              </button>
            )}

            {/* Queue selected for batch outreach */}
            <button
              type="button"
              disabled={selectedIds.size === 0}
              onClick={() => onQueueForCampaign(Array.from(selectedIds))}
              className={`inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                selectedIds.size > 0
                  ? 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-xs'
                  : 'bg-stone-100 text-stone-400 cursor-not-allowed'
              }`}
            >
              <Send className="w-3.5 h-3.5" />
              <span>إرسال بالدفعات للمحددين ({selectedIds.size})</span>
            </button>

            {selectedIds.size > 0 && (
              <button
                type="button"
                onClick={() => {
                  if (confirm(`هل أنت متأكد من حذف ${selectedIds.size} جهة محددة؟`)) {
                    onDeleteMultipleLeads(Array.from(selectedIds));
                    setSelectedIds(new Set());
                  }
                }}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-800 rounded-lg text-xs font-medium border border-rose-200 transition cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5 text-rose-600" />
                <span>حذف المحدد ({selectedIds.size})</span>
              </button>
            )}
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {/* Export to Excel (.xlsx) */}
            <button
              type="button"
              onClick={() => {
                const exportTarget = selectedIds.size > 0 ? leads.filter((l) => selectedIds.has(l.id)) : filteredLeads;
                if (exportTarget.length === 0) return;
                const filename = selectedIds.size > 0
                  ? `سجل_العملاء_المحدد_${new Date().toISOString().slice(0, 10)}.xlsx`
                  : `قائمة_العملاء_والنتائج_${new Date().toISOString().slice(0, 10)}.xlsx`;
                exportLeadsToExcel(exportTarget, filename);
                setExportFeedback(`تم تصدير ${exportTarget.length} سجل بنجاح إلى ملف Excel (.xlsx) محلي.`);
                setTimeout(() => setExportFeedback(null), 4000);
              }}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 rounded-lg text-xs font-bold border border-emerald-300 transition cursor-pointer shadow-2xs"
              title={selectedIds.size > 0 ? `تصدير ${selectedIds.size} جهة محددة إلى Excel` : 'تصدير القائمة الحالية إلى Excel'}
            >
              <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
              <span>تصدير Excel (.xlsx){selectedIds.size > 0 ? ` (${selectedIds.size})` : ''}</span>
            </button>

            {/* Export to CSV (.csv) */}
            <button
              type="button"
              onClick={() => {
                const exportTarget = selectedIds.size > 0 ? leads.filter((l) => selectedIds.has(l.id)) : filteredLeads;
                if (exportTarget.length === 0) return;
                const filename = selectedIds.size > 0
                  ? `سجل_العملاء_المحدد_${new Date().toISOString().slice(0, 10)}.csv`
                  : `قائمة_العملاء_والنتائج_${new Date().toISOString().slice(0, 10)}.csv`;
                exportLeadsToCSV(exportTarget, filename);
                setExportFeedback(`تم تصدير ${exportTarget.length} سجل بنجاح إلى ملف CSV محلي بترميز UTF-8 لدعم العربية.`);
                setTimeout(() => setExportFeedback(null), 4000);
              }}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-teal-50 hover:bg-teal-100 text-teal-800 rounded-lg text-xs font-bold border border-teal-300 transition cursor-pointer shadow-2xs"
              title={selectedIds.size > 0 ? `تصدير ${selectedIds.size} جهة محددة إلى CSV` : 'تصدير القائمة الحالية إلى CSV'}
            >
              <Download className="w-4 h-4 text-teal-600" />
              <span>تصدير CSV (.csv){selectedIds.size > 0 ? ` (${selectedIds.size})` : ''}</span>
            </button>

            {/* Export to Word (.doc) */}
            <button
              type="button"
              onClick={() => {
                const exportTarget = selectedIds.size > 0 ? leads.filter((l) => selectedIds.has(l.id)) : filteredLeads;
                if (exportTarget.length === 0) return;
                exportLeadsToWord(exportTarget);
                setExportFeedback(`تم تصدير التقرير الرسمي لـ ${exportTarget.length} جهة إلى ملف Word (.doc) بنجاح.`);
                setTimeout(() => setExportFeedback(null), 4000);
              }}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-blue-50 hover:bg-blue-100 text-blue-800 rounded-lg text-xs font-bold border border-blue-300 transition cursor-pointer"
            >
              <FileText className="w-4 h-4 text-blue-600" />
              <span>تقرير Word</span>
            </button>

            <button
              type="button"
              onClick={() => setIsAddModalOpen(true)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-stone-900 hover:bg-stone-800 text-white rounded-lg text-xs font-bold transition cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>إضافة جهة</span>
            </button>
          </div>
        </div>

        {/* Export Notification Banner */}
        {exportFeedback && (
          <div className="bg-emerald-50 border border-emerald-300 text-emerald-900 px-4 py-2.5 rounded-lg text-xs flex items-center justify-between transition">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span className="font-bold">{exportFeedback}</span>
            </div>
            <button
              type="button"
              onClick={() => setExportFeedback(null)}
              className="text-emerald-700 hover:text-emerald-900 font-bold px-2 cursor-pointer"
            >
              ✕
            </button>
          </div>
        )}
      </div>

      {/* Main Table */}
      <div className="bg-white rounded-xl border border-stone-200 overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-right border-collapse">
            <thead>
              <tr className="bg-stone-50/80 border-b border-stone-200 text-stone-600 text-xs font-semibold">
                <th className="py-3 px-4 w-10 text-center">
                  <button
                    type="button"
                    onClick={handleSelectAll}
                    className="cursor-pointer text-stone-600 hover:text-stone-900"
                  >
                    {selectedIds.size === filteredLeads.length && filteredLeads.length > 0 ? (
                      <CheckSquare className="w-4 h-4 text-emerald-600" />
                    ) : (
                      <Square className="w-4 h-4 text-stone-400" />
                    )}
                  </button>
                </th>
                <th className="py-3 px-4">اسم المنشأة / المدرسة</th>
                <th className="py-3 px-3">التصنيف</th>
                <th className="py-3 px-3">الدولة والمدينة</th>
                <th className="py-3 px-4">رقم الواتساب المتسق</th>
                <th className="py-3 px-3">صلاحية الرقم</th>
                <th className="py-3 px-3">البريد الإلكتروني</th>
                <th className="py-3 px-3">الحالة</th>
                <th className="py-3 px-4 text-center">الإجراءات السريعة</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-200 text-xs">
              {filteredLeads.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-12 text-center text-stone-500">
                    <p className="text-sm font-medium">لا توجد جهات اتصال مطابقة للمعايير المحددة.</p>
                    <p className="text-xs text-stone-400 mt-1">
                      يمكنك استخدام تبويب "البحث والتنقيب الذكي" لجلب مدارس وشركات جديدة من محركات البحث.
                    </p>
                  </td>
                </tr>
              ) : (
                filteredLeads.map((lead) => {
                  const isSelected = selectedIds.has(lead.id);
                  const isSchool = lead.category === 'school';

                  return (
                    <tr
                      key={lead.id}
                      className={`hover:bg-stone-50/70 transition ${
                        isSelected ? 'bg-emerald-50/40' : ''
                      }`}
                    >
                      {/* Checkbox */}
                      <td className="py-3 px-4 text-center">
                        <input
                          type="checkbox"
                          checked={isSelected}
                          onChange={() => handleToggleSelect(lead.id)}
                          className="w-4 h-4 text-emerald-600 rounded-sm border-stone-300 focus:ring-emerald-500 cursor-pointer"
                        />
                      </td>

                      {/* Name */}
                      <td className="py-3 px-4 font-bold text-stone-900 max-w-[220px]">
                        <div className="flex items-center gap-2">
                          <div className={`p-1.5 rounded-md ${isSchool ? 'bg-blue-50 text-blue-700' : 'bg-amber-50 text-amber-700'}`}>
                            {isSchool ? <School className="w-3.5 h-3.5" /> : <Building2 className="w-3.5 h-3.5" />}
                          </div>
                          <div>
                            <div className="truncate">{lead.name}</div>
                            {lead.website && (
                              <a
                                href={lead.website}
                                target="_blank"
                                rel="noreferrer"
                                className="text-[10px] text-stone-400 hover:text-emerald-700 flex items-center gap-1 mt-0.5"
                              >
                                <ExternalLink className="w-2.5 h-2.5" />
                                <span className="truncate max-w-[120px]">{lead.website.replace(/^https?:\/\//, '')}</span>
                              </a>
                            )}
                          </div>
                        </div>
                      </td>

                      {/* Category */}
                      <td className="py-3 px-3">
                        <span className={`px-2 py-0.5 rounded-full text-[11px] font-semibold ${
                          isSchool ? 'bg-blue-50 text-blue-800' : 'bg-amber-50 text-amber-800'
                        }`}>
                          {lead.categoryLabel || (isSchool ? 'مدرسة أهلية' : 'شركة عالمية')}
                        </span>
                      </td>

                      {/* Location */}
                      <td className="py-3 px-3 text-stone-600 whitespace-nowrap">
                        <div>{lead.city}</div>
                        <div className="text-[10px] text-stone-400">{lead.country}</div>
                      </td>

                      {/* WhatsApp Phone */}
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-1.5">
                          <span className="font-mono font-bold text-stone-800 dir-ltr text-xs">
                            {lead.whatsappNumber || lead.rawPhone || 'غير متوفر'}
                          </span>
                        </div>
                        {lead.rawPhone && lead.rawPhone !== lead.whatsappNumber && (
                          <div className="text-[10px] text-stone-400 font-mono dir-ltr">
                            أصلي: {lead.rawPhone}
                          </div>
                        )}
                      </td>

                      {/* Validity Badge */}
                      <td className="py-3 px-3 whitespace-nowrap">
                        {lead.isWhatsappValid ? (
                          <span
                            className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-800 font-medium text-[11px] border border-emerald-200"
                            title={lead.validationReason}
                          >
                            <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                            صالح للواتساب
                          </span>
                        ) : (
                          <span
                            className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-rose-50 text-rose-800 font-medium text-[11px] border border-rose-200"
                            title={lead.validationReason}
                          >
                            <XCircle className="w-3 h-3 text-rose-600" />
                            غير صالح
                          </span>
                        )}
                      </td>

                      {/* Email */}
                      <td className="py-3 px-3 text-stone-600 max-w-[150px]">
                        {lead.email ? (
                          <span className="font-mono text-xs dir-ltr block truncate" title={lead.email}>
                            {lead.email}
                          </span>
                        ) : (
                          <span className="text-stone-300">-</span>
                        )}
                      </td>

                      {/* Status */}
                      <td className="py-3 px-3 whitespace-nowrap">
                        <select
                          value={lead.status}
                          onChange={(e) =>
                            onUpdateLead({ ...lead, status: e.target.value as any })
                          }
                          className="text-[11px] py-1 px-2 border border-stone-200 rounded-md bg-white font-medium"
                        >
                          <option value="new">جديد</option>
                          <option value="in_queue">في دُفعة الإرسال</option>
                          <option value="contacted">تم التواصل</option>
                          <option value="replied">تم الرد</option>
                          <option value="converted">صفقة ناجحة</option>
                          <option value="skipped">مستبعد</option>
                        </select>
                      </td>

                      {/* Actions */}
                      <td className="py-3 px-4 text-center whitespace-nowrap">
                        <div className="flex items-center justify-center gap-1.5">
                          {/* Direct WhatsApp button */}
                          {lead.isWhatsappValid && (
                            <a
                              href={generateWhatsAppChatUrl(
                                lead.whatsappNumber,
                                `السلام عليكم ورحمة الله وبركاته، تحية طيبة لإدارة ${lead.name} الموقرة. يسر وكالتنا تقديم خدماتها المتخصصة لكم.`
                              )}
                              target="_blank"
                              rel="noreferrer"
                              className="p-1.5 rounded-md bg-emerald-50 text-emerald-700 hover:bg-emerald-600 hover:text-white transition"
                              title="فتح محادثة واتساب فورية"
                            >
                              <MessageCircle className="w-4 h-4" />
                            </a>
                          )}

                          {/* AI Custom Proposal / Pitch button */}
                          <button
                            type="button"
                            onClick={() => onOpenPitchModal(lead)}
                            className="p-1.5 rounded-md bg-purple-50 text-purple-700 hover:bg-purple-600 hover:text-white transition cursor-pointer"
                            title="صياغة رسالة إعلان وعرض أعمال مخصص بالذكاء الاصطناعي"
                          >
                            <Sparkles className="w-4 h-4" />
                          </button>

                          {/* Delete */}
                          <button
                            type="button"
                            onClick={() => onDeleteLead(lead.id)}
                            className="p-1.5 rounded-md text-stone-400 hover:text-rose-600 hover:bg-rose-50 transition cursor-pointer"
                            title="حذف"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Manual Lead Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 bg-stone-900/40 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-xl border border-stone-200">
            <h3 className="text-lg font-bold text-stone-900 mb-3">
              إضافة جهة اتصال جديدة يدوياً
            </h3>
            <form onSubmit={handleSaveManual} className="space-y-4 text-sm">
              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">
                  اسم المنشأة أو المدرسة:
                </label>
                <input
                  type="text"
                  required
                  value={manualName}
                  onChange={(e) => setManualName(e.target.value)}
                  placeholder="مثال: مدارس التربية النموذجية"
                  className="w-full px-3 py-2 border border-stone-300 rounded-lg text-sm"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    التصنيف:
                  </label>
                  <select
                    value={manualCategory}
                    onChange={(e) => setManualCategory(e.target.value as any)}
                    className="w-full px-3 py-2 border border-stone-300 rounded-lg text-sm bg-white"
                  >
                    <option value="school">مدرسة أهلية / دولية</option>
                    <option value="company">شركة عالمية / تجارية</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    الدولة:
                  </label>
                  <input
                    type="text"
                    value={manualCountry}
                    onChange={(e) => setManualCountry(e.target.value)}
                    className="w-full px-3 py-2 border border-stone-300 rounded-lg text-sm"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    المدينة:
                  </label>
                  <input
                    type="text"
                    value={manualCity}
                    onChange={(e) => setManualCity(e.target.value)}
                    className="w-full px-3 py-2 border border-stone-300 rounded-lg text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    رقم الواتساب:
                  </label>
                  <input
                    type="text"
                    required
                    value={manualPhone}
                    onChange={(e) => setManualPhone(e.target.value)}
                    placeholder="مثال: 0501234567 أو +966..."
                    className="w-full px-3 py-2 border border-stone-300 rounded-lg text-sm dir-ltr text-right"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">
                  البريد الإلكتروني (اختياري):
                </label>
                <input
                  type="email"
                  value={manualEmail}
                  onChange={(e) => setManualEmail(e.target.value)}
                  placeholder="info@example.com"
                  className="w-full px-3 py-2 border border-stone-300 rounded-lg text-sm dir-ltr text-right"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">
                  ملاحظات أو تفاصيل إضافية:
                </label>
                <textarea
                  value={manualNotes}
                  onChange={(e) => setManualNotes(e.target.value)}
                  rows={2}
                  className="w-full px-3 py-2 border border-stone-300 rounded-lg text-sm"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 border border-stone-300 rounded-lg text-stone-700 hover:bg-stone-50 cursor-pointer"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-lg cursor-pointer"
                >
                  حفظ وتدقيق الرقم
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
