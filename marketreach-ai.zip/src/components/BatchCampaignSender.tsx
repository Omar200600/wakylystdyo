import React, { useState, useEffect } from 'react';
import {
  Send,
  Sparkles,
  Layers,
  Clock,
  CheckCircle2,
  AlertCircle,
  Pause,
  Play,
  RotateCcw,
  MessageCircle,
  ExternalLink,
  Users,
  Copy,
  Check,
  Edit3,
  Bot,
  ShieldAlert,
  FileSpreadsheet,
  Download,
  History,
  Trash2,
  FileText,
} from 'lucide-react';
import { Lead, AgencyProfile, CampaignLogEntry, MessageTemplate } from '../types';
import { generateWhatsAppChatUrl } from '../utils/phoneUtils';
import { exportCampaignResultsToExcel, exportCampaignResultsToCSV } from '../utils/exportUtils';

interface BatchCampaignSenderProps {
  leads: Lead[];
  agencyProfile: AgencyProfile;
  preSelectedLeadIds?: string[];
  onMarkLeadsContacted: (leadIds: string[]) => void;
  templates?: MessageTemplate[];
  initialMessage?: string;
}

export const BatchCampaignSender: React.FC<BatchCampaignSenderProps> = ({
  leads,
  agencyProfile,
  preSelectedLeadIds = [],
  onMarkLeadsContacted,
  templates = [],
  initialMessage,
}) => {
  // Only valid WhatsApp leads can be contacted
  const validLeads = leads.filter((l) => l.isWhatsappValid);

  // Selected Target Leads
  const [selectedTargetIds, setSelectedTargetIds] = useState<string[]>(
    preSelectedLeadIds.length > 0 ? preSelectedLeadIds : validLeads.map((l) => l.id)
  );

  // Message Composition Mode
  const [composerMode, setComposerMode] = useState<'manual' | 'ai'>('ai');
  const [messageTemplate, setMessageTemplate] = useState(
    initialMessage ||
      agencyProfile.customAdCopy ||
      `السلام عليكم ورحمة الله وبركاته،
تحية طيبة لإدارة {اسم_الجهة} الموقرة،
يسعدنا في ${agencyProfile.agencyName || 'وكالتنا'} أن نعرض عليكم خدماتنا المخصصة في مجال الحلول الرقمية والتسويقية وأتمتة التواصل عبر الواتساب.
لقد حققنا نجاحات ملموسة في تطوير الأعمال ورفع معدلات التسجيل والإقبال.
يسرنا تقديم استشارة مجانية وعرض أعمالنا التفصيلي لكم.
للتواصل المباشر عبر الواتساب: ${agencyProfile.myWhatsapp || '00667737219181'}`
  );

  // Update message if initialMessage changes
  useEffect(() => {
    if (initialMessage) {
      setMessageTemplate(initialMessage);
    }
  }, [initialMessage]);

  // AI Pitch Generation State
  const [isGeneratingAiPitch, setIsGeneratingAiPitch] = useState(false);
  const [aiPitchTone, setAiPitchTone] = useState<'persuasive' | 'executive' | 'friendly'>('persuasive');

  // Batch Configuration
  const [batchSize, setBatchSize] = useState<number>(5);
  const [delaySeconds, setDelaySeconds] = useState<number>(4);

  // Batch Execution Engine State
  const [isCampaignRunning, setIsCampaignRunning] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [currentLeadIndex, setCurrentLeadIndex] = useState(0);
  const [sentLeadIds, setSentLeadIds] = useState<string[]>([]);
  const [countdown, setCountdown] = useState<number>(0);
  const [copiedSuccess, setCopiedSuccess] = useState(false);
  const [exportFeedback, setExportFeedback] = useState<string | null>(null);

  // Campaign History & Results Log (Persisted locally)
  const [campaignLogs, setCampaignLogs] = useState<CampaignLogEntry[]>(() => {
    try {
      const saved = localStorage.getItem('agency_campaign_logs');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error('Failed to load campaign logs', e);
    }
    // Pre-populate with existing contacted leads if logs are empty
    const contacted = leads.filter((l) => l.status === 'contacted' || l.status === 'replied');
    if (contacted.length > 0) {
      return contacted.map((l) => ({
        id: `log_init_${l.id}`,
        leadId: l.id,
        leadName: l.name,
        category: l.category,
        categoryLabel: l.categoryLabel || (l.category === 'school' ? 'مدرسة أهلية' : 'شركة عالمية'),
        country: l.country,
        city: l.city,
        phone: l.whatsappNumber,
        messageSent: l.customPitch || `عرض أعمال وتسويق مرسل من ${agencyProfile.agencyName || 'وكالتنا'}`,
        status: 'sent' as const,
        sentAt: l.lastContactedAt ? new Date(l.lastContactedAt).toLocaleString('ar-SA') : 'سجل سابق',
        agencyWhatsapp: agencyProfile.myWhatsapp || '00667737219181',
      }));
    }
    return [];
  });

  // Save campaign logs to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('agency_campaign_logs', JSON.stringify(campaignLogs));
    } catch (e) {
      console.error('Failed to save campaign logs', e);
    }
  }, [campaignLogs]);

  // Synchronize if preSelectedLeadIds change
  useEffect(() => {
    if (preSelectedLeadIds.length > 0) {
      setSelectedTargetIds(preSelectedLeadIds);
    }
  }, [preSelectedLeadIds]);

  const targetLeadsList = validLeads.filter((l) => selectedTargetIds.includes(l.id));

  // Current lead being processed in batch
  const currentLead = targetLeadsList[currentLeadIndex];

  // Format message for a specific lead
  const formatMessageForLead = (template: string, lead?: Lead) => {
    if (!lead) return template;
    return template
      .replace(/{اسم_الجهة}/g, lead.name)
      .replace(/{المدينة}/g, lead.city || 'مدينتكم')
      .replace(/{النوع}/g, lead.categoryLabel || (lead.category === 'school' ? 'المدرسة' : 'الشركة'))
      .replace(/{رقم_الواتس}/g, agencyProfile.myWhatsapp || '00667737219181');
  };

  // Generate AI Pitch / Ad using Agency Profile
  const handleGenerateAiPitch = async () => {
    setIsGeneratingAiPitch(true);
    try {
      const sampleLead = targetLeadsList[0] || {
        name: '{اسم_الجهة}',
        categoryLabel: 'مدرسة أهلية / شركة عالمية',
        city: '{المدينة}',
        country: 'الخليج والعالم العربي',
      };

      const res = await fetch('/api/leads/pitch', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          lead: sampleLead,
          agencyProfile,
          tone: aiPitchTone,
        }),
      });
      const data = await res.json();
      if (data.success && data.pitch) {
        setMessageTemplate(data.pitch);
      }
    } catch (err) {
      console.error('Failed to generate pitch', err);
    } finally {
      setIsGeneratingAiPitch(false);
    }
  };

  // Batch Runner Timer Effect
  useEffect(() => {
    let timer: any;
    if (isCampaignRunning && !isPaused && currentLeadIndex < targetLeadsList.length) {
      if (countdown > 0) {
        timer = setTimeout(() => {
          setCountdown((prev) => prev - 1);
        }, 1000);
      }
    }
    return () => clearTimeout(timer);
  }, [isCampaignRunning, isPaused, countdown, currentLeadIndex, targetLeadsList.length]);

  const handleStartCampaign = () => {
    if (targetLeadsList.length === 0) return;
    setIsCampaignRunning(true);
    setIsPaused(false);
    setCurrentLeadIndex(0);
    setSentLeadIds([]);
    setCountdown(0);
  };

  const handleSendCurrentAndNext = () => {
    if (!currentLead) return;

    // Mark as sent
    const newSent = [...sentLeadIds, currentLead.id];
    setSentLeadIds(newSent);
    onMarkLeadsContacted([currentLead.id]);

    const msg = formatMessageForLead(messageTemplate, currentLead);

    // Record in campaign logs
    const logItem: CampaignLogEntry = {
      id: `log_${Date.now()}_${currentLead.id}`,
      leadId: currentLead.id,
      leadName: currentLead.name,
      category: currentLead.category,
      categoryLabel: currentLead.categoryLabel || (currentLead.category === 'school' ? 'مدرسة أهلية' : 'شركة عالمية'),
      country: currentLead.country,
      city: currentLead.city,
      phone: currentLead.whatsappNumber,
      messageSent: msg,
      status: 'sent',
      sentAt: new Date().toLocaleString('ar-SA'),
      agencyWhatsapp: agencyProfile.myWhatsapp || '00667737219181',
    };
    setCampaignLogs((prev) => [logItem, ...prev.filter((p) => p.leadId !== currentLead.id)]);

    // Open WhatsApp Web with personalized text
    const url = generateWhatsAppChatUrl(currentLead.whatsappNumber, msg);
    window.open(url, '_blank');

    // Advance to next lead or finish
    const nextIndex = currentLeadIndex + 1;
    if (nextIndex < targetLeadsList.length) {
      setCurrentLeadIndex(nextIndex);
      // Check if we hit a batch boundary, add slight pause
      if (nextIndex % batchSize === 0) {
        setCountdown(delaySeconds + 3);
      } else {
        setCountdown(delaySeconds);
      }
    } else {
      setIsCampaignRunning(false);
    }
  };

  const handleSkipCurrent = () => {
    if (currentLead) {
      const skipItem: CampaignLogEntry = {
        id: `log_skip_${Date.now()}_${currentLead.id}`,
        leadId: currentLead.id,
        leadName: currentLead.name,
        category: currentLead.category,
        categoryLabel: currentLead.categoryLabel || (currentLead.category === 'school' ? 'مدرسة أهلية' : 'شركة عالمية'),
        country: currentLead.country,
        city: currentLead.city,
        phone: currentLead.whatsappNumber,
        messageSent: '(تم التخطي بدون إرسال)',
        status: 'skipped',
        sentAt: new Date().toLocaleString('ar-SA'),
        agencyWhatsapp: agencyProfile.myWhatsapp || '00667737219181',
      };
      setCampaignLogs((prev) => [skipItem, ...prev.filter((p) => p.leadId !== currentLead.id)]);
    }

    const nextIndex = currentLeadIndex + 1;
    if (nextIndex < targetLeadsList.length) {
      setCurrentLeadIndex(nextIndex);
      setCountdown(1);
    } else {
      setIsCampaignRunning(false);
    }
  };

  const handleCopyMessage = () => {
    navigator.clipboard.writeText(formatMessageForLead(messageTemplate, currentLead || targetLeadsList[0]));
    setCopiedSuccess(true);
    setTimeout(() => setCopiedSuccess(false), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white rounded-xl border border-stone-200 p-6 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-50 text-emerald-800 text-xs font-semibold mb-2">
              <Layers className="w-3.5 h-3.5" />
              نظام إرسال الإعلانات على شكل دفعات (Batch Outreach)
            </div>
            <h2 className="text-xl font-bold text-stone-900">
              إرسال عروض الأعمال والحملات التسويقية بالدفعات
            </h2>
            <p className="text-sm text-stone-600 mt-1 max-w-3xl">
              اكتب رسالتك الإعلانية أو دع الذكاء الاصطناعي يصيغها نيابة عنك بناءً على نشاط وسابقة أعمال وكالتك، ثم أرسلها للمدارس والشركات على شكل دفعات مجدولة مع فواصل زمنية آمنة لحماية رقمك.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <div className="text-left bg-stone-50 border border-stone-200 rounded-lg px-4 py-2 text-xs">
              <div className="text-stone-500">الجهات الصالحة الجاهزة للإرسال:</div>
              <div className="text-base font-black text-emerald-700 font-mono">
                {targetLeadsList.length} من أصل {validLeads.length}
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Composer & AI Pitch Writer */}
        <div className="lg:col-span-7 space-y-4">
          <div className="bg-white rounded-xl border border-stone-200 p-5 shadow-xs space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-stone-100 pb-3 gap-2">
              <h3 className="text-sm font-bold text-stone-900 flex items-center gap-2">
                <Edit3 className="w-4 h-4 text-emerald-600" />
                صياغة الرسالة الإعلانية وعرض الأعمال
              </h3>

              <div className="flex flex-wrap items-center gap-2">
                {/* Template Quick Loader Dropdown */}
                {templates.length > 0 && (
                  <div className="flex items-center gap-1 text-xs">
                    <FileText className="w-3.5 h-3.5 text-purple-600 shrink-0" />
                    <select
                      onChange={(e) => {
                        const selectedTpl = templates.find((t) => t.id === e.target.value);
                        if (selectedTpl) {
                          setMessageTemplate(selectedTpl.content);
                        }
                      }}
                      defaultValue=""
                      className="text-xs bg-purple-50 text-purple-900 border border-purple-200 rounded-md px-2 py-1 font-medium max-w-[200px] truncate"
                    >
                      <option value="" disabled>
                        تحميل قالب جاهز من المكتبة...
                      </option>
                      {templates.map((tpl) => (
                        <option key={tpl.id} value={tpl.id}>
                          {tpl.title} ({tpl.categoryLabel})
                        </option>
                      ))}
                    </select>
                  </div>
                )}

                {/* Mode Toggle */}
                <div className="flex items-center bg-stone-100 p-1 rounded-lg text-xs font-semibold">
                  <button
                    type="button"
                    onClick={() => setComposerMode('ai')}
                    className={`px-3 py-1 rounded-md transition cursor-pointer flex items-center gap-1.5 ${
                      composerMode === 'ai'
                        ? 'bg-white text-emerald-800 shadow-xs'
                        : 'text-stone-600 hover:text-stone-900'
                    }`}
                  >
                    <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
                    صياغة ذكية
                  </button>
                  <button
                    type="button"
                    onClick={() => setComposerMode('manual')}
                    className={`px-3 py-1 rounded-md transition cursor-pointer ${
                      composerMode === 'manual'
                        ? 'bg-white text-stone-900 shadow-xs'
                        : 'text-stone-600 hover:text-stone-900'
                    }`}
                  >
                    كتابة يدوية
                  </button>
                </div>
              </div>
            </div>

            {/* AI Pitch Assistant Bar */}
            {composerMode === 'ai' && (
              <div className="p-3.5 rounded-xl bg-purple-50/70 border border-purple-200 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-xs font-bold text-purple-900">
                    <Bot className="w-4 h-4 text-purple-600" />
                    توليد إعلان ذكي استناداً إلى بيانات وكالتك وسابقة أعمالك:
                  </div>
                  <select
                    value={aiPitchTone}
                    onChange={(e) => setAiPitchTone(e.target.value as any)}
                    className="text-xs bg-white border border-purple-300 rounded-md px-2 py-1 text-purple-900"
                  >
                    <option value="persuasive">نبرة إقناع تسويقي (موصى بها)</option>
                    <option value="executive">نبرة رسمية وتنفيذية</option>
                    <option value="friendly">نبرة ودية ومباشرة</option>
                  </select>
                </div>

                <div className="flex items-center justify-between gap-3">
                  <span className="text-[11px] text-purple-800">
                    سيتم تضمين رقم الواتساب المعتمد ({agencyProfile.myWhatsapp || '00667737219181'}) وعرض القيمة المضافة.
                  </span>
                  <button
                    type="button"
                    onClick={handleGenerateAiPitch}
                    disabled={isGeneratingAiPitch}
                    className="px-3.5 py-1.5 bg-purple-700 hover:bg-purple-800 active:scale-95 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 cursor-pointer transition shadow-xs shrink-0"
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>{isGeneratingAiPitch ? 'جاري الصياغة...' : 'توليد نص إعلاني فوري'}</span>
                  </button>
                </div>
              </div>
            )}

            {/* Message Textarea */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-semibold text-stone-700">
                  نص الرسالة الموجهة للجهات:
                </label>
                <div className="flex items-center gap-1">
                  <span className="text-[11px] text-stone-400">متغيرات ديناميكية:</span>
                  {['{اسم_الجهة}', '{المدينة}', '{النوع}', '{رقم_الواتس}'].map((tag) => (
                    <button
                      key={tag}
                      type="button"
                      onClick={() => setMessageTemplate((prev) => prev + ' ' + tag)}
                      className="text-[10px] bg-stone-100 hover:bg-stone-200 text-stone-700 px-1.5 py-0.5 rounded cursor-pointer font-mono"
                    >
                      {tag}
                    </button>
                  ))}
                </div>
              </div>

              <textarea
                value={messageTemplate}
                onChange={(e) => setMessageTemplate(e.target.value)}
                rows={9}
                className="w-full p-3.5 border border-stone-300 rounded-xl text-sm leading-relaxed focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                placeholder="اكتب هنا الرسالة الإعلانية أو عرض أعمال وكالتك..."
              />
            </div>

            {/* Copy Button */}
            <div className="flex items-center justify-between text-xs text-stone-500">
              <span>طول النص: {messageTemplate.length} حرف</span>
              <button
                type="button"
                onClick={handleCopyMessage}
                className="inline-flex items-center gap-1 text-emerald-700 hover:underline cursor-pointer"
              >
                {copiedSuccess ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedSuccess ? 'تم النسخ!' : 'نسخ نص النموذج'}</span>
              </button>
            </div>
          </div>

          {/* Batch Settings Card */}
          <div className="bg-white rounded-xl border border-stone-200 p-5 shadow-xs space-y-4">
            <h3 className="text-sm font-bold text-stone-900 flex items-center gap-2">
              <Layers className="w-4 h-4 text-emerald-600" />
              إعدادات الإرسال على دفعات (Batch Scheduling)
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div>
                <label className="block font-semibold text-stone-700 mb-1">
                  حجم كل دفعة (عدد الجهات لكل إرسال):
                </label>
                <select
                  value={batchSize}
                  onChange={(e) => setBatchSize(Number(e.target.value))}
                  className="w-full p-2.5 border border-stone-300 rounded-lg bg-white text-stone-900 font-medium"
                >
                  <option value={3}>3 جهات بكل دفعة (فائق الأمان)</option>
                  <option value={5}>5 جهات بكل دفعة (موصى به)</option>
                  <option value={10}>10 جهات بكل دفعة</option>
                  <option value={15}>15 جهة بكل دفعة</option>
                </select>
                <p className="text-[11px] text-stone-400 mt-1">
                  تقسيم الإرسال إلى دفعات يحمي حساب الواتساب من القيود.
                </p>
              </div>

              <div>
                <label className="block font-semibold text-stone-700 mb-1">
                  الفاصل الزمني التلقائي بين الرسائل:
                </label>
                <select
                  value={delaySeconds}
                  onChange={(e) => setDelaySeconds(Number(e.target.value))}
                  className="w-full p-2.5 border border-stone-300 rounded-lg bg-white text-stone-900 font-medium"
                >
                  <option value={3}>3 ثوانٍ</option>
                  <option value={5}>5 ثوانٍ (متوازن)</option>
                  <option value={8}>8 ثوانٍ</option>
                  <option value={12}>12 ثانية (حماية قصوى)</option>
                </select>
                <p className="text-[11px] text-stone-400 mt-1">
                  مهلة بين كل جهة وأخرى لتفادي اعتباره سلوكاً آلياً.
                </p>
              </div>
            </div>

            {/* Target Audience Checkboxes */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="font-semibold text-stone-700 text-xs">
                  الجهات المستهدفة المحددة ({targetLeadsList.length} جهة):
                </span>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setSelectedTargetIds(validLeads.map((l) => l.id))}
                    className="text-[11px] text-emerald-700 hover:underline cursor-pointer"
                  >
                    تحديد الكل
                  </button>
                  <span className="text-stone-300">|</span>
                  <button
                    type="button"
                    onClick={() => setSelectedTargetIds([])}
                    className="text-[11px] text-stone-500 hover:underline cursor-pointer"
                  >
                    إلغاء التحديد
                  </button>
                </div>
              </div>

              <div className="max-h-40 overflow-y-auto border border-stone-200 rounded-lg p-2 space-y-1.5 divide-y divide-stone-100">
                {validLeads.map((l) => {
                  const isChecked = selectedTargetIds.includes(l.id);
                  return (
                    <label
                      key={l.id}
                      className="flex items-center justify-between text-xs pt-1.5 first:pt-0 cursor-pointer hover:bg-stone-50 px-1.5 py-1 rounded"
                    >
                      <div className="flex items-center gap-2">
                        <input
                          type="checkbox"
                          checked={isChecked}
                          onChange={(e) => {
                            if (e.target.checked) {
                              setSelectedTargetIds([...selectedTargetIds, l.id]);
                            } else {
                              setSelectedTargetIds(selectedTargetIds.filter((id) => id !== l.id));
                            }
                          }}
                          className="w-3.5 h-3.5 text-emerald-600 rounded-xs"
                        />
                        <span className="font-medium text-stone-900">{l.name}</span>
                        <span className="text-[10px] text-stone-400">({l.city})</span>
                      </div>
                      <span className="font-mono text-emerald-700 dir-ltr text-[11px]">
                        {l.whatsappNumber}
                      </span>
                    </label>
                  );
                })}
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Live WhatsApp Preview & Campaign Runner */}
        <div className="lg:col-span-5 space-y-4">
          {/* WhatsApp Preview Mockup */}
          <div className="bg-emerald-900 rounded-2xl p-4 text-white shadow-md">
            <div className="flex items-center justify-between border-b border-emerald-800/80 pb-3 mb-3">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-emerald-700 flex items-center justify-center">
                  <MessageCircle className="w-4 h-4 text-white" />
                </div>
                <div>
                  <div className="text-xs font-bold">
                    {currentLead ? currentLead.name : (targetLeadsList[0]?.name || 'المدرسة المستهدفة')}
                  </div>
                  <div className="text-[10px] text-emerald-300">
                    رقم الواتساب: {currentLead ? currentLead.whatsappNumber : (targetLeadsList[0]?.whatsappNumber || '+96650...')}
                  </div>
                </div>
              </div>
              <span className="text-[10px] bg-emerald-800 text-emerald-200 px-2 py-0.5 rounded-full">
                معاينة مباشرة
              </span>
            </div>

            {/* Chat Bubble */}
            <div className="bg-emerald-800/90 rounded-xl p-3.5 text-xs text-stone-100 space-y-2 border border-emerald-700/50 leading-relaxed max-h-72 overflow-y-auto whitespace-pre-line">
              {formatMessageForLead(messageTemplate, currentLead || targetLeadsList[0])}
            </div>

            <div className="mt-3 pt-2 border-t border-emerald-800/50 flex items-center justify-between text-[11px] text-emerald-300">
              <span>المرسل: {agencyProfile.agencyName}</span>
              <span className="font-mono dir-ltr">{agencyProfile.myWhatsapp || '00667737219181'}</span>
            </div>
          </div>

          {/* Active Batch Control Card */}
          <div className="bg-white rounded-xl border border-stone-200 p-5 shadow-xs space-y-4">
            <h3 className="text-sm font-bold text-stone-900 flex items-center justify-between">
              <span>منصة الإرسال والتحكم بالدفعات</span>
              {isCampaignRunning && (
                <span className="text-xs bg-amber-100 text-amber-900 font-bold px-2 py-0.5 rounded-full flex items-center gap-1 animate-pulse">
                  <Clock className="w-3 h-3" />
                  جاري تشغيل الدفعة
                </span>
              )}
            </h3>

            {/* Progress Bar */}
            <div>
              <div className="flex items-center justify-between text-xs text-stone-600 mb-1.5">
                <span>التقدم الإجمالي:</span>
                <span className="font-bold font-mono">
                  {sentLeadIds.length} من {targetLeadsList.length} تم إرسالها
                </span>
              </div>
              <div className="w-full h-2.5 bg-stone-100 rounded-full overflow-hidden">
                <div
                  className="h-full bg-emerald-600 transition-all duration-300 rounded-full"
                  style={{
                    width: `${
                      targetLeadsList.length > 0
                        ? (sentLeadIds.length / targetLeadsList.length) * 100
                        : 0
                    }%`,
                  }}
                />
              </div>
            </div>

            {/* Batch Status Info */}
            {isCampaignRunning ? (
              <div className="p-4 rounded-xl bg-stone-50 border border-stone-200 space-y-3">
                <div className="flex items-start justify-between">
                  <div>
                    <span className="text-[10px] text-stone-400 font-bold uppercase">
                      الجهة الحالية (رقم {currentLeadIndex + 1}):
                    </span>
                    <div className="font-bold text-stone-900 text-sm">{currentLead?.name}</div>
                    <div className="text-xs text-stone-500 font-mono dir-ltr mt-0.5">
                      {currentLead?.whatsappNumber} • {currentLead?.city}
                    </div>
                  </div>
                  {countdown > 0 && (
                    <div className="text-center px-3 py-1 bg-amber-50 border border-amber-200 rounded-lg">
                      <div className="text-[10px] text-amber-800">فاصل أمان:</div>
                      <div className="text-lg font-black text-amber-700 font-mono">{countdown} ث</div>
                    </div>
                  )}
                </div>

                <div className="flex items-center gap-2 pt-2">
                  <button
                    type="button"
                    onClick={handleSendCurrentAndNext}
                    className="flex-1 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 transition cursor-pointer shadow-xs"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>إرسال عبر الواتساب والانتقال للتالي</span>
                  </button>
                  <button
                    type="button"
                    onClick={handleSkipCurrent}
                    className="px-3 py-2 bg-stone-200 hover:bg-stone-300 text-stone-700 rounded-lg text-xs font-medium transition cursor-pointer"
                  >
                    تخطي
                  </button>
                </div>
              </div>
            ) : (
              <div className="text-center py-6 space-y-3">
                <div className="w-12 h-12 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center mx-auto">
                  <Send className="w-6 h-6" />
                </div>
                <div>
                  <div className="text-sm font-bold text-stone-900">
                    جاهز لبدء إرسال الدفعات
                  </div>
                  <div className="text-xs text-stone-500 mt-1 max-w-xs mx-auto">
                    سيتم فتح محادثات الواتساب تلقائياً برسالتك المخصصة واسم كل مدرسة أو شركة.
                  </div>
                </div>

                <button
                  type="button"
                  disabled={targetLeadsList.length === 0}
                  onClick={handleStartCampaign}
                  className={`w-full py-2.5 rounded-xl text-sm font-bold text-white transition flex items-center justify-center gap-2 cursor-pointer shadow-sm ${
                    targetLeadsList.length > 0
                      ? 'bg-emerald-600 hover:bg-emerald-700 active:scale-[0.98]'
                      : 'bg-stone-300 cursor-not-allowed'
                  }`}
                >
                  <Play className="w-4 h-4" />
                  <span>بدء إرسال الحملة بالدفعات الآن ({targetLeadsList.length} جهة)</span>
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Campaign Results & History Export Suite */}
      <div className="bg-white rounded-xl border border-stone-200 p-5 shadow-xs space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-stone-100 pb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center border border-emerald-200">
              <History className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-stone-900">
                سجل نتائج الحملات والتصدير الخارجي
              </h3>
              <p className="text-xs text-stone-500">
                سجل تفصيلي بكافة عمليات الإرسال والتواصل الإعلاني للاحتفاظ بنسخة محلية خارج التطبيق بصيغة Excel أو CSV.
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {/* Export Results to Excel */}
            <button
              type="button"
              disabled={campaignLogs.length === 0}
              onClick={() => {
                if (campaignLogs.length === 0) return;
                const filename = `تقرير_نتائج_الحملات_التسويقية_${new Date().toISOString().slice(0, 10)}.xlsx`;
                exportCampaignResultsToExcel(campaignLogs, agencyProfile, filename);
                setExportFeedback(`تم تصدير نتائج وسجل الحملة (${campaignLogs.length} سجل) إلى ملف Excel (.xlsx) بنجاح.`);
                setTimeout(() => setExportFeedback(null), 4000);
              }}
              className={`inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-xs font-bold transition shadow-2xs ${
                campaignLogs.length > 0
                  ? 'bg-emerald-600 hover:bg-emerald-700 text-white cursor-pointer'
                  : 'bg-stone-100 text-stone-400 cursor-not-allowed'
              }`}
            >
              <FileSpreadsheet className="w-4 h-4" />
              <span>تصدير نتائج الحملة إلى Excel (.xlsx)</span>
            </button>

            {/* Export Results to CSV */}
            <button
              type="button"
              disabled={campaignLogs.length === 0}
              onClick={() => {
                if (campaignLogs.length === 0) return;
                const filename = `تقرير_نتائج_الحملات_التسويقية_${new Date().toISOString().slice(0, 10)}.csv`;
                exportCampaignResultsToCSV(campaignLogs, agencyProfile, filename);
                setExportFeedback(`تم تصدير نتائج وسجل الحملة (${campaignLogs.length} سجل) إلى ملف CSV (.csv) بترميز UTF-8 المتوافق مع العربية.`);
                setTimeout(() => setExportFeedback(null), 4000);
              }}
              className={`inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-xs font-bold transition shadow-2xs border ${
                campaignLogs.length > 0
                  ? 'bg-teal-50 hover:bg-teal-100 text-teal-800 border-teal-300 cursor-pointer'
                  : 'bg-stone-100 text-stone-400 border-stone-200 cursor-not-allowed'
              }`}
            >
              <Download className="w-4 h-4 text-teal-600" />
              <span>تصدير نتائج الحملة إلى CSV (.csv)</span>
            </button>

            {campaignLogs.length > 0 && (
              <button
                type="button"
                onClick={() => {
                  if (confirm('هل ترغب في مسح سجل نتائج الحملات الحالي؟')) {
                    setCampaignLogs([]);
                  }
                }}
                className="inline-flex items-center gap-1 px-2.5 py-2 bg-stone-50 hover:bg-rose-50 text-stone-600 hover:text-rose-700 rounded-lg text-xs transition border border-stone-200 hover:border-rose-200 cursor-pointer"
                title="مسح سجل النتائج"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>مسح السجل</span>
              </button>
            )}
          </div>
        </div>

        {/* Feedback Banner */}
        {exportFeedback && (
          <div className="bg-emerald-50 border border-emerald-300 text-emerald-900 px-4 py-2.5 rounded-lg text-xs flex items-center justify-between transition">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span className="font-bold">{exportFeedback}</span>
            </div>
            <button
              type="button"
              onClick={() => setExportFeedback(null)}
              className="text-emerald-700 hover:text-emerald-900 font-bold px-2 cursor-pointer"
            >
              ✕
            </button>
          </div>
        )}

        {/* Results Summary Stats */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <div className="bg-stone-50 p-3 rounded-lg border border-stone-200">
            <div className="text-[11px] text-stone-500">إجمالي سجلات الحملة</div>
            <div className="text-xl font-black text-stone-900 mt-0.5">{campaignLogs.length}</div>
          </div>
          <div className="bg-emerald-50/40 p-3 rounded-lg border border-emerald-200">
            <div className="text-[11px] text-emerald-800">تم إرسال الإعلان لهم</div>
            <div className="text-xl font-black text-emerald-700 mt-0.5">
              {campaignLogs.filter((l) => l.status === 'sent').length}
            </div>
          </div>
          <div className="bg-stone-50 p-3 rounded-lg border border-stone-200">
            <div className="text-[11px] text-stone-500">تم التخطي</div>
            <div className="text-xl font-black text-stone-600 mt-0.5">
              {campaignLogs.filter((l) => l.status === 'skipped').length}
            </div>
          </div>
          <div className="bg-stone-50 p-3 rounded-lg border border-stone-200">
            <div className="text-[11px] text-stone-500">رقم الواتساب المستخدم</div>
            <div className="text-xs font-mono font-bold text-stone-800 mt-1 dir-ltr text-right truncate">
              {agencyProfile.myWhatsapp || '00667737219181'}
            </div>
          </div>
        </div>

        {/* Results Table */}
        {campaignLogs.length > 0 ? (
          <div className="border border-stone-200 rounded-lg overflow-hidden">
            <div className="overflow-x-auto max-h-72">
              <table className="w-full text-right text-xs border-collapse">
                <thead className="bg-stone-50 sticky top-0 border-b border-stone-200 text-stone-600 font-semibold">
                  <tr>
                    <th className="py-2.5 px-3">الجهة المستهدفة</th>
                    <th className="py-2.5 px-3">المدينة والدولة</th>
                    <th className="py-2.5 px-3">رقم الواتساب</th>
                    <th className="py-2.5 px-3">حالة الإرسال</th>
                    <th className="py-2.5 px-3">تاريخ ووقت الإرسال</th>
                    <th className="py-2.5 px-3">الرسالة المرسلة</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100">
                  {campaignLogs.map((entry) => (
                    <tr key={entry.id} className="hover:bg-stone-50/50">
                      <td className="py-2.5 px-3 font-bold text-stone-900">{entry.leadName}</td>
                      <td className="py-2.5 px-3 text-stone-600">
                        {entry.city} - {entry.country}
                      </td>
                      <td className="py-2.5 px-3 font-mono dir-ltr text-right text-emerald-800 font-medium">
                        {entry.phone}
                      </td>
                      <td className="py-2.5 px-3">
                        {entry.status === 'sent' ? (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800">
                            <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                            تم الإرسال
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-stone-100 text-stone-600">
                            تم التخطي
                          </span>
                        )}
                      </td>
                      <td className="py-2.5 px-3 text-stone-500 whitespace-nowrap">{entry.sentAt}</td>
                      <td className="py-2.5 px-3 text-stone-600 max-w-xs truncate" title={entry.messageSent}>
                        {entry.messageSent}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        ) : (
          <div className="text-center py-6 bg-stone-50 rounded-lg border border-dashed border-stone-200">
            <History className="w-8 h-8 text-stone-300 mx-auto mb-2" />
            <div className="text-xs font-bold text-stone-700">لا توجد سجلات حملات مرسلة حالياً</div>
            <div className="text-[11px] text-stone-500 mt-0.5">
              عند إرسال الرسائل بالدفعات، ستسجل هنا كافة التفاصيل تلقائياً لتتمكن من تصديرها بضغطة زر إلى Excel أو CSV.
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
