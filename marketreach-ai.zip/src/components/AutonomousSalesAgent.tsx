import React, { useState } from 'react';
import {
  Bot,
  Send,
  Sparkles,
  Link,
  DollarSign,
  FileText,
  CheckCircle2,
  Clock,
  MessageSquare,
  Building2,
  GraduationCap,
  TrendingUp,
  AlertCircle,
  Phone,
  RefreshCw,
  Copy,
  Check,
  Printer,
  Download,
  Filter,
  ArrowRight,
  ShieldAlert,
  ChevronDown,
  ChevronUp,
  Zap,
  Sliders,
} from 'lucide-react';
import { AgencyProfile, Lead, PricingConfig } from '../types';
import { generateWhatsAppChatUrl } from '../utils/phoneUtils';

interface AutonomousSalesAgentProps {
  leads: Lead[];
  agencyProfile: AgencyProfile;
  onSaveProfile: (profile: AgencyProfile) => void;
  onUpdateLead: (lead: Lead) => void;
  onBatchUpdateLeads: (leads: Lead[]) => void;
  onNavigateToCampaigns: (initialMessage?: string) => void;
}

export const AutonomousSalesAgent: React.FC<AutonomousSalesAgentProps> = ({
  leads,
  agencyProfile,
  onSaveProfile,
  onUpdateLead,
  onBatchUpdateLeads,
  onNavigateToCampaigns,
}) => {
  // Local profile & announcement states
  const [formUrl, setFormUrl] = useState(
    agencyProfile.agencyFormUrl || 'https://agency-portal.com/join-schools-companies'
  );
  const [adAnnouncement, setAdAnnouncement] = useState(
    agencyProfile.agencyAdAnnouncement ||
      `📢 إعلان وشراكة استراتيجية للمدارس الأهلية والشركات الكبرى:
السلام عليكم ورحمة الله وبركاته، تحية تقدير لإدارة {اسم_الجهة} الموقرة في {المدينة}،
يسر {اسم_الوكالة} أن تعلن عن فتح باب الانضمام والشراكة الرقمية لتزويدكم بأحدث حلول الأتمتة المؤسسية والذكاء الاصطناعي:
✨ مميزات الانضمام:
1. روبوتات واتساب ذكية مخصصة لخدمة أولياء الأمور والعملاء 24/7 دون انقطاع.
2. بوابات رقمية متطورة لزيادة المبيعات وتسجيل الطلاب الجدد.
3. خيارات مرنة وميسرة تناسب ميزانيتكم: (شراء رخصة بيع كاملة وملكية دائمة، أو استئجار سحابي شهري/سنوي ميسر).

📋 للانضمام وتعبئة نموذج تسجيل الرغبات وحجز الباقة:
{رابط_النموذج}

📞 للتواصل والاستفسار المباشر مع استشاري الحلول عبر الواتساب:
{رقم_الواتس}`
  );

  // Pricing configuration state
  const [pricing, setPricing] = useState<PricingConfig>(
    agencyProfile.pricingConfig || {
      salePrice: 15000,
      saleTitle: 'شراء رخصة ملكية كاملة للنظام وحلول الواتساب مع التدريب والدعم الفني لسنة',
      leasePriceMonthly: 1200,
      leasePriceAnnual: 10800,
      leaseTitle: 'استئجار واشتراك دوري (شهري / سنوي) شامل الاستضافة والصيانة والتحديثات',
      currency: 'ريال',
      discountMargin: 15,
    }
  );

  const [showPricingSettings, setShowPricingSettings] = useState(false);
  const [isSavedBanner, setIsSavedBanner] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  const [copiedAd, setCopiedAd] = useState(false);

  // Negotiation & Deal Management States
  const [dealFilter, setDealFilter] = useState<'all' | 'ad_sent' | 'negotiating' | 'closed_sale' | 'closed_lease' | 'form_submitted'>('all');
  const [selectedLeadForNegotiation, setSelectedLeadForNegotiation] = useState<Lead | null>(null);
  const [customNegotiationInput, setCustomNegotiationInput] = useState('');
  const [isNegotiatingAI, setIsNegotiatingAI] = useState(false);
  const [negotiationResult, setNegotiationResult] = useState<any | null>(null);
  const [isBulkNegotiating, setIsBulkNegotiating] = useState(false);
  const [bulkNegotiationProgress, setBulkNegotiationProgress] = useState<{ current: number; total: number } | null>(null);

  // Executive Closing Report States ("موافاتي بتقرير عن ما تم وماحصل")
  const [showExecutiveReportModal, setShowExecutiveReportModal] = useState(false);
  const [isGeneratingReport, setIsGeneratingReport] = useState(false);
  const [executiveReportContent, setExecutiveReportContent] = useState<string>('');
  const [reportMetrics, setReportMetrics] = useState<any>(null);
  const [copiedReport, setCopiedReport] = useState(false);

  // Calculated Metrics
  const totalLeads = leads.length;
  const validWhatsAppLeads = leads.filter((l) => l.isWhatsappValid).length;
  const adSentCount = leads.filter((l) => l.dealStage === 'ad_sent' || l.status === 'contacted' || l.status === 'replied' || l.status === 'converted').length;
  const repliedCount = leads.filter((l) => l.status === 'replied' || l.status === 'converted' || l.replyText).length;
  const negotiatingCount = leads.filter((l) => l.dealStage === 'negotiating' || l.dealStage === 'pricing_offered').length;
  const closedSaleCount = leads.filter((l) => l.dealStage === 'closed_sale' || (l.dealType === 'sale' && l.status === 'converted')).length;
  const closedLeaseCount = leads.filter((l) => l.dealStage === 'closed_lease' || (l.dealType === 'lease' && l.status === 'converted')).length;
  const formSubmittedCount = leads.filter((l) => l.formSubmitted).length;

  const totalClosedRevenue = leads.reduce((acc, lead) => {
    if (lead.dealAmount && (lead.dealStage === 'closed_sale' || lead.dealStage === 'closed_lease' || lead.status === 'converted')) {
      return acc + Number(lead.dealAmount);
    }
    return acc;
  }, 0);

  // Save changes to profile
  const handleSaveProfileAndAd = () => {
    const updated: AgencyProfile = {
      ...agencyProfile,
      agencyFormUrl: formUrl,
      agencyAdAnnouncement: adAnnouncement,
      pricingConfig: pricing,
    };
    onSaveProfile(updated);
    setIsSavedBanner(true);
    setTimeout(() => setIsSavedBanner(false), 3500);
  };

  // Insert variable in ad copy
  const insertVariable = (tag: string) => {
    setAdAnnouncement((prev) => prev + ' ' + tag);
  };

  // Quick Preset Handlers
  const handleSelectPreset = (type: 'schools' | 'companies' | 'promotion') => {
    if (type === 'schools') {
      setAdAnnouncement(`📢 إعلان رسمي وشراكة استراتيجية للمدارس الأهلية والدولية:
السلام عليكم ورحمة الله وبركاته، تحية تقدير لإدارة {اسم_الجهة} الموقرة في {المدينة}،
معكم {اسم_الوكالة} المتخصصة في التحول الرقمي وحلول التعليم الذكي.
يسعدنا فتح باب الانضمام للشراكة السنوية لتزويد مدارسكم بـ:
1. روبوت واتساب ذكي مخصص للرد الفوري على استفسارات أولياء الأمور ورسوم التسجيل 24/7.
2. بوابة رقمية متكاملة لزيادة استقطاب وقبول الطلاب الجدد وخفض أعباء الكادر الإداري.
3. خيارات مرنة: شراء رخصة بيع كاملة وملكية دائمة، أو استئجار سنوي سحابي ميسر مع صيانة ودعم شامل.

📋 لتعبئة نموذج طلب الانضمام وحجز موعد العرض التجريبي:
{رابط_النموذج}

📞 للتواصل المباشر مع استشاري الحلول عبر الواتساب:
{رقم_الواتس}`);
    } else if (type === 'companies') {
      setAdAnnouncement(`📢 إعلان حلول الأتمتة المؤسسية والذكاء الاصطناعي (B2B):
تحية طيبة لإدارة التطوير والأعمال في {اسم_الجهة} الموقرة،
يسر {اسم_الوكالة} تقديم منظومة الأتمتة الذكية لرفع كفاءة العمليات وخفض تكاليف خدمة العملاء:
• ربط أنظمة المحادثات والواتساب المؤسسي (Cloud API) بالذكاء الاصطناعي التوليدي.
• حلول توليد وتأهيل العملاء وإغلاق الصفقات آلياً.
• باقات شراء وتملّك مباشر للأنظمة، أو استئجار وتشغيل سحابي شهري/سنوي مرن.

📋 للاطلاع وتعبئة نموذج التسجيل والشراكة المؤسسية:
{رابط_النموذج}

📞 للتواصل والتنسيق المباشر:
{رقم_الواتس}`);
    } else {
      setAdAnnouncement(`🔥 عرض خاص وحصري بمناسبة إطلاق باقات الشراكة الرقمية:
السلام عليكم ورحمة الله وبركاته، إدارة {اسم_الجهة} الكريمة،
تقدم لكم {اسم_الوكالة} خصماً تشجيعياً بنسبة 15% على باقات الأتمتة والذكاء الاصطناعي:
✨ اختر ما يناسبكم:
- باقة البيع والتملك الدائم (Perpetual License) مع تدريب شامل لسنة.
- باقة الاستئجار السحابي (SaaS Rental) الميسرة مع استضافة وصيانة مجانية.

📋 سارع بتعبئة نموذج حجز العرض الخاص والانضمام:
{رابط_النموذج}

📞 للمحادثة الفورية وتأكيد طلبكم عبر الواتساب:
{رقم_الواتس}`);
    }
  };

  // Launch Batch Broadcast of Ad
  const handleLaunchAnnouncementCampaign = () => {
    handleSaveProfileAndAd();
    // Prepare personalized message replacing {رابط_النموذج} with actual formUrl
    const personalizedTemplate = adAnnouncement.replace(/{رابط_النموذج}/g, formUrl);
    onNavigateToCampaigns(personalizedTemplate);
  };

  // Run AI Sales Negotiation on a single lead
  const handleRunNegotiationForLead = async (lead: Lead, customMsg?: string) => {
    setSelectedLeadForNegotiation(lead);
    setIsNegotiatingAI(true);
    setNegotiationResult(null);

    try {
      const incomingText = customMsg || lead.replyText || 'مرحباً، وصلتنا رسالتكم بخصوص باقات الأتمتة، ما هي الأسعار وطريقة الانضمام وما هو خيار البيع أو الاستئجار؟';

      const res = await fetch('/api/agency/negotiate-sale', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          lead,
          incomingMessage: incomingText,
          agencyProfile: {
            ...agencyProfile,
            agencyFormUrl: formUrl,
            agencyAdAnnouncement: adAnnouncement,
          },
          pricingConfig: pricing,
        }),
      });

      const json = await res.json();
      if (json.success && json.data) {
        setNegotiationResult(json.data);

        // Update lead with new negotiation outcome
        const updatedLead: Lead = {
          ...lead,
          dealStage: json.data.dealStage || 'negotiating',
          dealType: json.data.dealType || 'both',
          dealAmount: json.data.quotedAmount || lead.dealAmount || (json.data.dealType === 'lease' ? pricing.leasePriceAnnual : pricing.salePrice),
          dealTerms: json.data.dealSummary || lead.dealTerms,
          dealNotes: json.data.recommendedAction || lead.dealNotes,
          status: json.data.dealStage === 'closed_sale' || json.data.dealStage === 'closed_lease' ? 'converted' : 'replied',
        };
        onUpdateLead(updatedLead);
      }
    } catch (err) {
      console.error('Negotiation error:', err);
    } finally {
      setIsNegotiatingAI(false);
    }
  };

  // Batch Auto-Negotiation across all leads with replies
  const handleRunBatchAutoNegotiation = async () => {
    const candidates = leads.filter(
      (l) => (l.status === 'replied' || l.replyText) && l.dealStage !== 'closed_sale' && l.dealStage !== 'closed_lease'
    );

    if (candidates.length === 0) {
      alert('لا توجد استفسارات أو ردود غير مغلقة حالياً للتفاوض عليها.');
      return;
    }

    setIsBulkNegotiating(true);
    setBulkNegotiationProgress({ current: 0, total: candidates.length });

    const updatedLeads = [...leads];

    for (let i = 0; i < candidates.length; i++) {
      const candidate = candidates[i];
      setBulkNegotiationProgress({ current: i + 1, total: candidates.length });

      try {
        const res = await fetch('/api/agency/negotiate-sale', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            lead: candidate,
            incomingMessage: candidate.replyText || 'نود معرفة الأسعار وخيارات البيع والاستئجار ورابط التسجيل.',
            agencyProfile: {
              ...agencyProfile,
              agencyFormUrl: formUrl,
              agencyAdAnnouncement: adAnnouncement,
            },
            pricingConfig: pricing,
          }),
        });

        const json = await res.json();
        if (json.success && json.data) {
          const index = updatedLeads.findIndex((l) => l.id === candidate.id);
          if (index !== -1) {
            updatedLeads[index] = {
              ...updatedLeads[index],
              dealStage: json.data.dealStage || 'negotiating',
              dealType: json.data.dealType || 'both',
              dealAmount: json.data.quotedAmount || (json.data.dealType === 'lease' ? pricing.leasePriceAnnual : pricing.salePrice),
              dealTerms: json.data.dealSummary || updatedLeads[index].dealTerms,
              dealNotes: json.data.recommendedAction || updatedLeads[index].dealNotes,
              status: json.data.dealStage === 'closed_sale' || json.data.dealStage === 'closed_lease' ? 'converted' : 'replied',
            };
          }
        }
      } catch (err) {
        console.error('Batch negotiation item error:', err);
      }
      // Small polite delay
      await new Promise((r) => setTimeout(r, 600));
    }

    onBatchUpdateLeads(updatedLeads);
    setIsBulkNegotiating(false);
    setBulkNegotiationProgress(null);
    alert(`اكتملت جولة التفاوض الآلي بنجاح على ${candidates.length} جهة، وتم طرح الأسعار وتحديث مراحل الصفقات.`);
  };

  // Generate Executive Progress & Closing Report ("موافاتي بتقرير عن ما تم وماحصل")
  const handleGenerateExecutiveReport = async () => {
    setShowExecutiveReportModal(true);
    setIsGeneratingReport(true);
    setExecutiveReportContent('');

    try {
      const res = await fetch('/api/agency/generate-executive-report', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          leads,
          agencyProfile: {
            ...agencyProfile,
            agencyFormUrl: formUrl,
            agencyAdAnnouncement: adAnnouncement,
          },
          pricingConfig: pricing,
        }),
      });

      const json = await res.json();
      if (json.success && json.reportMarkdown) {
        setExecutiveReportContent(json.reportMarkdown);
        setReportMetrics(json.metrics);
      } else {
        setExecutiveReportContent('تعذر توليد التقرير في الوقت الحالي، يرجى المحاولة مجدداً.');
      }
    } catch (err) {
      console.error('Report error:', err);
      setExecutiveReportContent('حدث خطأ في الاتصال أثناء إعداد التقرير.');
    } finally {
      setIsGeneratingReport(false);
    }
  };

  // Fast manual stage update
  const handleSetDealStage = (lead: Lead, stage: Lead['dealStage'], type?: Lead['dealType'], amount?: number) => {
    const updated: Lead = {
      ...lead,
      dealStage: stage,
      dealType: type || lead.dealType,
      dealAmount: amount !== undefined ? amount : lead.dealAmount,
      status: stage === 'closed_sale' || stage === 'closed_lease' ? 'converted' : lead.status,
    };
    onUpdateLead(updated);
  };

  // Toggle Form Submission
  const handleToggleFormSubmitted = (lead: Lead) => {
    const updated: Lead = {
      ...lead,
      formSubmitted: !lead.formSubmitted,
    };
    onUpdateLead(updated);
  };

  // Filtered Leads
  const filteredLeads = leads.filter((lead) => {
    if (dealFilter === 'ad_sent') return lead.dealStage === 'ad_sent' || lead.status === 'contacted';
    if (dealFilter === 'negotiating') return lead.dealStage === 'negotiating' || lead.dealStage === 'pricing_offered';
    if (dealFilter === 'closed_sale') return lead.dealStage === 'closed_sale' || (lead.dealType === 'sale' && lead.status === 'converted');
    if (dealFilter === 'closed_lease') return lead.dealStage === 'closed_lease' || (lead.dealType === 'lease' && lead.status === 'converted');
    if (dealFilter === 'form_submitted') return lead.formSubmitted;
    return true;
  });

  return (
    <div className="space-y-6">
      {/* Top Banner & Quick Trigger for the Executive Report */}
      <div className="bg-gradient-to-r from-emerald-800 via-emerald-700 to-teal-800 rounded-2xl p-6 text-white shadow-md relative overflow-hidden">
        <div className="absolute -left-10 -bottom-10 w-48 h-48 bg-white/10 rounded-full blur-2xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="space-y-1.5 max-w-2xl">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-900/50 border border-emerald-500/40 text-xs font-semibold text-emerald-200">
              <Zap className="w-3.5 h-3.5 text-amber-300" />
              <span>وكيل المبيعات الآلي وإغلاق الصفقات (البيع والاستئجار)</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black tracking-tight">
              إرسال الإعلان ورابط الانضمام، الرد والتفاوض على الأسعار، وإتمام الصفقات
            </h2>
            <p className="text-xs sm:text-sm text-emerald-100 leading-relaxed">
              يتولى الوكيل إرسال إعلان الوكالة ورابط نموذج التسجيل للمدارس والشركات، ثم الرد الفوري، وطرح خيارات الأسعار (بيع ملكية كاملة أو استئجار سحابي دوري)، حتى إتمام الصفقة وموافاتك بتقرير تنفيذي كامل عما تم وما حصل.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5 w-full md:w-auto shrink-0">
            <button
              onClick={handleGenerateExecutiveReport}
              className="px-5 py-3 bg-amber-400 hover:bg-amber-300 text-stone-900 font-extrabold rounded-xl text-sm flex items-center justify-center gap-2 shadow-lg transition active:scale-95 cursor-pointer"
            >
              <FileText className="w-4 h-4 text-stone-950" />
              <span>📄 موافاتي بتقرير عن ما تم وما حصل</span>
            </button>
            <button
              onClick={handleLaunchAnnouncementCampaign}
              className="px-4 py-3 bg-white/15 hover:bg-white/25 text-white font-bold rounded-xl text-sm flex items-center justify-center gap-2 border border-white/20 transition active:scale-95 cursor-pointer"
            >
              <Send className="w-4 h-4" />
              <span>إطلاق إرسال الإعلان</span>
            </button>
          </div>
        </div>

        {/* Live Metrics Strip */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 mt-6 pt-5 border-t border-white/15 text-center">
          <div className="bg-white/10 backdrop-blur-xs rounded-xl p-2.5 border border-white/10">
            <div className="text-[11px] text-emerald-200">الجهات المستهدفة</div>
            <div className="text-lg font-black">{totalLeads}</div>
          </div>
          <div className="bg-white/10 backdrop-blur-xs rounded-xl p-2.5 border border-white/10">
            <div className="text-[11px] text-emerald-200">استلموا الإعلان والرابط</div>
            <div className="text-lg font-black">{adSentCount}</div>
          </div>
          <div className="bg-white/10 backdrop-blur-xs rounded-xl p-2.5 border border-white/10">
            <div className="text-[11px] text-emerald-200">تفاعلوا وردّوا</div>
            <div className="text-lg font-black text-amber-300">{repliedCount}</div>
          </div>
          <div className="bg-white/10 backdrop-blur-xs rounded-xl p-2.5 border border-white/10">
            <div className="text-[11px] text-emerald-200">صفقات بيع كامل</div>
            <div className="text-lg font-black text-emerald-300">{closedSaleCount}</div>
          </div>
          <div className="bg-white/10 backdrop-blur-xs rounded-xl p-2.5 border border-white/10">
            <div className="text-[11px] text-emerald-200">صفقات استئجار دوري</div>
            <div className="text-lg font-black text-cyan-300">{closedLeaseCount}</div>
          </div>
          <div className="bg-emerald-950/40 rounded-xl p-2.5 border border-emerald-400/30">
            <div className="text-[11px] text-emerald-200">قيمة العقود المغلقة</div>
            <div className="text-lg font-black text-emerald-300">{totalClosedRevenue.toLocaleString()} {pricing.currency}</div>
          </div>
        </div>
      </div>

      {/* Main Grid: Ad Copy & Form Box (Left/Top) + Pricing Strategy (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column (7 Cols): The Dedicated Ad Copy & Form Link Box requested by User */}
        <div className="lg:col-span-7 space-y-4">
          <div className="bg-white rounded-2xl border border-stone-200 p-5 shadow-xs space-y-4">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center">
                  <Link className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-stone-900">
                    خانة لصق رسالة الإعلان عن الوكالة ورابط نموذج الانضمام
                  </h3>
                  <p className="text-[11px] text-stone-500">
                    الصق رسالة إعلان وكالتك ورابطك ليتسنى للمدارس والشركات تعبئة النموذج والانضمام
                  </p>
                </div>
              </div>

              {isSavedBanner && (
                <span className="text-xs bg-emerald-100 text-emerald-800 px-2.5 py-1 rounded-full font-bold flex items-center gap-1">
                  <Check className="w-3.5 h-3.5" />
                  تم الحفظ والتطبيق!
                </span>
              )}
            </div>

            {/* Field 1: Agency Form Link / Landing URL */}
            <div className="space-y-1.5">
              <label className="block text-xs font-bold text-stone-800 flex items-center justify-between">
                <span className="flex items-center gap-1.5">
                  <Link className="w-3.5 h-3.5 text-emerald-600" />
                  رابط وكالتي / نموذج تسجيل وانضمام المدارس والشركات:
                </span>
                <span className="text-[10px] text-stone-400 font-normal">
                  يحل تلقائياً محل المتغير {'{رابط_النموذج}'}
                </span>
              </label>
              <div className="flex items-center gap-2">
                <input
                  type="url"
                  value={formUrl}
                  onChange={(e) => setFormUrl(e.target.value)}
                  placeholder="https://agency-portal.com/join-schools-companies أو رابط Google Forms"
                  className="flex-1 px-3.5 py-2.5 border border-stone-300 rounded-xl text-xs font-mono font-medium dir-ltr text-right focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                />
                <button
                  type="button"
                  onClick={() => {
                    navigator.clipboard.writeText(formUrl);
                    setCopiedLink(true);
                    setTimeout(() => setCopiedLink(false), 2000);
                  }}
                  className="px-3 py-2.5 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer"
                  title="نسخ الرابط"
                >
                  {copiedLink ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedLink ? 'تم النسخ' : 'نسخ'}</span>
                </button>
              </div>
            </div>

            {/* Quick Presets for Ad Copy */}
            <div className="flex flex-wrap items-center gap-1.5 text-xs pt-1">
              <span className="text-stone-400 text-[11px] font-medium">قوالب إعلانية جاهزة برابط الانضمام:</span>
              <button
                type="button"
                onClick={() => handleSelectPreset('schools')}
                className="px-2.5 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 rounded-lg text-[11px] font-semibold transition cursor-pointer flex items-center gap-1"
              >
                <GraduationCap className="w-3 h-3" />
                <span>إعلان مخصص للمدارس</span>
              </button>
              <button
                type="button"
                onClick={() => handleSelectPreset('companies')}
                className="px-2.5 py-1 bg-blue-50 hover:bg-blue-100 text-blue-800 rounded-lg text-[11px] font-semibold transition cursor-pointer flex items-center gap-1"
              >
                <Building2 className="w-3 h-3" />
                <span>إعلان للشركات B2B</span>
              </button>
              <button
                type="button"
                onClick={() => handleSelectPreset('promotion')}
                className="px-2.5 py-1 bg-amber-50 hover:bg-amber-100 text-amber-800 rounded-lg text-[11px] font-semibold transition cursor-pointer flex items-center gap-1"
              >
                <Zap className="w-3 h-3" />
                <span>عرض خصم وانضمام فوري</span>
              </button>
            </div>

            {/* Field 2: The Ad Copy Textarea */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-stone-800 flex items-center gap-1.5">
                  <MessageSquare className="w-3.5 h-3.5 text-emerald-600" />
                  <span>نص رسالة الإعلان عن الوكالة (الذي يحتوي رابط النموذج):</span>
                </label>
                <span className="text-[10px] text-stone-400">
                  {adAnnouncement.length} حرف
                </span>
              </div>
              <textarea
                value={adAnnouncement}
                onChange={(e) => setAdAnnouncement(e.target.value)}
                rows={9}
                className="w-full p-3.5 border border-stone-300 rounded-xl text-xs sm:text-sm leading-relaxed focus:ring-2 focus:ring-emerald-500 focus:outline-hidden font-sans"
                placeholder="الصق هنا رسالة إعلان الوكالة الكاملة مع رابط الانضمام..."
              />
            </div>

            {/* Insert Tag Variables Helper */}
            <div className="flex flex-wrap items-center gap-1.5 text-xs bg-stone-50 p-2.5 rounded-xl border border-stone-200">
              <span className="text-[11px] font-bold text-stone-600">إدراج متغير ذكي:</span>
              {[
                { tag: '{رابط_النموذج}', label: '🔗 رابط النموذج' },
                { tag: '{اسم_الجهة}', label: '🏫 اسم المدرسة/الشركة' },
                { tag: '{المدينة}', label: '📍 المدينة' },
                { tag: '{النوع}', label: '🏷️ القطاع' },
                { tag: '{رقم_الواتس}', label: '📱 رقم الواتس المعتمد' },
                { tag: '{اسم_الوكالة}', label: '🏢 اسم الوكالة' },
              ].map((v) => (
                <button
                  key={v.tag}
                  type="button"
                  onClick={() => insertVariable(v.tag)}
                  className="px-2 py-0.5 bg-white border border-stone-300 hover:border-emerald-500 hover:text-emerald-700 text-stone-700 rounded-md text-[11px] font-mono transition cursor-pointer"
                >
                  {v.label}
                </button>
              ))}
            </div>

            {/* Bottom Actions for Ad Box */}
            <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-stone-100">
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    navigator.clipboard.writeText(adAnnouncement.replace(/{رابط_النموذج}/g, formUrl));
                    setCopiedAd(true);
                    setTimeout(() => setCopiedAd(false), 2000);
                  }}
                  className="px-3 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer"
                >
                  {copiedAd ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedAd ? 'تم النسخ' : 'نسخ الإعلان بالرابط'}</span>
                </button>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleSaveProfileAndAd}
                  className="px-4 py-2 bg-stone-900 hover:bg-stone-800 text-white rounded-lg text-xs font-bold transition active:scale-95 cursor-pointer shadow-xs"
                >
                  حفظ وتحديث الإعلان
                </button>
                <button
                  type="button"
                  onClick={handleLaunchAnnouncementCampaign}
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 transition active:scale-95 cursor-pointer shadow-xs"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>إرسال الإعلان للمدارس والشركات</span>
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column (5 Cols): Pricing Settings & Negotiation Engine Options */}
        <div className="lg:col-span-5 space-y-4">
          {/* Pricing Policy Card */}
          <div className="bg-white rounded-2xl border border-stone-200 p-5 shadow-xs space-y-4">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-amber-100 text-amber-800 flex items-center justify-center">
                  <DollarSign className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-stone-900">
                    استراتيجية الأسعار (البيع vs الاستئجار)
                  </h3>
                  <p className="text-[11px] text-stone-500">
                    يطرحها الوكيل الذكي تلقائياً عند التفاوض مع المدارس والشركات
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setShowPricingSettings(!showPricingSettings)}
                className="text-stone-400 hover:text-stone-600 p-1 cursor-pointer"
              >
                {showPricingSettings ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
              </button>
            </div>

            {/* Quick Preview of Pricing */}
            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="bg-emerald-50/60 p-3 rounded-xl border border-emerald-200 space-y-1">
                <div className="flex items-center justify-between text-emerald-800 font-bold">
                  <span>خيار البيع الكامل</span>
                  <span className="text-[10px] bg-emerald-200/70 px-1.5 py-0.5 rounded">رخصة دائمة</span>
                </div>
                <div className="text-base font-black text-emerald-950">
                  {pricing.salePrice.toLocaleString()} {pricing.currency}
                </div>
                <p className="text-[10px] text-emerald-700 leading-tight">
                  شراء وتملك كامل للنظام دون رسوم شهرية متكررة
                </p>
              </div>

              <div className="bg-cyan-50/60 p-3 rounded-xl border border-cyan-200 space-y-1">
                <div className="flex items-center justify-between text-cyan-800 font-bold">
                  <span>خيار الاستئجار السنوي</span>
                  <span className="text-[10px] bg-cyan-200/70 px-1.5 py-0.5 rounded">SaaS دوري</span>
                </div>
                <div className="text-base font-black text-cyan-950">
                  {pricing.leasePriceAnnual.toLocaleString()} {pricing.currency}
                </div>
                <p className="text-[10px] text-cyan-700 leading-tight">
                  أو {pricing.leasePriceMonthly.toLocaleString()} {pricing.currency} شهرياً شامل الاستضافة والصيانة
                </p>
              </div>
            </div>

            {/* Collapsible Detailed Pricing Inputs */}
            {showPricingSettings && (
              <div className="space-y-3 pt-2 text-xs border-t border-stone-100">
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-stone-700 font-semibold mb-1">سعر البيع الكامل ({pricing.currency}):</label>
                    <input
                      type="number"
                      value={pricing.salePrice}
                      onChange={(e) => setPricing({ ...pricing, salePrice: Number(e.target.value) })}
                      className="w-full px-3 py-1.5 border border-stone-300 rounded-lg text-xs"
                    />
                  </div>
                  <div>
                    <label className="block text-stone-700 font-semibold mb-1">الاستئجار السنوي ({pricing.currency}):</label>
                    <input
                      type="number"
                      value={pricing.leasePriceAnnual}
                      onChange={(e) => setPricing({ ...pricing, leasePriceAnnual: Number(e.target.value) })}
                      className="w-full px-3 py-1.5 border border-stone-300 rounded-lg text-xs"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-stone-700 font-semibold mb-1">الاستئجار الشهري ({pricing.currency}):</label>
                    <input
                      type="number"
                      value={pricing.leasePriceMonthly}
                      onChange={(e) => setPricing({ ...pricing, leasePriceMonthly: Number(e.target.value) })}
                      className="w-full px-3 py-1.5 border border-stone-300 rounded-lg text-xs"
                    />
                  </div>
                  <div>
                    <label className="block text-stone-700 font-semibold mb-1">هامش الخصم للتفاوض (%):</label>
                    <input
                      type="number"
                      value={pricing.discountMargin || 15}
                      onChange={(e) => setPricing({ ...pricing, discountMargin: Number(e.target.value) })}
                      className="w-full px-3 py-1.5 border border-stone-300 rounded-lg text-xs"
                    />
                  </div>
                </div>

                <button
                  type="button"
                  onClick={handleSaveProfileAndAd}
                  className="w-full py-1.5 bg-stone-800 text-white rounded-lg font-bold text-xs hover:bg-stone-900 transition cursor-pointer"
                >
                  حفظ إعدادات الأسعار
                </button>
              </div>
            )}

            {/* Bulk Negotiation Trigger */}
            <div className="bg-amber-50/70 p-3.5 rounded-xl border border-amber-200 space-y-2 text-xs">
              <div className="flex items-center justify-between">
                <span className="font-bold text-amber-900 flex items-center gap-1.5">
                  <Bot className="w-4 h-4 text-amber-600" />
                  تشغيل التفاوض الآلي على كافة الاستفسارات:
                </span>
                <span className="text-[10px] bg-amber-200 text-amber-900 px-2 py-0.5 rounded-full font-bold">
                  {leads.filter((l) => l.status === 'replied' && l.dealStage !== 'closed_sale' && l.dealStage !== 'closed_lease').length} ردود بانتظار الطرح
                </span>
              </div>
              <p className="text-amber-800 text-[11px] leading-relaxed">
                يقوم الوكيل بالرد على استفسارات المدارس والشركات، وطرح عروض الأسعار (بيع واستئجار)، ومتابعة تقديم رابط النموذج لإتمام وإغلاق الصفقة.
              </p>

              <button
                type="button"
                disabled={isBulkNegotiating}
                onClick={handleRunBatchAutoNegotiation}
                className="w-full py-2.5 bg-amber-500 hover:bg-amber-600 text-stone-950 font-extrabold rounded-lg text-xs flex items-center justify-center gap-2 shadow-xs transition active:scale-95 cursor-pointer disabled:opacity-50"
              >
                {isBulkNegotiating ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    <span>جاري التفاوض ({bulkNegotiationProgress?.current} من {bulkNegotiationProgress?.total})...</span>
                  </>
                ) : (
                  <>
                    <Zap className="w-3.5 h-3.5" />
                    <span>بدء دورة التفاوض وطرح الأسعار آلياً</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Deals, Negotiation & Sales Lifecycle Center */}
      <div className="bg-white rounded-2xl border border-stone-200 p-5 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-stone-100 pb-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center">
              <TrendingUp className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-stone-900">
                سجل المبيعات والتفاوض مع المدارس والشركات (بيع vs استئجار)
              </h3>
              <p className="text-[11px] text-stone-500">
                متابعة طرح الأسعار، جولات التفاوض، الصفقات المنجزة، وحالة تعبئة نماذج الانضمام
              </p>
            </div>
          </div>

          {/* Filter Pills */}
          <div className="flex flex-wrap items-center gap-1.5 text-xs">
            {[
              { id: 'all', label: `الكل (${leads.length})` },
              { id: 'ad_sent', label: `استلموا الإعلان (${adSentCount})` },
              { id: 'negotiating', label: `جاري التفاوض (${negotiatingCount})` },
              { id: 'closed_sale', label: `بيع كامل (${closedSaleCount})` },
              { id: 'closed_lease', label: `استئجار دوري (${closedLeaseCount})` },
              { id: 'form_submitted', label: `تم تعبئة النموذج (${formSubmittedCount})` },
            ].map((f) => (
              <button
                key={f.id}
                onClick={() => setDealFilter(f.id as any)}
                className={`px-3 py-1 rounded-lg text-xs font-semibold transition cursor-pointer ${
                  dealFilter === f.id
                    ? 'bg-emerald-600 text-white'
                    : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
                }`}
              >
                {f.label}
              </button>
            ))}
          </div>
        </div>

        {/* Leads Deal Table / Cards */}
        <div className="space-y-3">
          {filteredLeads.length === 0 ? (
            <div className="p-8 text-center text-stone-400 text-xs">
              لا توجد جهات مطابقة لهذا الفلتر حالياً.
            </div>
          ) : (
            filteredLeads.map((lead) => {
              const isClosedSale = lead.dealStage === 'closed_sale' || (lead.dealType === 'sale' && lead.status === 'converted');
              const isClosedLease = lead.dealStage === 'closed_lease' || (lead.dealType === 'lease' && lead.status === 'converted');
              const isNegotiating = lead.dealStage === 'negotiating' || lead.dealStage === 'pricing_offered';

              return (
                <div
                  key={lead.id}
                  className={`p-4 rounded-xl border transition ${
                    isClosedSale
                      ? 'bg-emerald-50/40 border-emerald-200'
                      : isClosedLease
                      ? 'bg-cyan-50/40 border-cyan-200'
                      : isNegotiating
                      ? 'bg-amber-50/30 border-amber-200'
                      : 'bg-stone-50/50 border-stone-200'
                  }`}
                >
                  <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-3">
                    {/* Lead Info */}
                    <div className="space-y-1 max-w-lg">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="font-bold text-sm text-stone-900">{lead.name}</span>
                        <span
                          className={`text-[10px] px-2 py-0.5 rounded-full font-bold flex items-center gap-1 ${
                            lead.category === 'school'
                              ? 'bg-purple-100 text-purple-800'
                              : 'bg-blue-100 text-blue-800'
                          }`}
                        >
                          {lead.category === 'school' ? <GraduationCap className="w-3 h-3" /> : <Building2 className="w-3 h-3" />}
                          {lead.categoryLabel || lead.category}
                        </span>
                        <span className="text-[11px] text-stone-400">
                          {lead.city} • {lead.country}
                        </span>

                        {/* Form Submission Badge */}
                        <button
                          type="button"
                          onClick={() => handleToggleFormSubmitted(lead)}
                          className={`text-[10px] px-2 py-0.5 rounded-full font-bold transition cursor-pointer flex items-center gap-1 ${
                            lead.formSubmitted
                              ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                              : 'bg-stone-200 text-stone-600 hover:bg-stone-300'
                          }`}
                          title="اضغط لتغيير حالة تعبئة نموذج الانضمام"
                        >
                          <CheckCircle2 className="w-3 h-3" />
                          <span>{lead.formSubmitted ? 'تم تعبئة النموذج ✅' : 'بانتظار النموذج'}</span>
                        </button>
                      </div>

                      {/* Phone & notes */}
                      <div className="flex items-center gap-3 text-xs text-stone-500">
                        <span className="font-mono text-stone-700">{lead.whatsappNumber || lead.rawPhone}</span>
                        {lead.notes && <span className="text-stone-400 truncate max-w-xs">{lead.notes}</span>}
                      </div>

                      {/* Client reply if present */}
                      {lead.replyText && (
                        <div className="text-xs bg-white p-2.5 rounded-lg border border-stone-200 mt-2 text-stone-800">
                          <span className="font-bold text-stone-900 block mb-0.5">💬 رد العميل:</span>
                          <p className="text-stone-600 leading-relaxed">{lead.replyText}</p>
                        </div>
                      )}

                      {/* Deal terms or notes if present */}
                      {lead.dealTerms && (
                        <div className="text-[11px] text-emerald-800 font-medium mt-1">
                          📌 <span className="font-bold">العرض والتفاوض:</span> {lead.dealTerms}
                        </div>
                      )}
                    </div>

                    {/* Deal Status & Actions */}
                    <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3 shrink-0 w-full lg:w-auto justify-between lg:justify-end">
                      {/* Deal Amount & Stage Badge */}
                      <div className="text-left sm:text-right">
                        <div className="flex items-center gap-1.5">
                          {isClosedSale && (
                            <span className="px-2.5 py-0.5 rounded-full bg-emerald-600 text-white text-xs font-bold">
                              تمت عملية البيع 🎉
                            </span>
                          )}
                          {isClosedLease && (
                            <span className="px-2.5 py-0.5 rounded-full bg-cyan-700 text-white text-xs font-bold">
                              تم عقد الاستئجار 📜
                            </span>
                          )}
                          {isNegotiating && (
                            <span className="px-2.5 py-0.5 rounded-full bg-amber-500 text-stone-950 text-xs font-bold">
                              جاري التفاوض والأسعار ⚖️
                            </span>
                          )}
                          {!isClosedSale && !isClosedLease && !isNegotiating && (
                            <span className="px-2 py-0.5 rounded-full bg-stone-200 text-stone-700 text-[11px] font-medium">
                              تم إرسال الإعلان 📢
                            </span>
                          )}
                        </div>

                        {lead.dealAmount && (
                          <div className="text-sm font-black text-stone-900 mt-0.5">
                            {Number(lead.dealAmount).toLocaleString()} {pricing.currency}
                          </div>
                        )}
                      </div>

                      {/* Buttons */}
                      <div className="flex flex-wrap items-center gap-1.5">
                        {/* Negotiate with AI */}
                        <button
                          type="button"
                          onClick={() => handleRunNegotiationForLead(lead)}
                          className="px-3 py-1.5 bg-emerald-100 hover:bg-emerald-200 text-emerald-900 font-bold rounded-lg text-xs flex items-center gap-1 transition cursor-pointer"
                        >
                          <Bot className="w-3.5 h-3.5 text-emerald-700" />
                          <span>تفاوض وطرح أسعار</span>
                        </button>

                        {/* Close as Sale */}
                        <button
                          type="button"
                          onClick={() => handleSetDealStage(lead, 'closed_sale', 'sale', pricing.salePrice)}
                          className="px-2.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-lg text-[11px] transition cursor-pointer"
                          title="إتمام وإغلاق كـ بيع كامل"
                        >
                          إغلاق كـ بيع
                        </button>

                        {/* Close as Lease */}
                        <button
                          type="button"
                          onClick={() => handleSetDealStage(lead, 'closed_lease', 'lease', pricing.leasePriceAnnual)}
                          className="px-2.5 py-1.5 bg-cyan-700 hover:bg-cyan-800 text-white font-bold rounded-lg text-[11px] transition cursor-pointer"
                          title="إتمام وإغلاق كـ عقد استئجار"
                        >
                          إغلاق كـ استئجار
                        </button>

                        {/* WhatsApp Direct Chat */}
                        {lead.whatsappNumber && (
                          <a
                            href={generateWhatsAppChatUrl(
                              lead.whatsappNumber,
                              `السلام عليكم ورحمة الله، مرحباً بإدارة ${lead.name}، يسعدنا تزويدكم بنموذج الانضمام وتفاصيل الأسعار: ${formUrl}`
                            )}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="p-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 rounded-lg border border-emerald-300 transition"
                            title="فتح محادثة واتساب مباشرة"
                          >
                            <Phone className="w-3.5 h-3.5 text-emerald-700" />
                          </a>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>

      {/* Interactive Negotiation Drawer / Modal */}
      {selectedLeadForNegotiation && (
        <div className="fixed inset-0 bg-stone-900/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-xl w-full p-6 space-y-4 shadow-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-emerald-600 text-white flex items-center justify-center">
                  <Bot className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-stone-900">
                    غرفة تفاوض الذكاء الاصطناعي مع: {selectedLeadForNegotiation.name}
                  </h3>
                  <p className="text-[11px] text-stone-500">
                    نيابة عن رقمك {agencyProfile.myWhatsapp} • طرح باقات البيع والاستئجار
                  </p>
                </div>
              </div>
              <button
                onClick={() => {
                  setSelectedLeadForNegotiation(null);
                  setNegotiationResult(null);
                }}
                className="text-stone-400 hover:text-stone-600 text-sm font-bold cursor-pointer"
              >
                ✕
              </button>
            </div>

            {/* Client Context */}
            <div className="bg-stone-50 p-3 rounded-xl border border-stone-200 text-xs space-y-1">
              <div className="text-stone-500">
                <span className="font-bold text-stone-700">القطاع والمدينة:</span> {selectedLeadForNegotiation.categoryLabel} - {selectedLeadForNegotiation.city}
              </div>
              <div>
                <span className="font-bold text-stone-700">رسالة/استفسار العميل:</span>{' '}
                <span className="text-stone-800">{selectedLeadForNegotiation.replyText || 'طلب معرفة الأسعار وباقات البيع أو الاستئجار'}</span>
              </div>
            </div>

            {/* Custom Input for Negotiation Query */}
            <div className="space-y-1">
              <label className="text-xs font-semibold text-stone-700">
                اختبر سؤال أو اعتراض مخصص للعميل للتفاوض عليه:
              </label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={customNegotiationInput}
                  onChange={(e) => setCustomNegotiationInput(e.target.value)}
                  placeholder="مثال: هل السعر قابل للتفاوض؟ أو هل الاستئجار يشمل الصيانة؟"
                  className="flex-1 px-3 py-2 border border-stone-300 rounded-lg text-xs"
                />
                <button
                  type="button"
                  disabled={isNegotiatingAI}
                  onClick={() => handleRunNegotiationForLead(selectedLeadForNegotiation, customNegotiationInput)}
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-lg text-xs transition cursor-pointer"
                >
                  {isNegotiatingAI ? 'جاري التفاوض...' : 'تفاوض'}
                </button>
              </div>
            </div>

            {/* Negotiation Output */}
            {negotiationResult && (
              <div className="space-y-3 pt-2 border-t border-stone-100">
                <div className="bg-emerald-50/80 p-3.5 rounded-xl border border-emerald-200 text-xs space-y-2">
                  <div className="flex items-center justify-between font-bold text-emerald-950">
                    <span>رد الوكيل المقترح للعميل عبر الواتساب:</span>
                    <span className="text-[10px] bg-emerald-200 text-emerald-900 px-2 py-0.5 rounded-full">
                      المرحلة: {negotiationResult.dealStage}
                    </span>
                  </div>
                  <p className="text-emerald-900 leading-relaxed whitespace-pre-line bg-white/70 p-3 rounded-lg border border-emerald-100 font-sans">
                    {negotiationResult.replyMessage}
                  </p>

                  <div className="grid grid-cols-2 gap-2 text-[11px] text-emerald-800 pt-1">
                    <div>
                      <span className="font-bold">نوع الصفقة المطروحة:</span> {negotiationResult.dealType === 'sale' ? 'بيع كامل' : negotiationResult.dealType === 'lease' ? 'استئجار دوري' : 'عرض الخيارين'}
                    </div>
                    <div>
                      <span className="font-bold">السعر المعروض:</span> {negotiationResult.quotedAmount ? Number(negotiationResult.quotedAmount).toLocaleString() : pricing.salePrice.toLocaleString()} {pricing.currency}
                    </div>
                  </div>

                  {negotiationResult.dealSummary && (
                    <div className="text-[11px] text-emerald-900/80">
                      <span className="font-bold">ملخص الاتفاق:</span> {negotiationResult.dealSummary}
                    </div>
                  )}
                </div>

                <div className="flex items-center justify-end gap-2 pt-2">
                  <a
                    href={generateWhatsAppChatUrl(
                      selectedLeadForNegotiation.whatsappNumber,
                      negotiationResult.replyMessage
                    )}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-lg text-xs flex items-center gap-1.5 transition cursor-pointer"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>إرسال الرد للعميل على الواتساب</span>
                  </a>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Full Executive Closing Report Modal ("موافاتي بتقرير عن ما تم وماحصل") */}
      {showExecutiveReportModal && (
        <div className="fixed inset-0 bg-stone-900/70 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-3xl w-full p-6 space-y-4 shadow-2xl max-h-[92vh] flex flex-col">
            {/* Modal Header */}
            <div className="flex items-center justify-between border-b border-stone-200 pb-3 shrink-0">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-xl bg-amber-500 text-stone-950 flex items-center justify-center shadow-xs">
                  <FileText className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-black text-stone-900">
                    التقرير التنفيذي الشامل لوكيل المبيعات: ما تم وما حصل
                  </h3>
                  <p className="text-xs text-stone-500">
                    تقرير صادر لصاحب الوكالة • صفقات البيع والاستئجار وتوزيع رابط الانضمام
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    navigator.clipboard.writeText(executiveReportContent);
                    setCopiedReport(true);
                    setTimeout(() => setCopiedReport(false), 2000);
                  }}
                  className="px-3 py-1.5 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded-lg text-xs font-semibold flex items-center gap-1 transition cursor-pointer"
                >
                  {copiedReport ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedReport ? 'تم النسخ' : 'نسخ التقرير'}</span>
                </button>

                <button
                  type="button"
                  onClick={() => window.print()}
                  className="px-3 py-1.5 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded-lg text-xs font-semibold flex items-center gap-1 transition cursor-pointer"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>طباعة / PDF</span>
                </button>

                <button
                  type="button"
                  onClick={() => setShowExecutiveReportModal(false)}
                  className="p-1.5 text-stone-400 hover:text-stone-600 rounded-lg cursor-pointer"
                >
                  ✕
                </button>
              </div>
            </div>

            {/* Quick Metrics Cards Inside Report */}
            {reportMetrics && (
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 bg-stone-50 p-3 rounded-xl border border-stone-200 text-center shrink-0 text-xs">
                <div>
                  <span className="text-stone-500 text-[10px] block">إجمالي المستهدفين</span>
                  <span className="font-extrabold text-sm text-stone-900">{reportMetrics.totalLeads}</span>
                </div>
                <div>
                  <span className="text-stone-500 text-[10px] block">تم إرسال الإعلان</span>
                  <span className="font-extrabold text-sm text-stone-900">{reportMetrics.contactedLeads}</span>
                </div>
                <div>
                  <span className="text-stone-500 text-[10px] block">صفقات منجزة (بيع/إيجار)</span>
                  <span className="font-extrabold text-sm text-emerald-600">{reportMetrics.closedSaleDeals + reportMetrics.closedLeaseDeals}</span>
                </div>
                <div>
                  <span className="text-stone-500 text-[10px] block">إجمالي الإيرادات</span>
                  <span className="font-extrabold text-sm text-emerald-700">{reportMetrics.totalRevenue?.toLocaleString()} {pricing.currency}</span>
                </div>
              </div>
            )}

            {/* Report Content Scroll Area */}
            <div className="flex-1 overflow-y-auto p-4 bg-stone-50/60 rounded-xl border border-stone-200 text-stone-800 text-xs sm:text-sm leading-relaxed whitespace-pre-line font-sans select-text">
              {isGeneratingReport ? (
                <div className="py-16 flex flex-col items-center justify-center gap-3 text-stone-500">
                  <RefreshCw className="w-7 h-7 text-emerald-600 animate-spin" />
                  <span className="font-bold">جاري تحليل البيانات وصياغة التقرير التنفيذي لما تم وما حصل بالذكاء الاصطناعي...</span>
                </div>
              ) : (
                executiveReportContent
              )}
            </div>

            {/* Footer */}
            <div className="flex items-center justify-between pt-2 border-t border-stone-100 text-xs text-stone-400 shrink-0">
              <span>تم إعداد هذا التقرير آلياً نيابة عن رقم الواتساب: {agencyProfile.myWhatsapp}</span>
              <button
                onClick={handleGenerateExecutiveReport}
                className="text-emerald-700 font-bold hover:underline flex items-center gap-1 cursor-pointer"
              >
                <RefreshCw className="w-3 h-3" />
                <span>إعادة توليد وتحديث التقرير</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
