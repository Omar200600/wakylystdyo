import React, { useState } from 'react';
import {
  CheckSquare,
  Square,
  Plus,
  Trash2,
  Calendar,
  AlertCircle,
  Clock,
  Sparkles,
  ArrowRight,
  TrendingUp,
  Search,
  Send,
  MessageCircle,
  Briefcase,
  CheckCircle2,
} from 'lucide-react';
import { DailyTask } from '../types';

interface DailyTasksViewProps {
  tasks: DailyTask[];
  onToggleTask: (id: string) => void;
  onAddTask: (task: DailyTask) => void;
  onDeleteTask: (id: string) => void;
  onNavigateTab: (tab: 'search' | 'leads' | 'campaigns' | 'autoReply') => void;
}

export const DailyTasksView: React.FC<DailyTasksViewProps> = ({
  tasks,
  onToggleTask,
  onAddTask,
  onDeleteTask,
  onNavigateTab,
}) => {
  const [filter, setFilter] = useState<'all' | 'pending' | 'completed'>('all');
  const [newTitle, setNewTitle] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [newCategory, setNewCategory] = useState<'leads' | 'outreach' | 'followup' | 'replies' | 'general'>('outreach');
  const [newPriority, setNewPriority] = useState<'high' | 'medium' | 'low'>('high');
  const [newDueDate, setNewDueDate] = useState('اليوم');
  const [newTargetCount, setNewTargetCount] = useState<number | undefined>(10);
  const [isFormOpen, setIsFormOpen] = useState(false);

  const completedCount = tasks.filter((t) => t.completed).length;
  const pendingCount = tasks.length - completedCount;
  const progressPercent = tasks.length > 0 ? Math.round((completedCount / tasks.length) * 100) : 0;

  const filteredTasks = tasks.filter((t) => {
    if (filter === 'pending') return !t.completed;
    if (filter === 'completed') return t.completed;
    return true;
  });

  const handleCreateTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    const task: DailyTask = {
      id: `task_${Date.now()}`,
      title: newTitle.trim(),
      description: newDesc.trim(),
      category: newCategory,
      priority: newPriority,
      completed: false,
      dueDate: newDueDate,
      leadCountTarget: newTargetCount,
      completedCount: 0,
      createdAt: new Date().toISOString(),
    };

    onAddTask(task);
    setNewTitle('');
    setNewDesc('');
    setIsFormOpen(false);
  };

  const getCategoryIcon = (category: DailyTask['category']) => {
    switch (category) {
      case 'leads':
        return <Search className="w-4 h-4 text-emerald-600" />;
      case 'outreach':
        return <Send className="w-4 h-4 text-blue-600" />;
      case 'followup':
        return <TrendingUp className="w-4 h-4 text-purple-600" />;
      case 'replies':
        return <MessageCircle className="w-4 h-4 text-amber-600" />;
      default:
        return <Briefcase className="w-4 h-4 text-stone-600" />;
    }
  };

  const getCategoryLabel = (category: DailyTask['category']) => {
    switch (category) {
      case 'leads':
        return 'تنقيب وبحث';
      case 'outreach':
        return 'إرسال حملات';
      case 'followup':
        return 'متابعة صفقات';
      case 'replies':
        return 'ردود واستفسارات';
      default:
        return 'مهام عامة';
    }
  };

  return (
    <div className="space-y-6">
      {/* Banner & Daily Productivity Scorecard */}
      <div className="bg-white rounded-xl border border-stone-200 p-6 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-50 text-emerald-800 text-xs font-semibold mb-2">
              <CheckSquare className="w-3.5 h-3.5" />
              لوحة إدارة المهام اليومية والإنتاجية
            </div>
            <h2 className="text-xl font-bold text-stone-900">
              متابعة المهام اليومية للوكالة والعملاء المستهدفين
            </h2>
            <p className="text-sm text-stone-600 mt-1 max-w-3xl">
              نظم جدولك اليومي لتوليد جهات الاتصال، إرسال دفعات الرسائل الإعلانية، مراجعة ردود العملاء الواردة على رقمك، ومتابعة الصفقات.
            </p>
          </div>

          {/* Quick Task Add Button */}
          <button
            type="button"
            onClick={() => setIsFormOpen(!isFormOpen)}
            className="px-4 py-2 bg-stone-900 hover:bg-stone-800 text-white text-xs font-bold rounded-lg flex items-center gap-2 transition cursor-pointer self-start md:self-auto shadow-xs"
          >
            <Plus className="w-4 h-4" />
            <span>إضافة مهمة يومية جديدة</span>
          </button>
        </div>

        {/* Productivity Metric Bar */}
        <div className="mt-5 pt-4 border-t border-stone-100 grid grid-cols-1 sm:grid-cols-4 gap-3">
          <div className="p-3 bg-stone-50 rounded-xl border border-stone-200">
            <div className="text-xs text-stone-500">إجمالي مهام اليوم</div>
            <div className="text-2xl font-black text-stone-900 mt-0.5">{tasks.length}</div>
          </div>
          <div className="p-3 bg-emerald-50/50 rounded-xl border border-emerald-200">
            <div className="text-xs text-emerald-800 font-medium">المهام المنجزة</div>
            <div className="text-2xl font-black text-emerald-700 mt-0.5">{completedCount}</div>
          </div>
          <div className="p-3 bg-amber-50/50 rounded-xl border border-amber-200">
            <div className="text-xs text-amber-800 font-medium">قيد التنفيذ</div>
            <div className="text-2xl font-black text-amber-700 mt-0.5">{pendingCount}</div>
          </div>
          <div className="p-3 bg-stone-50 rounded-xl border border-stone-200">
            <div className="text-xs text-stone-500 font-medium flex items-center justify-between">
              <span>نسبة الإنجاز اليومي</span>
              <span className="font-bold text-emerald-700 font-mono">{progressPercent}%</span>
            </div>
            <div className="w-full h-2 bg-stone-200 rounded-full mt-2 overflow-hidden">
              <div
                className="h-full bg-emerald-600 rounded-full transition-all duration-300"
                style={{ width: `${progressPercent}%` }}
              />
            </div>
          </div>
        </div>
      </div>

      {/* New Task Inline Form */}
      {isFormOpen && (
        <form
          onSubmit={handleCreateTask}
          className="bg-white rounded-xl border border-emerald-300 p-5 shadow-sm space-y-4 animate-in fade-in duration-200"
        >
          <div className="flex items-center justify-between border-b border-stone-100 pb-2">
            <h3 className="text-sm font-bold text-stone-900 flex items-center gap-2">
              <Plus className="w-4 h-4 text-emerald-600" />
              إضافة مهمة جديدة لجدول اليوم
            </h3>
            <button
              type="button"
              onClick={() => setIsFormOpen(false)}
              className="text-xs text-stone-400 hover:text-stone-700"
            >
              إغلاق
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            <div>
              <label className="block font-semibold text-stone-700 mb-1">عنوان المهمة:</label>
              <input
                type="text"
                required
                value={newTitle}
                onChange={(e) => setNewTitle(e.target.value)}
                placeholder="مثال: إرسال دفعة 20 رسالة لمدارس جدة"
                className="w-full px-3 py-2 border border-stone-300 rounded-lg text-sm"
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block font-semibold text-stone-700 mb-1">التصنيف:</label>
                <select
                  value={newCategory}
                  onChange={(e) => setNewCategory(e.target.value as any)}
                  className="w-full px-2.5 py-2 border border-stone-300 rounded-lg text-xs bg-white font-medium"
                >
                  <option value="leads">تنقيب وبحث عن جهات</option>
                  <option value="outreach">إرسال حملة واتساب</option>
                  <option value="followup">متابعة صفقات</option>
                  <option value="replies">ردود على استفسارات</option>
                  <option value="general">مهمة عامة</option>
                </select>
              </div>

              <div>
                <label className="block font-semibold text-stone-700 mb-1">الأولوية:</label>
                <select
                  value={newPriority}
                  onChange={(e) => setNewPriority(e.target.value as any)}
                  className="w-full px-2.5 py-2 border border-stone-300 rounded-lg text-xs bg-white font-medium"
                >
                  <option value="high">أولوية عالية</option>
                  <option value="medium">متوسطة</option>
                  <option value="low">منخفضة</option>
                </select>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            <div>
              <label className="block font-semibold text-stone-700 mb-1">تفاصيل أو تعليمات المهمة:</label>
              <input
                type="text"
                value={newDesc}
                onChange={(e) => setNewDesc(e.target.value)}
                placeholder="ملاحظات إضافية حول آلية التنفيذ أو الأسماء المستهدفة..."
                className="w-full px-3 py-2 border border-stone-300 rounded-lg text-sm"
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block font-semibold text-stone-700 mb-1">الموعد المستهدف:</label>
                <input
                  type="text"
                  value={newDueDate}
                  onChange={(e) => setNewDueDate(e.target.value)}
                  placeholder="اليوم، غداً، الساعة 2 ظهراً"
                  className="w-full px-2.5 py-2 border border-stone-300 rounded-lg text-xs"
                />
              </div>
              <div>
                <label className="block font-semibold text-stone-700 mb-1">العدد المستهدف (اختياري):</label>
                <input
                  type="number"
                  value={newTargetCount || ''}
                  onChange={(e) => setNewTargetCount(Number(e.target.value))}
                  placeholder="مثلاً 10 جهات"
                  className="w-full px-2.5 py-2 border border-stone-300 rounded-lg text-xs font-mono"
                />
              </div>
            </div>
          </div>

          <div className="flex items-center justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setIsFormOpen(false)}
              className="px-3.5 py-1.5 border border-stone-300 rounded-lg text-xs text-stone-700"
            >
              إلغاء
            </button>
            <button
              type="submit"
              className="px-5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-lg cursor-pointer"
            >
              إضافة المهمة
            </button>
          </div>
        </form>
      )}

      {/* Filter Tabs */}
      <div className="flex items-center justify-between border-b border-stone-200 pb-2">
        <div className="flex items-center gap-2">
          {(['all', 'pending', 'completed'] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setFilter(tab)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition ${
                filter === tab
                  ? 'bg-stone-900 text-white shadow-xs'
                  : 'text-stone-600 hover:text-stone-900 hover:bg-stone-100'
              }`}
            >
              {tab === 'all' && `جميع المهام (${tasks.length})`}
              {tab === 'pending' && `قيد التنفيذ (${pendingCount})`}
              {tab === 'completed' && `المكتملة (${completedCount})`}
            </button>
          ))}
        </div>
      </div>

      {/* Tasks List */}
      <div className="space-y-2.5">
        {filteredTasks.length === 0 ? (
          <div className="bg-white rounded-xl border border-stone-200 p-10 text-center text-stone-500">
            <CheckCircle2 className="w-8 h-8 text-emerald-600 mx-auto mb-2 opacity-80" />
            <p className="text-sm font-semibold text-stone-800">لا توجد مهام في هذا التصنيف حالياً</p>
            <p className="text-xs text-stone-400 mt-1">
              جميع مهامك اليومية تحت السيطرة أو يمكنك إضافة مهمة جديدة للبدء.
            </p>
          </div>
        ) : (
          filteredTasks.map((task) => {
            const isDone = task.completed;
            return (
              <div
                key={task.id}
                className={`p-4 rounded-xl border transition flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
                  isDone
                    ? 'bg-stone-50/60 border-stone-200 opacity-75'
                    : 'bg-white border-stone-200 hover:border-emerald-300 shadow-xs'
                }`}
              >
                <div className="flex items-start gap-3">
                  <button
                    type="button"
                    onClick={() => onToggleTask(task.id)}
                    className="mt-0.5 text-stone-400 hover:text-emerald-600 cursor-pointer transition"
                  >
                    {isDone ? (
                      <CheckSquare className="w-5 h-5 text-emerald-600" />
                    ) : (
                      <Square className="w-5 h-5 text-stone-300 hover:text-stone-400" />
                    )}
                  </button>

                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span
                        className={`text-sm font-bold ${
                          isDone ? 'line-through text-stone-400' : 'text-stone-900'
                        }`}
                      >
                        {task.title}
                      </span>

                      {/* Category Badge */}
                      <span className="inline-flex items-center gap-1 text-[10px] font-semibold px-2 py-0.5 rounded-full bg-stone-100 text-stone-700">
                        {getCategoryIcon(task.category)}
                        {getCategoryLabel(task.category)}
                      </span>

                      {/* Priority Badge */}
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                          task.priority === 'high'
                            ? 'bg-rose-100 text-rose-800'
                            : task.priority === 'medium'
                              ? 'bg-amber-100 text-amber-800'
                              : 'bg-stone-100 text-stone-600'
                        }`}
                      >
                        {task.priority === 'high' ? 'عالية الأهمية' : task.priority === 'medium' ? 'متوسطة' : 'عادية'}
                      </span>
                    </div>

                    {task.description && (
                      <p className="text-xs text-stone-500 leading-relaxed max-w-2xl">
                        {task.description}
                      </p>
                    )}

                    <div className="flex items-center gap-3 text-[11px] text-stone-400 pt-0.5">
                      <span className="flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        الموعد: {task.dueDate}
                      </span>
                      {typeof task.leadCountTarget === 'number' && (
                        <span>
                          الهدف الرقمي: {task.completedCount || 0} / {task.leadCountTarget} جهة
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                {/* Quick Launch Button to relevant action */}
                <div className="flex items-center gap-2 self-end sm:self-center">
                  {task.category === 'leads' && (
                    <button
                      type="button"
                      onClick={() => onNavigateTab('search')}
                      className="px-2.5 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 rounded-lg text-xs font-semibold flex items-center gap-1 transition cursor-pointer"
                    >
                      <span>الانتقال للبحث</span>
                      <ArrowRight className="w-3 h-3" />
                    </button>
                  )}

                  {task.category === 'outreach' && (
                    <button
                      type="button"
                      onClick={() => onNavigateTab('campaigns')}
                      className="px-2.5 py-1 bg-blue-50 hover:bg-blue-100 text-blue-800 rounded-lg text-xs font-semibold flex items-center gap-1 transition cursor-pointer"
                    >
                      <span>تنفيذ الحملة</span>
                      <ArrowRight className="w-3 h-3" />
                    </button>
                  )}

                  {task.category === 'replies' && (
                    <button
                      type="button"
                      onClick={() => onNavigateTab('autoReply')}
                      className="px-2.5 py-1 bg-purple-50 hover:bg-purple-100 text-purple-800 rounded-lg text-xs font-semibold flex items-center gap-1 transition cursor-pointer"
                    >
                      <span>صندوق الردود</span>
                      <ArrowRight className="w-3 h-3" />
                    </button>
                  )}

                  <button
                    type="button"
                    onClick={() => onDeleteTask(task.id)}
                    className="p-1.5 text-stone-300 hover:text-rose-600 transition cursor-pointer"
                    title="حذف المهمة"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
