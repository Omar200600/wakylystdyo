import React from 'react';
import {
  Search,
  Users,
  Send,
  Bot,
  CheckSquare,
  MessageCircle,
  Sparkles,
  Phone,
  FileText,
  TrendingUp,
  DollarSign,
  Zap,
} from 'lucide-react';
import { AgencyProfile, DailyTask, Lead } from '../types';

interface HeaderProps {
  activeTab: 'search' | 'leads' | 'campaigns' | 'templates' | 'analytics' | 'sales' | 'autoReply' | 'tasks';
  setActiveTab: (tab: 'search' | 'leads' | 'campaigns' | 'templates' | 'analytics' | 'sales' | 'autoReply' | 'tasks') => void;
  leads: Lead[];
  tasks: DailyTask[];
  agencyProfile: AgencyProfile;
  templatesCount?: number;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  leads,
  tasks,
  agencyProfile,
  templatesCount = 7,
}) => {
  const validLeadsCount = leads.filter((l) => l.isWhatsappValid).length;
  const pendingTasksCount = tasks.filter((t) => !t.completed).length;

  const tabs = [
    {
      id: 'search' as const,
      label: 'البحث والتنقيب الذكي',
      icon: Search,
      badge: 'ذكاء اصطناعي',
    },
    {
      id: 'leads' as const,
      label: 'قاعدة البيانات والتصفية',
      icon: Users,
      count: validLeadsCount,
    },
    {
      id: 'templates' as const,
      label: 'مكتبة قوالب الرسائل',
      icon: FileText,
      count: templatesCount,
    },
    {
      id: 'campaigns' as const,
      label: 'إرسال الحملات بالدفعات',
      icon: Send,
    },
    {
      id: 'sales' as const,
      label: 'وكيل المبيعات والتقرير',
      icon: DollarSign,
      badge: 'بيع واستئجار',
      highlight: true,
    },
    {
      id: 'analytics' as const,
      label: 'تحليلات أداء الحملات',
      icon: TrendingUp,
      badge: 'مباشر',
    },
    {
      id: 'autoReply' as const,
      label: 'وكيل الرد وبيانات العمل',
      icon: Bot,
      highlight: true,
    },
    {
      id: 'tasks' as const,
      label: 'إدارة المهام اليومية',
      icon: CheckSquare,
      count: pendingTasksCount,
    },
  ];

  return (
    <header className="bg-white border-b border-stone-200 sticky top-0 z-30 shadow-xs">
      {/* Top Banner with Agency & Contact Info */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center shadow-sm">
            <Bot className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-bold text-stone-900 tracking-tight">
                وكيل المهام والتسويق الذكي
              </h1>
              <span className="text-xs bg-emerald-50 text-emerald-700 font-medium px-2 py-0.5 rounded-full border border-emerald-200">
                مفعل بـ Gemini & Google Search
              </span>
            </div>
            <p className="text-xs text-stone-500">
              تنقيب المدارس والشركات • تصفية الأرقام • إرسال الدفعات • ردود ذكية برقمك
            </p>
          </div>
        </div>

        {/* Quick Stats & Dedicated WhatsApp Display */}
        <div className="flex items-center gap-3 text-xs">
          <div className="hidden md:flex items-center gap-2 bg-stone-50 border border-stone-200 rounded-lg px-3 py-1.5 text-stone-700">
            <span className="text-stone-400">الجهات الصالحة:</span>
            <span className="font-bold text-emerald-700">{validLeadsCount}</span>
            <span className="text-stone-300">|</span>
            <span className="text-stone-400">مهام اليوم:</span>
            <span className="font-bold text-amber-700">{pendingTasksCount}</span>
          </div>

          <div className="flex items-center gap-2 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-lg px-3 py-1.5">
            <MessageCircle className="w-4 h-4 text-emerald-600" />
            <span>رقم الواتساب المعتمد:</span>
            <span className="font-bold font-mono dir-ltr select-all">
              {agencyProfile.myWhatsapp || '00667737219181'}
            </span>
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 border-t border-stone-100">
        <nav className="flex space-x-reverse space-x-1 sm:space-x-2 overflow-x-auto py-2 scrollbar-none">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                id={`tab-${tab.id}`}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-sm font-medium transition-all whitespace-nowrap cursor-pointer ${
                  isActive
                    ? 'bg-stone-900 text-white shadow-xs'
                    : 'text-stone-600 hover:text-stone-900 hover:bg-stone-100'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-emerald-400' : 'text-stone-400'}`} />
                <span>{tab.label}</span>
                {tab.badge && (
                  <span className={`text-[10px] px-1.5 py-0.5 rounded-full font-bold ${
                    isActive ? 'bg-emerald-500 text-stone-950' : 'bg-emerald-100 text-emerald-800'
                  }`}>
                    {tab.badge}
                  </span>
                )}
                {typeof tab.count === 'number' && (
                  <span className={`text-[11px] px-2 py-0.2 rounded-full font-bold ${
                    isActive ? 'bg-stone-800 text-stone-200' : 'bg-stone-200 text-stone-700'
                  }`}>
                    {tab.count}
                  </span>
                )}
              </button>
            );
          })}
        </nav>
      </div>
    </header>
  );
};
