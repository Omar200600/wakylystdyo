import React, { useState, useMemo } from 'react';
import {
  TrendingUp,
  School,
  Building2,
  MailCheck,
  MessageCircle,
  Flame,
  CheckCircle2,
  Users,
  FileSpreadsheet,
  Calendar,
  Filter,
  ArrowUpRight,
  ExternalLink,
  Edit,
  Sparkles,
  Award,
  AlertTriangle,
  Clock,
  Send,
  RefreshCw,
} from 'lucide-react';
import { Lead, AgencyProfile } from '../types';
import { exportAnalyticsReportToExcel } from '../utils/exportUtils';

interface CampaignAnalyticsProps {
  leads: Lead[];
  agencyProfile: AgencyProfile;
  onUpdateLead: (updatedLead: Lead) => void;
  onNavigateToWhatsApp?: (lead: Lead) => void;
}

export const CampaignAnalytics: React.FC<CampaignAnalyticsProps> = ({
  leads,
  agencyProfile,
  onUpdateLead,
  onNavigateToWhatsApp,
}) => {
  // Interest filter state
  const [interestFilter, setInterestFilter] = useState<string>('all');
  const [sectorFilter, setSectorFilter] = useState<'all' | 'school' | 'company'>('all');
  const [searchQuery, setSearchQuery] = useState('');

  // Response Update Modal State
  const [isReplyModalOpen, setIsReplyModalOpen] = useState(false);
  const [selectedLeadForReply, setSelectedLeadForReply] = useState<Lead | null>(null);
  const [replyTextInput, setReplyTextInput] = useState('');
  const [interestLevelInput, setInterestLevelInput] = useState<Lead['interestLevel']>('hot');
  const [statusInput, setStatusInput] = useState<Lead['status']>('replied');
  const [isGeneratingAiNextStep, setIsGeneratingAiNextStep] = useState(false);
  const [aiNextStepAdvice, setAiNextStepAdvice] = useState<string | null>(null);

  // Overall statistics calculation
  const stats = useMemo(() => {
    const contacted = leads.filter(
      (l) => l.status === 'contacted' || l.status === 'replied' || l.status === 'converted'
    );
    const totalSent = contacted.length;

    // WhatsApp open rate estimated typically at 90-95% for delivered valid numbers
    const estimatedOpenedCount = contacted.filter((l) => l.estimatedOpened || l.isWhatsappValid).length;
    const openRate = totalSent > 0 ? Math.round((estimatedOpenedCount / totalSent) * 100) : 0;

    const replied = leads.filter((l) => l.status === 'replied' || l.status === 'converted');
    const totalReplied = replied.length;
    const responseRate = totalSent > 0 ? Math.round((totalReplied / totalSent) * 100) : 0;

    const hotLeads = leads.filter((l) => l.interestLevel === 'hot');
    const warmLeads = leads.filter((l) => l.interestLevel === 'warm');
    const followupLeads = leads.filter((l) => l.interestLevel === 'followup');
    const convertedLeads = leads.filter((l) => l.status === 'converted' || l.interestLevel === 'converted');
    const notInterestedLeads = leads.filter((l) => l.interestLevel === 'not_interested');

    const totalInterested = hotLeads.length + warmLeads.length;

    // School statistics
    const schoolLeads = leads.filter((l) => l.category === 'school');
    const schoolSent = schoolLeads.filter(
      (l) => l.status === 'contacted' || l.status === 'replied' || l.status === 'converted'
    ).length;
    const schoolReplied = schoolLeads.filter((l) => l.status === 'replied' || l.status === 'converted').length;
    const schoolResponseRate = schoolSent > 0 ? Math.round((schoolReplied / schoolSent) * 100) : 0;
    const schoolInterested = schoolLeads.filter((l) => l.interestLevel === 'hot' || l.interestLevel === 'warm').length;

    // Company statistics
    const companyLeads = leads.filter((l) => l.category === 'company');
    const companySent = companyLeads.filter(
      (l) => l.status === 'contacted' || l.status === 'replied' || l.status === 'converted'
    ).length;
    const companyReplied = companyLeads.filter((l) => l.status === 'replied' || l.status === 'converted').length;
    const companyResponseRate = companySent > 0 ? Math.round((companyReplied / companySent) * 100) : 0;
    const companyInterested = companyLeads.filter((l) => l.interestLevel === 'hot' || l.interestLevel === 'warm').length;

    return {
      totalLeads: leads.length,
      totalSent,
      estimatedOpenedCount,
      openRate,
      totalReplied,
      responseRate,
      hotCount: hotLeads.length,
      warmCount: warmLeads.length,
      followupCount: followupLeads.length,
      convertedCount: convertedLeads.length,
      notInterestedCount: notInterestedLeads.length,
      totalInterested,
      schools: {
        total: schoolLeads.length,
        sent: schoolSent,
        replied: schoolReplied,
        responseRate: schoolResponseRate,
        interested: schoolInterested,
      },
      companies: {
        total: companyLeads.length,
        sent: companySent,
        replied: companyReplied,
        responseRate: companyResponseRate,
        interested: companyInterested,
      },
    };
  }, [leads]);

  // Filtered Leads List (Focused on contacted, replied, or interested leads)
  const qualifiedLeads = useMemo(() => {
    return leads.filter((lead) => {
      // Must have had some interaction or reply, or all if user wants
      const hasInteraction =
        lead.status === 'contacted' ||
        lead.status === 'replied' ||
        lead.status === 'converted' ||
        Boolean(lead.replyText) ||
        Boolean(lead.interestLevel);

      if (!hasInteraction) return false;

      // Sector Filter
      if (sectorFilter !== 'all' && lead.category !== sectorFilter) {
        return false;
      }

      // Interest Filter
      if (interestFilter === 'hot' && lead.interestLevel !== 'hot') return false;
      if (interestFilter === 'warm' && lead.interestLevel !== 'warm') return false;
      if (interestFilter === 'interested' && lead.interestLevel !== 'hot' && lead.interestLevel !== 'warm') return false;
      if (interestFilter === 'followup' && lead.interestLevel !== 'followup') return false;
      if (interestFilter === 'converted' && lead.status !== 'converted' && lead.interestLevel !== 'converted') return false;
      if (interestFilter === 'not_interested' && lead.interestLevel !== 'not_interested') return false;

      // Search Query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchesName = lead.name.toLowerCase().includes(q);
        const matchesCity = lead.city.toLowerCase().includes(q);
        const matchesReply = lead.replyText?.toLowerCase().includes(q);
        if (!matchesName && !matchesCity && !matchesReply) return false;
      }

      return true;
    });
  }, [leads, sectorFilter, interestFilter, searchQuery]);

  // Open Reply / Status update modal
  const handleOpenReplyModal = (lead: Lead) => {
    setSelectedLeadForReply(lead);
    setReplyTextInput(lead.replyText || '');
    setInterestLevelInput(lead.interestLevel || 'hot');
    setStatusInput(lead.status === 'new' ? 'replied' : lead.status);
    setAiNextStepAdvice(null);
    setIsReplyModalOpen(true);
  };

  // Save updated reply & interest status
  const handleSaveReply = () => {
    if (!selectedLeadForReply) return;

    const updated: Lead = {
      ...selectedLeadForReply,
      status: statusInput,
      interestLevel: interestLevelInput,
      replyText: replyTextInput.trim() || undefined,
      repliedAt: selectedLeadForReply.repliedAt || new Date().toLocaleString('ar-SA', { dateStyle: 'short', timeStyle: 'short' }),
      estimatedOpened: true,
    };

    onUpdateLead(updated);
    setIsReplyModalOpen(false);
  };

  // AI Next-Step advice for this specific lead
  const handleGetAiAdvice = async () => {
    if (!selectedLeadForReply) return;
    setIsGeneratingAiNextStep(true);
    setAiNextStepAdvice(null);

    try {
      const prompt = `أنت مستشار مبيعات B2B محترف لحملات الواتساب.
لدينا عميل محتمل:
- اسم الجهة: ${selectedLeadForReply.name} (${selectedLeadForReply.categoryLabel || selectedLeadForReply.category})
- المدينة: ${selectedLeadForReply.city}
- تصنيف الاهتمام الحالي: ${interestLevelInput}
- رد العميل الوارد: "${replyTextInput || 'طلب تفاصيل إضافية عن الأسعار والخدمات'}"

المطلوب:
أعطني نصيحة سريعة في نقطتين ونموذج رسالة واتساب مقترحة (لا تتجاوز 4 أسطر) لإغلاق الصفقة وتحديد موعد اجتماع معه.`;

      const res = await fetch('/api/agency/ai-reply', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          clientName: selectedLeadForReply.name,
          clientType: selectedLeadForReply.categoryLabel,
          incomingMessage: replyTextInput || 'مرحباً، مهتم بالخدمات وأريد معرفة الأسعار',
          agencyProfile,
        }),
      });

      const data = await res.json();
      if (data.success && data.reply) {
        setAiNextStepAdvice(data.reply);
      } else {
        setAiNextStepAdvice(`مقترح الرد المباشر:\nأهلاً وسهلاً بكم إدارة ${selectedLeadForReply.name}. يسعدنا خدمتكم ونقترح ترتيب جلسة زووم سريعة غداً لاستعراض الباقة المخصصة لكم. ما هو الوقت الأنسب؟`);
      }
    } catch (e) {
      setAiNextStepAdvice(`مقترح الرد:\nأهلاً وسهلاً بكم إدارة ${selectedLeadForReply.name}. يسعدنا مشاركة ملف الأسعار والخدمات، ويمكننا التنسيق لجلسة تعريفية سريعة. للتواصل المباشر: ${agencyProfile.myWhatsapp}`);
    } finally {
      setIsGeneratingAiNextStep(false);
    }
  };

  // Export Analytics to Excel
  const handleExportReport = () => {
    exportAnalyticsReportToExcel(leads, agencyProfile);
  };

  return (
    <div className="space-y-6">
      {/* Header & Export Bar */}
      <div className="bg-white rounded-xl border border-stone-200 p-5 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-start sm:items-center gap-3">
          <div className="w-11 h-11 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center border border-emerald-200 shrink-0">
            <TrendingUp className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-lg font-bold text-stone-900">
                لوحة تحليلات أداء الحملات والعملاء المهتمين
              </h2>
              <span className="text-[11px] bg-emerald-100 text-emerald-800 font-bold px-2 py-0.5 rounded-full">
                تحديث مباشر
              </span>
            </div>
            <p className="text-xs text-stone-500 mt-0.5">
              تتبع معدلات فتح الرسائل، مقارنة استجابات المدارس والشركات، وتحديد العملاء الأكثر اهتماماً لسرعة إغلاق الصفقات.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={handleExportReport}
            className="inline-flex items-center gap-1.5 px-4 py-2 bg-emerald-700 hover:bg-emerald-800 active:scale-95 text-white rounded-lg text-xs font-bold transition shadow-xs cursor-pointer"
          >
            <FileSpreadsheet className="w-4 h-4" />
            <span>تصدير تقرير التحليلات (Excel)</span>
          </button>
        </div>
      </div>

      {/* Main KPI Cards Grid */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3.5">
        {/* Card 1: Total Outreach Sent */}
        <div className="bg-white rounded-xl border border-stone-200 p-4 shadow-xs">
          <div className="flex items-center justify-between text-stone-500 mb-2">
            <span className="text-xs font-medium">رسائل الحملات</span>
            <Send className="w-4 h-4 text-purple-600" />
          </div>
          <div className="text-2xl font-bold text-stone-900">{stats.totalSent}</div>
          <p className="text-[11px] text-stone-400 mt-1">من إجمالي {stats.totalLeads} جهة بقاعدتك</p>
        </div>

        {/* Card 2: Estimated Open Rate */}
        <div className="bg-white rounded-xl border border-stone-200 p-4 shadow-xs">
          <div className="flex items-center justify-between text-stone-500 mb-2">
            <span className="text-xs font-medium">معدل الفتح المقدر</span>
            <MailCheck className="w-4 h-4 text-blue-600" />
          </div>
          <div className="flex items-baseline gap-1.5">
            <span className="text-2xl font-bold text-stone-900">{stats.openRate}%</span>
            <span className="text-[11px] text-emerald-600 font-bold">~{stats.estimatedOpenedCount} مفتوحة</span>
          </div>
          <p className="text-[11px] text-stone-400 mt-1">بناءً على الأرقام المتسقة المقروءة</p>
        </div>

        {/* Card 3: Overall Response Rate */}
        <div className="bg-white rounded-xl border border-stone-200 p-4 shadow-xs">
          <div className="flex items-center justify-between text-stone-500 mb-2">
            <span className="text-xs font-medium">معدل الاستجابة العام</span>
            <MessageCircle className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="flex items-baseline gap-1.5">
            <span className="text-2xl font-bold text-emerald-700">{stats.responseRate}%</span>
            <span className="text-[11px] text-stone-500 font-medium">({stats.totalReplied} رد وارد)</span>
          </div>
          <p className="text-[11px] text-stone-400 mt-1">نسبة الردود على رسائل الواتساب</p>
        </div>

        {/* Card 4: Hot & Warm Leads */}
        <div className="bg-white rounded-xl border border-stone-200 p-4 shadow-xs">
          <div className="flex items-center justify-between text-stone-500 mb-2">
            <span className="text-xs font-medium">العملاء المهتمون</span>
            <Flame className="w-4 h-4 text-rose-500" />
          </div>
          <div className="flex items-baseline gap-1.5">
            <span className="text-2xl font-bold text-rose-600">{stats.totalInterested}</span>
            <span className="text-[11px] text-rose-700 font-bold">({stats.hotCount} عالي الاهتمام)</span>
          </div>
          <p className="text-[11px] text-stone-400 mt-1">أبدوا تفاعلاً لطلب أسعار واجتماعات</p>
        </div>

        {/* Card 5: Converted Deals */}
        <div className="bg-white rounded-xl border border-stone-200 p-4 shadow-xs col-span-2 md:col-span-1">
          <div className="flex items-center justify-between text-stone-500 mb-2">
            <span className="text-xs font-medium">الصفقات الناجحة</span>
            <Award className="w-4 h-4 text-amber-500" />
          </div>
          <div className="flex items-baseline gap-1.5">
            <span className="text-2xl font-bold text-amber-700">{stats.convertedCount}</span>
            <span className="text-[11px] text-emerald-600 font-bold">معتمدة</span>
          </div>
          <p className="text-[11px] text-stone-400 mt-1">تم توقيع العقد وبدء الخدمة</p>
        </div>
      </div>

      {/* Sector Comparison: Schools vs Companies */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {/* Schools Performance */}
        <div className="bg-white rounded-xl border border-stone-200 p-5 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-lg bg-blue-50 text-blue-700 flex items-center justify-center border border-blue-200">
                <School className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-stone-900">المدارس الأهلية والدولية</h3>
                <p className="text-xs text-stone-500">حملات استقطاب وتسجيل الطلاب والقبول</p>
              </div>
            </div>
            <div className="text-right">
              <span className="text-lg font-bold text-blue-700">{stats.schools.responseRate}%</span>
              <p className="text-[10px] text-stone-400">معدل الاستجابة</p>
            </div>
          </div>

          {/* Progress Bar */}
          <div className="w-full bg-stone-100 rounded-full h-2.5 overflow-hidden">
            <div
              className="bg-blue-600 h-2.5 rounded-full transition-all duration-500"
              style={{ width: `${Math.min(stats.schools.responseRate, 100)}%` }}
            />
          </div>

          <div className="grid grid-cols-3 gap-2 pt-1 text-center">
            <div className="bg-blue-50/50 p-2.5 rounded-lg border border-blue-100">
              <div className="text-xs text-stone-500">تم الإرسال</div>
              <div className="text-sm font-bold text-stone-800">{stats.schools.sent}</div>
            </div>
            <div className="bg-blue-50/50 p-2.5 rounded-lg border border-blue-100">
              <div className="text-xs text-stone-500">الردود الواردة</div>
              <div className="text-sm font-bold text-blue-700">{stats.schools.replied}</div>
            </div>
            <div className="bg-blue-50/50 p-2.5 rounded-lg border border-blue-100">
              <div className="text-xs text-stone-500">مهتمون فعلياً</div>
              <div className="text-sm font-bold text-rose-600">{stats.schools.interested}</div>
            </div>
          </div>
        </div>

        {/* Companies Performance */}
        <div className="bg-white rounded-xl border border-stone-200 p-5 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-lg bg-emerald-50 text-emerald-700 flex items-center justify-center border border-emerald-200">
                <Building2 className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-stone-900">الشركات والمؤسسات العالمية</h3>
                <p className="text-xs text-stone-500">حلول الأتمتة المؤسسية والذكاء الاصطناعي</p>
              </div>
            </div>
            <div className="text-right">
              <span className="text-lg font-bold text-emerald-700">{stats.companies.responseRate}%</span>
              <p className="text-[10px] text-stone-400">معدل الاستجابة</p>
            </div>
          </div>

          {/* Progress Bar */}
          <div className="w-full bg-stone-100 rounded-full h-2.5 overflow-hidden">
            <div
              className="bg-emerald-600 h-2.5 rounded-full transition-all duration-500"
              style={{ width: `${Math.min(stats.companies.responseRate, 100)}%` }}
            />
          </div>

          <div className="grid grid-cols-3 gap-2 pt-1 text-center">
            <div className="bg-emerald-50/50 p-2.5 rounded-lg border border-emerald-100">
              <div className="text-xs text-stone-500">تم الإرسال</div>
              <div className="text-sm font-bold text-stone-800">{stats.companies.sent}</div>
            </div>
            <div className="bg-emerald-50/50 p-2.5 rounded-lg border border-emerald-100">
              <div className="text-xs text-stone-500">الردود الواردة</div>
              <div className="text-sm font-bold text-emerald-700">{stats.companies.replied}</div>
            </div>
            <div className="bg-emerald-50/50 p-2.5 rounded-lg border border-emerald-100">
              <div className="text-xs text-stone-500">مهتمون فعلياً</div>
              <div className="text-sm font-bold text-rose-600">{stats.companies.interested}</div>
            </div>
          </div>
        </div>
      </div>

      {/* Conversion Funnel (قمع التحويل) */}
      <div className="bg-white rounded-xl border border-stone-200 p-5 shadow-xs space-y-3">
        <h3 className="text-sm font-bold text-stone-900">قمع التحويل الإعلاني (Campaign Conversion Funnel)</h3>
        <p className="text-xs text-stone-500">
          مسار العميل المحتمل من استخراج البيانات وحتى إتمام التعاقد.
        </p>

        <div className="grid grid-cols-2 md:grid-cols-5 gap-2 pt-2">
          {/* Step 1 */}
          <div className="bg-stone-50 border border-stone-200 rounded-xl p-3 text-center">
            <span className="text-[10px] font-bold text-stone-400 block mb-1">المرحلة 1</span>
            <div className="text-xs font-bold text-stone-800">مؤهل للإرسال</div>
            <div className="text-lg font-extrabold text-stone-900 mt-1">{stats.totalLeads}</div>
            <span className="text-[10px] text-stone-500">100% من القاعدة</span>
          </div>

          {/* Step 2 */}
          <div className="bg-purple-50/60 border border-purple-200 rounded-xl p-3 text-center">
            <span className="text-[10px] font-bold text-purple-600 block mb-1">المرحلة 2</span>
            <div className="text-xs font-bold text-purple-900">تم الإرسال</div>
            <div className="text-lg font-extrabold text-purple-700 mt-1">{stats.totalSent}</div>
            <span className="text-[10px] text-purple-700">
              {stats.totalLeads > 0 ? Math.round((stats.totalSent / stats.totalLeads) * 100) : 0}% من الإجمالي
            </span>
          </div>

          {/* Step 3 */}
          <div className="bg-blue-50/60 border border-blue-200 rounded-xl p-3 text-center">
            <span className="text-[10px] font-bold text-blue-600 block mb-1">المرحلة 3</span>
            <div className="text-xs font-bold text-blue-900">فتح وقراءة الرسالة</div>
            <div className="text-lg font-extrabold text-blue-700 mt-1">{stats.estimatedOpenedCount}</div>
            <span className="text-[10px] text-blue-700">{stats.openRate}% معدل القراءة</span>
          </div>

          {/* Step 4 */}
          <div className="bg-emerald-50/60 border border-emerald-200 rounded-xl p-3 text-center">
            <span className="text-[10px] font-bold text-emerald-600 block mb-1">المرحلة 4</span>
            <div className="text-xs font-bold text-emerald-900">الرد وإبداء الاهتمام</div>
            <div className="text-lg font-extrabold text-emerald-700 mt-1">{stats.totalReplied}</div>
            <span className="text-[10px] text-emerald-700">{stats.responseRate}% معدل التجاوب</span>
          </div>

          {/* Step 5 */}
          <div className="bg-amber-50/60 border border-amber-200 rounded-xl p-3 text-center col-span-2 md:col-span-1">
            <span className="text-[10px] font-bold text-amber-600 block mb-1">المرحلة 5</span>
            <div className="text-xs font-bold text-amber-900">الصفقات المغلقة</div>
            <div className="text-lg font-extrabold text-amber-700 mt-1">{stats.convertedCount}</div>
            <span className="text-[10px] text-amber-700">
              {stats.totalSent > 0 ? Math.round((stats.convertedCount / stats.totalSent) * 100) : 0}% تحويل نهائي
            </span>
          </div>
        </div>
      </div>

      {/* Qualified Leads & Responses Hub */}
      <div className="bg-white rounded-xl border border-stone-200 p-5 shadow-xs space-y-4">
        {/* Filters and search header */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pb-3 border-b border-stone-100">
          <div>
            <h3 className="text-sm font-bold text-stone-900 flex items-center gap-2">
              <span>سجل ردود العملاء والفرص المهتمة</span>
              <span className="text-xs bg-rose-100 text-rose-800 font-bold px-2 py-0.5 rounded-full">
                {qualifiedLeads.length} عميل في هذا العرض
              </span>
            </h3>
            <p className="text-xs text-stone-500">
              انقر على أي عميل لتسجيل وتعديل رده أو تغيير درجة اهتمامه، أو فتح محادثة واتساب فورية معه.
            </p>
          </div>

          {/* Search Box */}
          <div className="w-full sm:w-64">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="بحث في أسماء الجهات أو نص الرد..."
              className="w-full p-2 border border-stone-300 rounded-lg text-xs"
            />
          </div>
        </div>

        {/* Filter Pills */}
        <div className="flex flex-wrap items-center justify-between gap-2">
          {/* Interest filter buttons */}
          <div className="flex flex-wrap gap-1.5 text-xs">
            <button
              type="button"
              onClick={() => setInterestFilter('all')}
              className={`px-3 py-1 rounded-lg font-medium transition cursor-pointer ${
                interestFilter === 'all'
                  ? 'bg-stone-900 text-white font-bold'
                  : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
              }`}
            >
              الكل ({stats.totalSent})
            </button>

            <button
              type="button"
              onClick={() => setInterestFilter('hot')}
              className={`px-3 py-1 rounded-lg font-medium transition cursor-pointer flex items-center gap-1 ${
                interestFilter === 'hot'
                  ? 'bg-rose-600 text-white font-bold'
                  : 'bg-rose-50 text-rose-700 hover:bg-rose-100 border border-rose-200'
              }`}
            >
              <Flame className="w-3.5 h-3.5" />
              <span>عالي الاهتمام ({stats.hotCount})</span>
            </button>

            <button
              type="button"
              onClick={() => setInterestFilter('warm')}
              className={`px-3 py-1 rounded-lg font-medium transition cursor-pointer flex items-center gap-1 ${
                interestFilter === 'warm'
                  ? 'bg-amber-600 text-white font-bold'
                  : 'bg-amber-50 text-amber-800 hover:bg-amber-100 border border-amber-200'
              }`}
            >
              <span>استفسار دافئ ({stats.warmCount})</span>
            </button>

            <button
              type="button"
              onClick={() => setInterestFilter('followup')}
              className={`px-3 py-1 rounded-lg font-medium transition cursor-pointer ${
                interestFilter === 'followup'
                  ? 'bg-blue-600 text-white font-bold'
                  : 'bg-blue-50 text-blue-700 hover:bg-blue-100 border border-blue-200'
              }`}
            >
              متابعة لاحقة ({stats.followupCount})
            </button>

            <button
              type="button"
              onClick={() => setInterestFilter('converted')}
              className={`px-3 py-1 rounded-lg font-medium transition cursor-pointer ${
                interestFilter === 'converted'
                  ? 'bg-emerald-600 text-white font-bold'
                  : 'bg-emerald-50 text-emerald-700 hover:bg-emerald-100 border border-emerald-200'
              }`}
            >
              صفقات ناجحة ({stats.convertedCount})
            </button>
          </div>

          {/* Sector Toggle */}
          <div className="flex items-center gap-1 text-xs bg-stone-100 p-1 rounded-lg">
            <button
              type="button"
              onClick={() => setSectorFilter('all')}
              className={`px-2 py-0.5 rounded text-[11px] font-semibold transition cursor-pointer ${
                sectorFilter === 'all' ? 'bg-white text-stone-900 shadow-2xs' : 'text-stone-600'
              }`}
            >
              كافة القطاعات
            </button>
            <button
              type="button"
              onClick={() => setSectorFilter('school')}
              className={`px-2 py-0.5 rounded text-[11px] font-semibold transition cursor-pointer ${
                sectorFilter === 'school' ? 'bg-white text-blue-700 shadow-2xs' : 'text-stone-600'
              }`}
            >
              المدارس فقط
            </button>
            <button
              type="button"
              onClick={() => setSectorFilter('company')}
              className={`px-2 py-0.5 rounded text-[11px] font-semibold transition cursor-pointer ${
                sectorFilter === 'company' ? 'bg-white text-emerald-700 shadow-2xs' : 'text-stone-600'
              }`}
            >
              الشركات فقط
            </button>
          </div>
        </div>

        {/* Qualified Leads Table / Cards */}
        {qualifiedLeads.length > 0 ? (
          <div className="space-y-3">
            {qualifiedLeads.map((lead) => {
              const isHot = lead.interestLevel === 'hot';
              const isWarm = lead.interestLevel === 'warm';
              const isConverted = lead.status === 'converted' || lead.interestLevel === 'converted';

              return (
                <div
                  key={lead.id}
                  className={`rounded-xl border p-4 transition-all flex flex-col md:flex-row md:items-center justify-between gap-4 ${
                    isHot
                      ? 'bg-rose-50/40 border-rose-200 hover:border-rose-400'
                      : isConverted
                        ? 'bg-emerald-50/40 border-emerald-200 hover:border-emerald-400'
                        : isWarm
                          ? 'bg-amber-50/30 border-amber-200 hover:border-amber-400'
                          : 'bg-white border-stone-200 hover:border-stone-300'
                  }`}
                >
                  {/* Lead Info & Incoming Message */}
                  <div className="space-y-2 max-w-2xl">
                    <div className="flex flex-wrap items-center gap-2">
                      <h4 className="text-sm font-bold text-stone-900">{lead.name}</h4>
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                          lead.category === 'school'
                            ? 'bg-blue-100 text-blue-800'
                            : 'bg-emerald-100 text-emerald-800'
                        }`}
                      >
                        {lead.categoryLabel || (lead.category === 'school' ? 'مدرسة أهلية' : 'شركة عالمية')}
                      </span>
                      <span className="text-xs text-stone-500 font-medium">
                        📍 {lead.city} - {lead.country}
                      </span>
                    </div>

                    {/* Incoming Reply Box */}
                    {lead.replyText ? (
                      <div className="bg-white rounded-lg p-2.5 border border-stone-200 text-xs text-stone-800 space-y-1">
                        <div className="flex items-center justify-between text-[10px] text-stone-400">
                          <span className="font-bold text-stone-600 flex items-center gap-1">
                            <MessageCircle className="w-3 h-3 text-emerald-600" />
                            رد العميل الوارد:
                          </span>
                          <span>{lead.repliedAt || 'مؤخراً'}</span>
                        </div>
                        <p className="leading-relaxed text-stone-900 select-text font-sans">
                          "{lead.replyText}"
                        </p>
                      </div>
                    ) : (
                      <p className="text-xs text-stone-500 italic">
                        تم إرسال الرسالة الإعلانية وبانتظار رد العميل أو تسجيل المتابعة الهاتفية.
                      </p>
                    )}

                    {/* WhatsApp & Email Quick Contacts */}
                    <div className="flex flex-wrap items-center gap-3 text-xs text-stone-600">
                      <span className="font-mono text-stone-800 font-semibold dir-ltr">
                        📱 {lead.whatsappNumber || lead.rawPhone}
                      </span>
                      {lead.email && <span className="text-stone-500">✉️ {lead.email}</span>}
                    </div>
                  </div>

                  {/* Status Badges & Quick Action Controls */}
                  <div className="flex flex-col sm:flex-row md:flex-col items-start md:items-end gap-2 shrink-0">
                    {/* Interest Badge */}
                    <div className="flex items-center gap-1.5">
                      {isHot && (
                        <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-rose-100 text-rose-800 font-bold text-xs rounded-full border border-rose-300">
                          <Flame className="w-3.5 h-3.5 text-rose-600" />
                          <span>عميل مهتم جداً (Hot)</span>
                        </span>
                      )}
                      {isWarm && (
                        <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-amber-100 text-amber-900 font-bold text-xs rounded-full border border-amber-300">
                          <span>استفسار دافئ (Warm)</span>
                        </span>
                      )}
                      {isConverted && (
                        <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-emerald-100 text-emerald-800 font-bold text-xs rounded-full border border-emerald-300">
                          <Award className="w-3.5 h-3.5 text-emerald-600" />
                          <span>صفقة معتمدة</span>
                        </span>
                      )}
                      {lead.interestLevel === 'followup' && (
                        <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-blue-100 text-blue-800 font-bold text-xs rounded-full border border-blue-300">
                          <Clock className="w-3.5 h-3.5" />
                          <span>متابعة لاحقة</span>
                        </span>
                      )}
                      {lead.interestLevel === 'not_interested' && (
                        <span className="px-2 py-0.5 bg-stone-100 text-stone-500 text-xs rounded-full">
                          غير مهتم
                        </span>
                      )}
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center gap-1.5 pt-1">
                      {/* Update Reply & Interest Button */}
                      <button
                        type="button"
                        onClick={() => handleOpenReplyModal(lead)}
                        className="inline-flex items-center gap-1 px-3 py-1.5 bg-stone-100 hover:bg-stone-200 text-stone-800 rounded-lg text-xs font-semibold transition cursor-pointer"
                        title="تسجيل رد العميل وتصنيف اهتمامه"
                      >
                        <Edit className="w-3.5 h-3.5 text-stone-600" />
                        <span>تسجيل رد العميل</span>
                      </button>

                      {/* Direct WhatsApp Chat */}
                      {lead.isWhatsappValid && lead.whatsappNumber && (
                        <a
                          href={`https://wa.me/${lead.whatsappNumber.replace(/[^0-9]/g, '')}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-1 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold transition shadow-2xs cursor-pointer"
                        >
                          <MessageCircle className="w-3.5 h-3.5" />
                          <span>محادثة واتساب</span>
                        </a>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="text-center py-10 border border-dashed border-stone-200 rounded-xl p-6 space-y-2">
            <Users className="w-8 h-8 text-stone-300 mx-auto" />
            <h4 className="text-xs font-bold text-stone-700">لا يوجد عملاء يطابقون الفلتر الحالي</h4>
            <p className="text-[11px] text-stone-400">
              قم بإرسال حملة إعلانية جديدة أو تغيير خيارات التصفية بالأعلى.
            </p>
          </div>
        )}
      </div>

      {/* Reply & Interest Level Modal */}
      {isReplyModalOpen && selectedLeadForReply && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/60 backdrop-blur-xs overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-xl w-full border border-stone-200 shadow-xl overflow-hidden my-6">
            <div className="px-6 py-4 border-b border-stone-100 flex items-center justify-between bg-stone-50">
              <div>
                <h3 className="text-base font-bold text-stone-900">
                  تسجيل رد العميل وتصنيف مستوى الاهتمام
                </h3>
                <p className="text-xs text-stone-500">
                  {selectedLeadForReply.name} ({selectedLeadForReply.city})
                </p>
              </div>
              <button
                type="button"
                onClick={() => setIsReplyModalOpen(false)}
                className="text-stone-400 hover:text-stone-700 text-sm font-bold"
              >
                ✕
              </button>
            </div>

            <div className="p-6 space-y-4">
              {/* Interest Level Selector */}
              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1.5">
                  تصنيف درجة اهتمام العميل:
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-xs">
                  <label
                    className={`flex items-center gap-2 p-2.5 rounded-lg border cursor-pointer ${
                      interestLevelInput === 'hot'
                        ? 'bg-rose-50 border-rose-300 text-rose-900 font-bold'
                        : 'bg-white border-stone-200 text-stone-700'
                    }`}
                  >
                    <input
                      type="radio"
                      name="interest"
                      value="hot"
                      checked={interestLevelInput === 'hot'}
                      onChange={() => setInterestLevelInput('hot')}
                      className="text-rose-600"
                    />
                    <span>🔥 عالي الاهتمام</span>
                  </label>

                  <label
                    className={`flex items-center gap-2 p-2.5 rounded-lg border cursor-pointer ${
                      interestLevelInput === 'warm'
                        ? 'bg-amber-50 border-amber-300 text-amber-900 font-bold'
                        : 'bg-white border-stone-200 text-stone-700'
                    }`}
                  >
                    <input
                      type="radio"
                      name="interest"
                      value="warm"
                      checked={interestLevelInput === 'warm'}
                      onChange={() => setInterestLevelInput('warm')}
                      className="text-amber-600"
                    />
                    <span>💬 استفسار دافئ</span>
                  </label>

                  <label
                    className={`flex items-center gap-2 p-2.5 rounded-lg border cursor-pointer ${
                      interestLevelInput === 'followup'
                        ? 'bg-blue-50 border-blue-300 text-blue-900 font-bold'
                        : 'bg-white border-stone-200 text-stone-700'
                    }`}
                  >
                    <input
                      type="radio"
                      name="interest"
                      value="followup"
                      checked={interestLevelInput === 'followup'}
                      onChange={() => setInterestLevelInput('followup')}
                      className="text-blue-600"
                    />
                    <span>⏳ بحاجة متابعة</span>
                  </label>

                  <label
                    className={`flex items-center gap-2 p-2.5 rounded-lg border cursor-pointer ${
                      interestLevelInput === 'converted'
                        ? 'bg-emerald-50 border-emerald-300 text-emerald-900 font-bold'
                        : 'bg-white border-stone-200 text-stone-700'
                    }`}
                  >
                    <input
                      type="radio"
                      name="interest"
                      value="converted"
                      checked={interestLevelInput === 'converted'}
                      onChange={() => {
                        setInterestLevelInput('converted');
                        setStatusInput('converted');
                      }}
                      className="text-emerald-600"
                    />
                    <span>🏆 صفقة معتمدة</span>
                  </label>

                  <label
                    className={`flex items-center gap-2 p-2.5 rounded-lg border cursor-pointer ${
                      interestLevelInput === 'not_interested'
                        ? 'bg-stone-100 border-stone-400 text-stone-900 font-bold'
                        : 'bg-white border-stone-200 text-stone-700'
                    }`}
                  >
                    <input
                      type="radio"
                      name="interest"
                      value="not_interested"
                      checked={interestLevelInput === 'not_interested'}
                      onChange={() => setInterestLevelInput('not_interested')}
                      className="text-stone-600"
                    />
                    <span>✖️ غير مهتم</span>
                  </label>
                </div>
              </div>

              {/* Reply Text */}
              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  نص رد العميل الوارد (المحادثة على الواتساب أو الهاتف):
                </label>
                <textarea
                  rows={4}
                  value={replyTextInput}
                  onChange={(e) => setReplyTextInput(e.target.value)}
                  placeholder="مثال: رحبوا بالعرض وطلبوا عقد اجتماع زووم يوم الثلاثاء القادم لمناقشة الأسعار..."
                  className="w-full p-3 border border-stone-300 rounded-xl text-xs leading-relaxed"
                />
              </div>

              {/* AI Quick Next Step Generator */}
              <div className="bg-stone-50 border border-stone-200 rounded-xl p-3.5 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-stone-900 flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-purple-600" />
                    المساعد الذكي لاقتراح الرد والخطوة القادمة:
                  </span>
                  <button
                    type="button"
                    onClick={handleGetAiAdvice}
                    disabled={isGeneratingAiNextStep}
                    className="px-2.5 py-1 bg-purple-700 hover:bg-purple-800 text-white rounded text-[11px] font-bold transition cursor-pointer disabled:opacity-50"
                  >
                    {isGeneratingAiNextStep ? 'جاري التحليل...' : 'اقتراح خطوة الإغلاق'}
                  </button>
                </div>

                {aiNextStepAdvice && (
                  <div className="bg-white p-3 rounded-lg border border-purple-200 text-xs text-stone-800 leading-relaxed whitespace-pre-line select-text">
                    {aiNextStepAdvice}
                  </div>
                )}
              </div>
            </div>

            {/* Modal Footer */}
            <div className="px-6 py-3.5 border-t border-stone-100 flex items-center justify-between bg-stone-50">
              <button
                type="button"
                onClick={() => setIsReplyModalOpen(false)}
                className="px-4 py-2 bg-stone-200 hover:bg-stone-300 text-stone-700 rounded-lg text-xs font-semibold"
              >
                إلغاء
              </button>

              <button
                type="button"
                onClick={handleSaveReply}
                className="px-5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg text-xs font-bold shadow-xs cursor-pointer active:scale-95"
              >
                حفظ التحديث والتحليلات
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
