import React, { useState, useEffect } from 'react';
import {
  Sparkles,
  MessageCircle,
  Copy,
  Check,
  X,
  Send,
  Loader2,
  School,
  Building2,
} from 'lucide-react';
import { Lead, AgencyProfile } from '../types';
import { generateWhatsAppChatUrl } from '../utils/phoneUtils';

interface CustomPitchModalProps {
  lead: Lead | null;
  agencyProfile: AgencyProfile;
  isOpen: boolean;
  onClose: () => void;
  onMarkContacted: (leadId: string) => void;
}

export const CustomPitchModal: React.FC<CustomPitchModalProps> = ({
  lead,
  agencyProfile,
  isOpen,
  onClose,
  onMarkContacted,
}) => {
  const [pitchText, setPitchText] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (isOpen && lead) {
      generatePitch();
    }
  }, [isOpen, lead]);

  const generatePitch = async () => {
    if (!lead) return;
    setIsLoading(true);
    try {
      const res = await fetch('/api/leads/pitch', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          lead,
          agencyProfile,
          tone: 'persuasive',
        }),
      });
      const data = await res.json();
      if (data.success && data.pitch) {
        setPitchText(data.pitch);
      }
    } catch (err) {
      console.error('Error generating pitch', err);
    } finally {
      setIsLoading(false);
    }
  };

  if (!isOpen || !lead) return null;

  const handleCopy = () => {
    navigator.clipboard.writeText(pitchText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSendToWhatsApp = () => {
    onMarkContacted(lead.id);
    const url = generateWhatsAppChatUrl(lead.whatsappNumber, pitchText);
    window.open(url, '_blank');
  };

  const isSchool = lead.category === 'school';

  return (
    <div className="fixed inset-0 bg-stone-900/50 backdrop-blur-xs z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-xl w-full p-6 shadow-2xl border border-stone-200 space-y-4 animate-in fade-in zoom-in-95 duration-150">
        <div className="flex items-start justify-between border-b border-stone-100 pb-3">
          <div className="flex items-center gap-2">
            <div className={`p-2 rounded-lg ${isSchool ? 'bg-blue-50 text-blue-700' : 'bg-amber-50 text-amber-700'}`}>
              {isSchool ? <School className="w-5 h-5" /> : <Building2 className="w-5 h-5" />}
            </div>
            <div>
              <h3 className="text-base font-bold text-stone-900">
                عرض أعمال وتسويق مخصص بالذكاء الاصطناعي
              </h3>
              <p className="text-xs text-stone-500">
                موجه خصيصاً إلى: <span className="font-bold text-stone-800">{lead.name}</span> ({lead.city} - {lead.country})
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1 rounded-lg text-stone-400 hover:text-stone-700 hover:bg-stone-100 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Loading State */}
        {isLoading ? (
          <div className="py-12 text-center space-y-2 text-stone-600">
            <Loader2 className="w-8 h-8 animate-spin text-emerald-600 mx-auto" />
            <p className="text-sm font-semibold">
              يقوم الوكيل الذكي الآن بصياغة عرض مخصص يتناسب مع نشاط {lead.name}...
            </p>
            <p className="text-xs text-stone-400">
              يتم دمج سابقة أعمالك ورقمك الواتس ({agencyProfile.myWhatsapp || '00667737219181'}) بدقة.
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            <div>
              <label className="block text-xs font-semibold text-stone-700 mb-1">
                نص الرسالة المقترح (يمكنك التعديل عليه بحرية):
              </label>
              <textarea
                value={pitchText}
                onChange={(e) => setPitchText(e.target.value)}
                rows={9}
                className="w-full p-3 border border-stone-300 rounded-xl text-xs leading-relaxed focus:ring-2 focus:ring-emerald-500 focus:outline-hidden font-sans"
              />
            </div>

            <div className="flex items-center justify-between text-xs text-stone-500">
              <span>الواتساب المستهدف: <span className="font-mono font-bold text-emerald-700 dir-ltr">{lead.whatsappNumber}</span></span>
              <button
                type="button"
                onClick={generatePitch}
                className="text-emerald-700 hover:underline flex items-center gap-1 cursor-pointer"
              >
                <Sparkles className="w-3.5 h-3.5" />
                إعادة التوليد بصيغة بديلة
              </button>
            </div>
          </div>
        )}

        {/* Modal Actions */}
        <div className="flex items-center justify-between pt-3 border-t border-stone-100">
          <button
            type="button"
            onClick={handleCopy}
            disabled={isLoading || !pitchText}
            className="px-3.5 py-2 border border-stone-300 hover:bg-stone-50 text-stone-700 rounded-lg text-xs font-medium flex items-center gap-1.5 cursor-pointer"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'تم النسخ' : 'نسخ الرسالة'}</span>
          </button>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-stone-600 text-xs font-medium hover:bg-stone-100 rounded-lg cursor-pointer"
            >
              إغلاق
            </button>
            <button
              type="button"
              onClick={handleSendToWhatsApp}
              disabled={isLoading || !pitchText || !lead.isWhatsappValid}
              className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white text-xs font-bold rounded-lg flex items-center gap-1.5 cursor-pointer shadow-xs disabled:bg-stone-300"
            >
              <MessageCircle className="w-4 h-4" />
              <span>إرسال عبر الواتساب فوراً</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
