import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { SearchSection } from './components/SearchSection';
import { LeadsTable } from './components/LeadsTable';
import { BatchCampaignSender } from './components/BatchCampaignSender';
import { TemplatesManager } from './components/TemplatesManager';
import { CampaignAnalytics } from './components/CampaignAnalytics';
import { AutonomousSalesAgent } from './components/AutonomousSalesAgent';
import { AgencyProfileAndAutoReply } from './components/AgencyProfileAndAutoReply';
import { DailyTasksView } from './components/DailyTasksView';
import { CustomPitchModal } from './components/CustomPitchModal';
import { Lead, DailyTask, AgencyProfile, MessageTemplate } from './types';
import {
  initialLeads,
  initialDailyTasks,
  initialAgencyProfile,
  initialMessageTemplates,
} from './utils/defaultData';

export default function App() {
  // Persistence in localStorage with fallbacks
  const [leads, setLeads] = useState<Lead[]>(() => {
    try {
      const saved = localStorage.getItem('agency_leads_data');
      return saved ? JSON.parse(saved) : initialLeads;
    } catch {
      return initialLeads;
    }
  });

  const [tasks, setTasks] = useState<DailyTask[]>(() => {
    try {
      const saved = localStorage.getItem('agency_daily_tasks');
      return saved ? JSON.parse(saved) : initialDailyTasks;
    } catch {
      return initialDailyTasks;
    }
  });

  const [agencyProfile, setAgencyProfile] = useState<AgencyProfile>(() => {
    try {
      const saved = localStorage.getItem('agency_profile_data');
      return saved ? JSON.parse(saved) : initialAgencyProfile;
    } catch {
      return initialAgencyProfile;
    }
  });

  const [templates, setTemplates] = useState<MessageTemplate[]>(() => {
    try {
      const saved = localStorage.getItem('agency_message_templates');
      return saved ? JSON.parse(saved) : initialMessageTemplates;
    } catch {
      return initialMessageTemplates;
    }
  });

  const [activeTab, setActiveTab] = useState<
    'search' | 'leads' | 'campaigns' | 'templates' | 'analytics' | 'sales' | 'autoReply' | 'tasks'
  >('sales');

  const [campaignLeadIds, setCampaignLeadIds] = useState<string[]>([]);
  const [pitchLead, setPitchLead] = useState<Lead | null>(null);
  const [campaignInitialMessage, setCampaignInitialMessage] = useState<string | undefined>(undefined);

  // Sync to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('agency_leads_data', JSON.stringify(leads));
    } catch (e) {
      console.warn('Storage save error', e);
    }
  }, [leads]);

  useEffect(() => {
    try {
      localStorage.setItem('agency_daily_tasks', JSON.stringify(tasks));
    } catch (e) {
      console.warn('Storage save error', e);
    }
  }, [tasks]);

  useEffect(() => {
    try {
      localStorage.setItem('agency_profile_data', JSON.stringify(agencyProfile));
    } catch (e) {
      console.warn('Storage save error', e);
    }
  }, [agencyProfile]);

  useEffect(() => {
    try {
      localStorage.setItem('agency_message_templates', JSON.stringify(templates));
    } catch (e) {
      console.warn('Storage save error', e);
    }
  }, [templates]);

  // Lead handlers
  const handleAddLeads = (newLeads: Lead[]) => {
    // Merge preventing duplicate phones
    setLeads((prev) => {
      const existingPhones = new Set(prev.map((l) => l.whatsappNumber || l.rawPhone));
      const filteredNew = newLeads.filter(
        (l) => !existingPhones.has(l.whatsappNumber || l.rawPhone)
      );
      return [...filteredNew, ...prev];
    });

    // Auto update task if lead research task exists
    setTasks((prev) =>
      prev.map((t) => {
        if (t.category === 'leads' && !t.completed) {
          const nextCount = (t.completedCount || 0) + newLeads.length;
          return {
            ...t,
            completedCount: nextCount,
            completed: t.leadCountTarget ? nextCount >= t.leadCountTarget : false,
          };
        }
        return t;
      })
    );
  };

  const handleUpdateLead = (updated: Lead) => {
    setLeads((prev) => prev.map((l) => (l.id === updated.id ? updated : l)));
  };

  const handleBatchUpdateLeads = (updatedBatch: Lead[]) => {
    const map = new Map(updatedBatch.map((l) => [l.id, l]));
    setLeads((prev) => prev.map((l) => map.get(l.id) || l));
  };

  const handleDeleteLead = (id: string) => {
    setLeads((prev) => prev.filter((l) => l.id !== id));
  };

  const handleDeleteMultipleLeads = (ids: string[]) => {
    const toDelete = new Set(ids);
    setLeads((prev) => prev.filter((l) => !toDelete.has(l.id)));
  };

  // Bulk Clean: filter out invalid numbers & keep only valid ones
  const handleBulkCleanInvalid = () => {
    const beforeCount = leads.length;
    const cleaned = leads.filter((l) => l.isWhatsappValid);
    const removedCount = beforeCount - cleaned.length;
    setLeads(cleaned);
    alert(`تمت تصفية قاعدة البيانات بنجاح: تم حذف ${removedCount} رقم غير صالح والاحتفاظ بـ ${cleaned.length} رقم واتساب متسق.`);
  };

  const handleQueueForCampaign = (leadIds: string[]) => {
    setCampaignLeadIds(leadIds);
    setActiveTab('campaigns');
  };

  const handleMarkLeadsContacted = (contactedIds: string[]) => {
    const idSet = new Set(contactedIds);
    setLeads((prev) =>
      prev.map((l) =>
        idSet.has(l.id)
          ? { ...l, status: 'contacted', lastContactedAt: new Date().toISOString() }
          : l
      )
    );

    // Update daily outreach task progress
    setTasks((prev) =>
      prev.map((t) => {
        if (t.category === 'outreach' && !t.completed) {
          const nextCount = (t.completedCount || 0) + contactedIds.length;
          return {
            ...t,
            completedCount: nextCount,
            completed: t.leadCountTarget ? nextCount >= t.leadCountTarget : false,
          };
        }
        return t;
      })
    );
  };

  // Task handlers
  const handleToggleTask = (id: string) => {
    setTasks((prev) =>
      prev.map((t) => (t.id === id ? { ...t, completed: !t.completed } : t))
    );
  };

  const handleAddTask = (task: DailyTask) => {
    setTasks((prev) => [task, ...prev]);
  };

  const handleDeleteTask = (id: string) => {
    setTasks((prev) => prev.filter((t) => t.id !== id));
  };

  // Message Template handlers
  const handleSaveTemplate = (updated: MessageTemplate) => {
    setTemplates((prev) => {
      const exists = prev.some((t) => t.id === updated.id);
      if (exists) {
        return prev.map((t) => (t.id === updated.id ? updated : t));
      }
      return [updated, ...prev];
    });
  };

  const handleDeleteTemplate = (id: string) => {
    setTemplates((prev) => prev.filter((t) => t.id !== id));
  };

  const handleResetDefaultTemplates = () => {
    setTemplates(initialMessageTemplates);
  };

  const handleUseTemplateInCampaign = (content: string) => {
    setCampaignInitialMessage(content);
    setActiveTab('campaigns');
  };

  return (
    <div className="min-h-screen bg-stone-50 text-stone-900 flex flex-col font-['Tajawal',sans-serif]">
      {/* Top Header & Navigation */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        leads={leads}
        tasks={tasks}
        agencyProfile={agencyProfile}
        templatesCount={templates.length}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {activeTab === 'search' && (
          <SearchSection
            onAddLeads={handleAddLeads}
            onNavigateToLeads={() => setActiveTab('leads')}
          />
        )}

        {activeTab === 'leads' && (
          <LeadsTable
            leads={leads}
            onUpdateLead={handleUpdateLead}
            onDeleteLead={handleDeleteLead}
            onDeleteMultipleLeads={handleDeleteMultipleLeads}
            onBulkCleanInvalid={handleBulkCleanInvalid}
            onQueueForCampaign={handleQueueForCampaign}
            onOpenPitchModal={(lead) => setPitchLead(lead)}
            onAddManualLead={(lead) => handleAddLeads([lead])}
            agencyProfile={agencyProfile}
          />
        )}

        {activeTab === 'templates' && (
          <TemplatesManager
            templates={templates}
            onSaveTemplate={handleSaveTemplate}
            onDeleteTemplate={handleDeleteTemplate}
            onResetDefaultTemplates={handleResetDefaultTemplates}
            onUseTemplateInCampaign={handleUseTemplateInCampaign}
            agencyProfile={agencyProfile}
            leads={leads}
          />
        )}

        {activeTab === 'campaigns' && (
          <BatchCampaignSender
            leads={leads}
            agencyProfile={agencyProfile}
            preSelectedLeadIds={campaignLeadIds}
            onMarkLeadsContacted={handleMarkLeadsContacted}
            templates={templates}
            initialMessage={campaignInitialMessage}
          />
        )}

        {activeTab === 'sales' && (
          <AutonomousSalesAgent
            leads={leads}
            agencyProfile={agencyProfile}
            onSaveProfile={(updated) => setAgencyProfile(updated)}
            onUpdateLead={handleUpdateLead}
            onBatchUpdateLeads={handleBatchUpdateLeads}
            onNavigateToCampaigns={(initialMsg) => {
              if (initialMsg) {
                setCampaignInitialMessage(initialMsg);
              }
              setActiveTab('campaigns');
            }}
          />
        )}

        {activeTab === 'analytics' && (
          <CampaignAnalytics
            leads={leads}
            agencyProfile={agencyProfile}
            onUpdateLead={handleUpdateLead}
          />
        )}

        {activeTab === 'autoReply' && (
          <AgencyProfileAndAutoReply
            agencyProfile={agencyProfile}
            onSaveProfile={(updated) => setAgencyProfile(updated)}
          />
        )}

        {activeTab === 'tasks' && (
          <DailyTasksView
            tasks={tasks}
            onToggleTask={handleToggleTask}
            onAddTask={handleAddTask}
            onDeleteTask={handleDeleteTask}
            onNavigateTab={(tab) => setActiveTab(tab)}
          />
        )}
      </main>

      {/* Custom AI Proposal Modal */}
      <CustomPitchModal
        lead={pitchLead}
        agencyProfile={agencyProfile}
        isOpen={Boolean(pitchLead)}
        onClose={() => setPitchLead(null)}
        onMarkContacted={(leadId) => handleMarkLeadsContacted([leadId])}
      />

      {/* Simple Footer */}
      <footer className="border-t border-stone-200 bg-white py-4 mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between text-xs text-stone-500 gap-2">
          <div>
            نظام وكيل المهام والتسويق الذكي • مدعوم بتقنيات Gemini والبحث المتصل بمحركات البحث
          </div>
          <div className="flex items-center gap-2">
            <span>الواتساب المعتمد:</span>
            <span className="font-mono font-bold text-stone-800 dir-ltr">
              {agencyProfile.myWhatsapp || '00667737219181'}
            </span>
          </div>
        </div>
      </footer>
    </div>
  );
}
