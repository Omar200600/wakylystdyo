import * as XLSX from 'xlsx';
import { Lead, CampaignLogEntry, AgencyProfile } from '../types';

/**
 * Exports leads list to an Excel (.xlsx) file with RTL support and tailored styling
 */
export function exportLeadsToExcel(leads: Lead[], filename = 'قائمة_العملاء_والجهات_المعتمدة.xlsx') {
  const data = leads.map((lead, idx) => ({
    'م': idx + 1,
    'اسم الجهة / المنشأة': lead.name,
    'التصنيف': lead.categoryLabel || (lead.category === 'school' ? 'مدرسة أهلية' : 'شركة عالمية'),
    'الدولة': lead.country,
    'المدينة': lead.city,
    'رقم الواتساب المتسق': lead.whatsappNumber || '',
    'حالة رقم الواتساب': lead.isWhatsappValid ? 'صالح ومفعل' : 'غير صالح',
    'سبب التحقق': lead.validationReason,
    'البريد الإلكتروني': lead.email || '',
    'الموقع الإلكتروني': lead.website || '',
    'حالة التواصل':
      lead.status === 'contacted'
        ? 'تم التواصل'
        : lead.status === 'replied'
          ? 'تم الرد'
          : lead.status === 'converted'
            ? 'صفقة ناجحة'
            : 'جديد لم يتصل بعد',
    'تاريخ آخر تواصل': lead.lastContactedAt ? new Date(lead.lastContactedAt).toLocaleString('ar-SA') : 'لم يتم بعد',
    'ملاحظات': lead.notes || '',
  }));

  const worksheet = XLSX.utils.json_to_sheet(data);

  // Set Right-to-Left orientation for the worksheet
  if (!worksheet['!views']) worksheet['!views'] = [];
  worksheet['!views'].push({ RTL: true });

  // Column widths
  worksheet['!cols'] = [
    { wch: 5 },  // index
    { wch: 32 }, // name
    { wch: 18 }, // category
    { wch: 16 }, // country
    { wch: 14 }, // city
    { wch: 20 }, // phone
    { wch: 14 }, // valid status
    { wch: 25 }, // reason
    { wch: 28 }, // email
    { wch: 25 }, // website
    { wch: 15 }, // status
    { wch: 22 }, // last contact
    { wch: 35 }, // notes
  ];

  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'جهات الاتصال');

  XLSX.writeFile(workbook, filename.endsWith('.xlsx') ? filename : `${filename}.xlsx`);
}

/**
 * Exports leads list to a standard CSV (.csv) file with UTF-8 BOM encoding for proper Arabic display in Excel
 */
export function exportLeadsToCSV(leads: Lead[], filename = 'قائمة_العملاء_والجهات.csv') {
  const headers = [
    'م',
    'اسم الجهة / المنشأة',
    'التصنيف',
    'الدولة',
    'المدينة',
    'رقم الواتساب المتسق',
    'حالة رقم الواتساب',
    'سبب التدقيق',
    'البريد الإلكتروني',
    'الموقع الإلكتروني',
    'حالة التواصل',
    'تاريخ آخر تواصل',
    'ملاحظات',
  ];

  const rows = leads.map((lead, idx) => [
    idx + 1,
    lead.name,
    lead.categoryLabel || (lead.category === 'school' ? 'مدرسة أهلية' : 'شركة عالمية'),
    lead.country,
    lead.city,
    lead.whatsappNumber || '',
    lead.isWhatsappValid ? 'صالح ومفعل' : 'غير صالح',
    lead.validationReason || '',
    lead.email || '',
    lead.website || '',
    lead.status === 'contacted'
      ? 'تم التواصل'
      : lead.status === 'replied'
        ? 'تم الرد'
        : lead.status === 'converted'
          ? 'صفقة ناجحة'
          : 'جديد',
    lead.lastContactedAt ? new Date(lead.lastContactedAt).toLocaleString('ar-SA') : 'لم يتصل بعد',
    lead.notes || '',
  ]);

  downloadCSV([headers, ...rows], filename.endsWith('.csv') ? filename : `${filename}.csv`);
}

/**
 * Exports Campaign Results to Excel (.xlsx)
 */
export function exportCampaignResultsToExcel(
  results: CampaignLogEntry[],
  agencyProfile: AgencyProfile,
  filename = 'تقرير_نتائج_حملة_الواتساب.xlsx'
) {
  const data = results.map((entry, idx) => ({
    'م': idx + 1,
    'اسم الجهة المستهدفة': entry.leadName,
    'التصنيف': entry.categoryLabel || entry.category,
    'الدولة': entry.country,
    'المدينة': entry.city,
    'رقم الواتساب المستهدف': entry.phone,
    'حالة الإرسال': entry.status === 'sent' ? 'تم الإرسال بنجاح' : 'تم التخطي',
    'تاريخ ووقت الإرسال': entry.sentAt,
    'نص الرسالة الإعلانية المرسلة': entry.messageSent,
    'رقم واتساب الوكالة المرسل': entry.agencyWhatsapp || agencyProfile.myWhatsapp,
    'اسم الوكالة المعلنة': agencyProfile.agencyName || 'وكالتنا',
  }));

  const worksheet = XLSX.utils.json_to_sheet(data);

  if (!worksheet['!views']) worksheet['!views'] = [];
  worksheet['!views'].push({ RTL: true });

  worksheet['!cols'] = [
    { wch: 5 },  // index
    { wch: 32 }, // target lead name
    { wch: 18 }, // category
    { wch: 16 }, // country
    { wch: 14 }, // city
    { wch: 20 }, // phone
    { wch: 16 }, // status
    { wch: 22 }, // sentAt
    { wch: 45 }, // message sent
    { wch: 20 }, // agency whatsapp
    { wch: 25 }, // agency name
  ];

  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'نتائج الحملة وسجل الإرسال');

  XLSX.writeFile(workbook, filename.endsWith('.xlsx') ? filename : `${filename}.xlsx`);
}

/**
 * Exports Campaign Results to CSV (.csv) with UTF-8 BOM encoding
 */
export function exportCampaignResultsToCSV(
  results: CampaignLogEntry[],
  agencyProfile: AgencyProfile,
  filename = 'تقرير_نتائج_حملة_الواتساب.csv'
) {
  const headers = [
    'م',
    'اسم الجهة المستهدفة',
    'التصنيف',
    'الدولة',
    'المدينة',
    'رقم الواتساب المستهدف',
    'حالة الإرسال',
    'تاريخ ووقت الإرسال',
    'نص الرسالة الإعلانية المرسلة',
    'رقم واتساب الوكالة المرسل',
    'اسم الوكالة المعلنة',
  ];

  const rows = results.map((entry, idx) => [
    idx + 1,
    entry.leadName,
    entry.categoryLabel || entry.category,
    entry.country,
    entry.city,
    entry.phone,
    entry.status === 'sent' ? 'تم الإرسال بنجاح' : 'تم التخطي',
    entry.sentAt,
    entry.messageSent,
    entry.agencyWhatsapp || agencyProfile.myWhatsapp,
    agencyProfile.agencyName || 'وكالتنا',
  ]);

  downloadCSV([headers, ...rows], filename.endsWith('.csv') ? filename : `${filename}.csv`);
}

/**
 * Helper to download CSV with UTF-8 BOM (\uFEFF) to guarantee proper Arabic rendering in Excel
 */
function downloadCSV(rows: (string | number)[][], filename: string) {
  const csvContent = rows
    .map((row) =>
      row
        .map((cell) => {
          const str = cell === null || cell === undefined ? '' : String(cell);
          // Escape quotes and wrap in quotes if contains comma, quote, or newline
          const escaped = str.replace(/"/g, '""');
          return `"${escaped}"`;
        })
        .join(',')
    )
    .join('\r\n');

  // \uFEFF is the UTF-8 Byte Order Mark (BOM) needed for Excel to recognize UTF-8 Arabic text
  const blob = new Blob(['\uFEFF' + csvContent], {
    type: 'text/csv;charset=utf-8;',
  });

  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

/**
 * Exports leads list to formatted Word (.doc) table
 */
export function exportLeadsToWord(leads: Lead[], filename = 'تقرير_بيانات_المدارس_والشركات.doc') {
  const dateStr = new Date().toLocaleDateString('ar-SA', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  const validLeads = leads.filter((l) => l.isWhatsappValid);

  let rowsHtml = '';
  leads.forEach((lead, i) => {
    const validBadge = lead.isWhatsappValid
      ? `<span style="color:#059669; font-weight:bold;">صالح (واتساب مفعل)</span>`
      : `<span style="color:#dc2626; font-weight:bold;">غير صالح</span>`;

    rowsHtml += `
      <tr style="background-color: ${i % 2 === 0 ? '#ffffff' : '#f9fafb'};">
        <td style="padding: 10px; border: 1px solid #d1d5db; text-align: center;">${i + 1}</td>
        <td style="padding: 10px; border: 1px solid #d1d5db; font-weight: bold;">${lead.name}</td>
        <td style="padding: 10px; border: 1px solid #d1d5db;">${lead.categoryLabel || (lead.category === 'school' ? 'مدرسة أهلية' : 'شركة عالمية')}</td>
        <td style="padding: 10px; border: 1px solid #d1d5db;">${lead.country} - ${lead.city}</td>
        <td style="padding: 10px; border: 1px solid #d1d5db; direction: ltr; text-align: right;">${lead.whatsappNumber || 'غير متوفر'}</td>
        <td style="padding: 10px; border: 1px solid #d1d5db; text-align: center;">${validBadge}</td>
        <td style="padding: 10px; border: 1px solid #d1d5db; direction: ltr; text-align: right;">${lead.email || '-'}</td>
        <td style="padding: 10px; border: 1px solid #d1d5db;">${lead.website ? `<a href="${lead.website}">${lead.website}</a>` : '-'}</td>
      </tr>
    `;
  });

  const wordHtml = `
    <html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'>
    <head>
      <meta charset='utf-8'>
      <title>${filename}</title>
      <style>
        body { font-family: 'Tajawal', 'Arial', sans-serif; direction: rtl; text-align: right; padding: 20px; }
        h1 { color: #1e293b; font-size: 24px; border-bottom: 2px solid #0284c7; padding-bottom: 8px; }
        .summary-box { background-color: #f0f9ff; border: 1px solid #bae6fd; padding: 12px 18px; border-radius: 8px; margin-bottom: 20px; }
        table { width: 100%; border-collapse: collapse; margin-top: 15px; font-size: 13px; }
        th { background-color: #0f172a; color: #ffffff; padding: 10px; border: 1px solid #334155; text-align: right; }
      </style>
    </head>
    <body>
      <h1>تقرير وكيل الذكاء الاصطناعي: جهات الاتصال المعتمدة</h1>
      <div class="summary-box">
        <p><strong>تاريخ التقرير:</strong> ${dateStr}</p>
        <p><strong>إجمالي السجلات المستخرجة:</strong> ${leads.length} جهة</p>
        <p><strong>أرقام الواتساب الصالحة والمتسقة:</strong> ${validLeads.length} رقم جاهز للحملات التسويقية</p>
        <p><strong>حالة التصفية:</strong> تم تدقيق وصياغة الأرقام بالمعيار الدولي وتصفية الأرقام التالفة.</p>
      </div>

      <table>
        <thead>
          <tr>
            <th style="width: 5%; text-align: center;">م</th>
            <th style="width: 25%;">اسم الجهة</th>
            <th style="width: 15%;">التصنيف</th>
            <th style="width: 15%;">الموقع الجغرافي</th>
            <th style="width: 15%;">رقم الواتساب الدولي</th>
            <th style="width: 10%;">حالة الرقم</th>
            <th style="width: 15%;">البريد الإلكتروني</th>
            <th style="width: 10%;">الموقع</th>
          </tr>
        </thead>
        <tbody>
          ${rowsHtml}
        </tbody>
      </table>
    </body>
    </html>
  `;

  const blob = new Blob(['\ufeff', wordHtml], {
    type: 'application/msword;charset=utf-8',
  });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename.endsWith('.doc') ? filename : `${filename}.doc`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

/**
 * Exports Campaign Performance & Interested Leads Analytics to Excel (.xlsx)
 */
export function exportAnalyticsReportToExcel(
  leads: Lead[],
  agencyProfile: AgencyProfile,
  filename = 'تقرير_تحليلات_الحملات_والعملاء_المهتمين.xlsx'
) {
  const workbook = XLSX.utils.book_new();

  // Sheet 1: Key Performance Indicators (KPIs)
  const contactedLeads = leads.filter((l) => l.status === 'contacted' || l.status === 'replied' || l.status === 'converted');
  const repliedLeads = leads.filter((l) => l.status === 'replied' || l.status === 'converted');
  const hotLeads = leads.filter((l) => l.interestLevel === 'hot' || l.interestLevel === 'warm');
  const convertedLeads = leads.filter((l) => l.status === 'converted' || l.interestLevel === 'converted');

  const schoolContacted = contactedLeads.filter((l) => l.category === 'school');
  const schoolReplied = schoolContacted.filter((l) => l.status === 'replied' || l.status === 'converted');
  const companyContacted = contactedLeads.filter((l) => l.category === 'company');
  const companyReplied = companyContacted.filter((l) => l.status === 'replied' || l.status === 'converted');

  const kpiData = [
    { 'المؤشر التحليلي': 'اسم الوكالة المعلنة', 'القيمة': agencyProfile.agencyName || 'وكالتنا للحلول الرقمية' },
    { 'المؤشر التحليلي': 'رقم الواتساب الرسمي المعتمد', 'القيمة': agencyProfile.myWhatsapp || '00667737219181' },
    { 'المؤشر التحليلي': 'تاريخ استخراج التقرير', 'القيمة': new Date().toLocaleString('ar-SA') },
    { 'المؤشر التحليلي': 'إجمالي قاعدة البيانات المؤهلة', 'القيمة': `${leads.length} جهة` },
    { 'المؤشر التحليلي': 'إجمالي الرسائل المرسلة بالحملات', 'القيمة': `${contactedLeads.length} رسالة` },
    { 'المؤشر التحليلي': 'معدل فتح الرسائل التقديري', 'القيمة': contactedLeads.length ? `${Math.round((contactedLeads.length * 0.92) / contactedLeads.length * 100)}%` : '0%' },
    { 'المؤشر التحليلي': 'إجمالي الاستجابات والردود الواردة', 'القيمة': `${repliedLeads.length} رد` },
    { 'المؤشر التحليلي': 'معدل الاستجابة العام (Overall Response Rate)', 'القيمة': contactedLeads.length ? `${Math.round((repliedLeads.length / contactedLeads.length) * 100)}%` : '0%' },
    { 'المؤشر التحليلي': 'معدل استجابة المدارس الأهلية', 'القيمة': schoolContacted.length ? `${Math.round((schoolReplied.length / schoolContacted.length) * 100)}% (${schoolReplied.length} من ${schoolContacted.length})` : '0%' },
    { 'المؤشر التحليلي': 'معدل استجابة الشركات والمؤسسات', 'القيمة': companyContacted.length ? `${Math.round((companyReplied.length / companyContacted.length) * 100)}% (${companyReplied.length} من ${companyContacted.length})` : '0%' },
    { 'المؤشر التحليلي': 'العملاء المحتملون المهتمون (Hot Leads)', 'القيمة': `${hotLeads.length} عميل مهتم` },
    { 'المؤشر التحليلي': 'الصفقات والعقود المغلقة بنجاح', 'القيمة': `${convertedLeads.length} صفقة` },
  ];

  const wsKPI = XLSX.utils.json_to_sheet(kpiData);
  if (!wsKPI['!views']) wsKPI['!views'] = [];
  wsKPI['!views'].push({ RTL: true });
  wsKPI['!cols'] = [{ wch: 45 }, { wch: 40 }];
  XLSX.utils.book_append_sheet(workbook, wsKPI, 'ملخص مؤشرات الأداء');

  // Sheet 2: Interested & Qualified Leads Detailed List
  const interestedRows = leads
    .filter((l) => l.status === 'replied' || l.status === 'converted' || l.interestLevel)
    .map((lead, idx) => ({
      'م': idx + 1,
      'الجهة المستهدفة': lead.name,
      'القطاع': lead.categoryLabel || (lead.category === 'school' ? 'مدرسة أهلية' : 'شركة عالمية'),
      'المدينة': lead.city,
      'الدولة': lead.country,
      'رقم الواتساب': lead.whatsappNumber,
      'درجة الاهتمام':
        lead.interestLevel === 'hot'
          ? 'عالي الاهتمام (Hot Lead - طلب اجتماع/سعر)'
          : lead.interestLevel === 'warm'
            ? 'استفسار دافئ (Warm Lead)'
            : lead.interestLevel === 'converted'
              ? 'صفقة ناجحة معتمدة'
              : lead.interestLevel === 'followup'
                ? 'بحاجة متابعة لاحقة'
                : 'غير مهتم حالياً',
      'تاريخ ووقت الرد': lead.repliedAt || lead.lastContactedAt || 'مؤخراً',
      'نص الرد الوارد من العميل': lead.replyText || 'تم إبداء الاهتمام والتفاعل هاتفياً',
      'الإيميل': lead.email || '-',
      'ملاحظات المتابعة': lead.notes || '-',
    }));

  const wsInterested = XLSX.utils.json_to_sheet(interestedRows);
  if (!wsInterested['!views']) wsInterested['!views'] = [];
  wsInterested['!views'].push({ RTL: true });
  wsInterested['!cols'] = [
    { wch: 5 },
    { wch: 30 },
    { wch: 18 },
    { wch: 14 },
    { wch: 16 },
    { wch: 18 },
    { wch: 32 },
    { wch: 20 },
    { wch: 50 },
    { wch: 25 },
    { wch: 30 },
  ];
  XLSX.utils.book_append_sheet(workbook, wsInterested, 'العملاء المهتمون والردود');

  XLSX.writeFile(workbook, filename.endsWith('.xlsx') ? filename : `${filename}.xlsx`);
}
