// Helper utilities for Arabic/English phone normalization, validation, and WhatsApp links

export function cleanAndValidatePhone(rawPhone: string, countryHint = ''): {
  normalized: string;
  isValid: boolean;
  reason: string;
  waLink: string;
} {
  if (!rawPhone || !rawPhone.trim()) {
    return {
      normalized: '',
      isValid: false,
      reason: 'لا يوجد رقم هاتف مسجل',
      waLink: '',
    };
  }

  // Convert Arabic-Indic numerals (٠-٩) to Western (0-9)
  const arabicDigits = '٠١٢٣٤٥٦٧٨٩';
  let cleaned = rawPhone.replace(/[٠-٩]/g, (d) => String(arabicDigits.indexOf(d)));

  // Preserve leading +
  const trimmed = cleaned.trim();
  const startsWithPlus = trimmed.startsWith('+');
  const startsWithDoubleZero = trimmed.startsWith('00');

  // Strip non-digits
  cleaned = cleaned.replace(/[^0-9]/g, '');

  if (startsWithDoubleZero) {
    cleaned = cleaned.substring(2);
  }

  // Country-specific smart prefixing
  const lowerHint = countryHint.toLowerCase();
  const isSaudi = countryHint.includes('سعود') || lowerHint.includes('saudi') || lowerHint.includes('ksa');
  const isUAE = countryHint.includes('إمارات') || lowerHint.includes('uae') || lowerHint.includes('emirates');
  const isEgypt = countryHint.includes('مصر') || lowerHint.includes('egypt');
  const isKuwait = countryHint.includes('كويت') || lowerHint.includes('kuwait');
  const isQatar = countryHint.includes('قطر') || lowerHint.includes('qatar');
  const isOman = countryHint.includes('عمان') || lowerHint.includes('عُمان') || lowerHint.includes('oman');
  const isJordan = countryHint.includes('أردن') || countryHint.includes('اردن') || lowerHint.includes('jordan');

  if (!cleaned.startsWith('966') && isSaudi) {
    if (cleaned.startsWith('05')) {
      cleaned = '966' + cleaned.substring(1);
    } else if (cleaned.startsWith('5') && cleaned.length === 9) {
      cleaned = '966' + cleaned;
    }
  } else if (!cleaned.startsWith('971') && isUAE) {
    if (cleaned.startsWith('05')) {
      cleaned = '971' + cleaned.substring(1);
    } else if (cleaned.startsWith('5') && cleaned.length === 9) {
      cleaned = '971' + cleaned;
    }
  } else if (!cleaned.startsWith('20') && isEgypt) {
    if (cleaned.startsWith('01')) {
      cleaned = '20' + cleaned.substring(1);
    }
  } else if (!cleaned.startsWith('965') && isKuwait) {
    if (cleaned.length === 8 && ['5', '6', '9'].includes(cleaned[0])) {
      cleaned = '965' + cleaned;
    }
  } else if (!cleaned.startsWith('974') && isQatar) {
    if (cleaned.length === 8 && ['3', '5', '6', '7'].includes(cleaned[0])) {
      cleaned = '974' + cleaned;
    }
  } else if (!cleaned.startsWith('968') && isOman) {
    if (cleaned.length === 8 && ['7', '9'].includes(cleaned[0])) {
      cleaned = '968' + cleaned;
    }
  } else if (!cleaned.startsWith('962') && isJordan) {
    if (cleaned.startsWith('07')) {
      cleaned = '962' + cleaned.substring(1);
    }
  }

  // Length and format validation
  const digitCount = cleaned.length;
  if (digitCount < 8) {
    return {
      normalized: '+' + cleaned,
      isValid: false,
      reason: 'رقم غير صالح: ناقص أرقام (أقل من 8)',
      waLink: '',
    };
  }

  if (digitCount > 15) {
    return {
      normalized: '+' + cleaned,
      isValid: false,
      reason: 'رقم غير صالح: يتجاوز المعيار الدولي (أكثر من 15 رقم)',
      waLink: '',
    };
  }

  const normalized = '+' + cleaned;
  const waLink = `https://wa.me/${cleaned}`;

  return {
    normalized,
    isValid: true,
    reason: 'رقم دولي قياسي متسق وصالح للواتساب',
    waLink,
  };
}

export function generateWhatsAppChatUrl(phone: string, message: string): string {
  const digits = phone.replace(/[^0-9]/g, '');
  const encodedMsg = encodeURIComponent(message.trim());
  return `https://wa.me/${digits}?text=${encodedMsg}`;
}
