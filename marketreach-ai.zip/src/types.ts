export interface Lead {
  id: string;
  name: string;
  category: 'school' | 'company' | 'other';
  categoryLabel: string;
  country: string;
  city: string;
  rawPhone: string;
  whatsappNumber: string;
  isWhatsappValid: boolean;
  validationReason: string;
  email: string;
  isEmailValid: boolean;
  website: string;
  address?: string;
  notes?: string;
  status: 'new' | 'in_queue' | 'contacted' | 'replied' | 'converted' | 'skipped';
  interestLevel?: 'hot' | 'warm' | 'followup' | 'not_interested' | 'converted';
  replyText?: string;
  repliedAt?: string;
  estimatedOpened?: boolean;
  lastContactedAt?: string;
  customPitch?: string;
  sourceUrl?: string;
  // Deals, Pricing & Sales Negotiation
  dealStage?: 'ad_sent' | 'form_clicked' | 'pricing_offered' | 'negotiating' | 'closed_sale' | 'closed_lease' | 'pending_form' | 'declined';
  dealType?: 'sale' | 'lease' | 'both' | 'pending';
  dealAmount?: number;
  dealTerms?: string;
  dealNotes?: string;
  formSubmitted?: boolean;
}

export interface PricingConfig {
  salePrice: number;
  saleTitle: string;
  leasePriceMonthly: number;
  leasePriceAnnual: number;
  leaseTitle: string;
  currency: string;
  discountMargin?: number;
}

export interface MessageTemplate {
  id: string;
  title: string;
  category: 'schools' | 'companies' | 'offers' | 'followup' | 'direct_meeting' | 'custom';
  categoryLabel: string;
  content: string;
  tags: string[];
  isDefault?: boolean;
  createdAt: string;
  updatedAt?: string;
  usageCount?: number;
}

export interface AgencyProfile {
  agencyName: string;
  myWhatsapp: string;
  myEmail: string;
  industry: string;
  businessDetails: string;
  portfolioSummary: string;
  keyOfferings: string;
  customAdCopy: string;
  autoReplyMode: 'auto' | 'review_first';
  agencyAdAnnouncement?: string;
  agencyFormUrl?: string;
  pricingConfig?: PricingConfig;
}

export interface DailyTask {
  id: string;
  title: string;
  description: string;
  category: 'leads' | 'outreach' | 'followup' | 'replies' | 'general';
  priority: 'high' | 'medium' | 'low';
  completed: boolean;
  dueDate: string;
  leadCountTarget?: number;
  completedCount?: number;
  createdAt: string;
}

export interface BatchCampaign {
  id: string;
  name: string;
  leadIds: string[];
  message: string;
  status: 'idle' | 'running' | 'paused' | 'completed';
  batchSize: number;
  delaySeconds: number;
  currentIndex: number;
  successCount: number;
  failedCount: number;
  channel: 'whatsapp' | 'email';
}

export interface ChatInteraction {
  id: string;
  leadName: string;
  leadPhone: string;
  incomingMessage: string;
  aiSuggestedReply: string;
  finalReplySent: string;
  status: 'sent' | 'needs_review' | 'replied_manually';
  timestamp: string;
}

export interface CampaignLogEntry {
  id: string;
  leadId: string;
  leadName: string;
  category: string;
  categoryLabel?: string;
  country: string;
  city: string;
  phone: string;
  messageSent: string;
  status: 'sent' | 'skipped';
  sentAt: string;
  agencyWhatsapp: string;
}

export interface SearchQueryPayload {
  category: 'schools' | 'companies' | 'all';
  country: string;
  city?: string;
  keywords: string;
  strictWhatsappOnly?: boolean;
}
