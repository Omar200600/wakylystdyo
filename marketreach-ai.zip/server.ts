import express from 'express';
import path from 'path';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';
import { createServer as createViteServer } from 'vite';

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json({ limit: '10mb' }));

// Lazy GoogleGenAI initialization
let aiClient: GoogleGenAI | null = null;
function getAI(): GoogleGenAI {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error('GEMINI_API_KEY is not configured in the environment');
    }
    aiClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return aiClient;
}

// Arabic-to-English numeral conversion & phone cleaner
function cleanPhoneNumber(raw: string, countryHint = ''): {
  cleaned: string;
  isValid: boolean;
  reason: string;
} {
  if (!raw) return { cleaned: '', isValid: false, reason: 'لا يوجد رقم هاتف' };

  // Convert Arabic-Indic numerals to Western digits
  const arabicDigits = '٠١٢٣٤٥٦٧٨٩';
  let cleaned = raw.replace(/[٠-٩]/g, (d) => String(arabicDigits.indexOf(d)));

  // Remove non-numeric characters except leading +
  const hasPlus = cleaned.trim().startsWith('+');
  cleaned = cleaned.replace(/[^0-9]/g, '');

  if (cleaned.startsWith('00')) {
    cleaned = '+' + cleaned.substring(2);
  } else if (hasPlus) {
    cleaned = '+' + cleaned;
  } else if (countryHint.includes('سعود') || countryHint.toLowerCase().includes('saudi')) {
    if (cleaned.startsWith('05')) {
      cleaned = '+966' + cleaned.substring(1);
    } else if (cleaned.startsWith('5') && cleaned.length === 9) {
      cleaned = '+966' + cleaned;
    }
  } else if (countryHint.includes('إمارات') || countryHint.toLowerCase().includes('uae')) {
    if (cleaned.startsWith('05')) {
      cleaned = '+971' + cleaned.substring(1);
    }
  } else if (countryHint.includes('مصر') || countryHint.toLowerCase().includes('egypt')) {
    if (cleaned.startsWith('01')) {
      cleaned = '+20' + cleaned.substring(1);
    }
  } else if (countryHint.includes('كويت') || countryHint.toLowerCase().includes('kuwait')) {
    if (cleaned.length === 8 && ['5', '6', '9'].includes(cleaned[0])) {
      cleaned = '+965' + cleaned;
    }
  }

  // Digits count check
  const digitsOnly = cleaned.replace(/\D/g, '');
  if (digitsOnly.length < 8) {
    return { cleaned, isValid: false, reason: 'رقم غير مكتمل (أقل من 8 أرقام)' };
  }
  if (digitsOnly.length > 15) {
    return { cleaned, isValid: false, reason: 'رقم طويل جداً أو يحتوي على تشويش' };
  }

  // Ensure it has international prefix (+)
  if (!cleaned.startsWith('+')) {
    cleaned = '+' + cleaned;
  }

  return {
    cleaned,
    isValid: true,
    reason: 'رقم هاتف دولي متسق وصالح للواتساب',
  };
}

// Health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Search leads with Google Search Grounding
app.post('/api/leads/search', async (req, res) => {
  try {
    const { category, country, city, keywords, count = 8 } = req.body;

    const targetType =
      category === 'schools'
        ? 'مدارس أهلية وخاصة ودولية'
        : category === 'companies'
          ? 'شركات ومؤسسات ومكاتب كبرى وعالمية'
          : 'مدارس أهلية وشركات عالمية';

    const locationQuery = [city, country].filter(Boolean).join(' - ');
    const userKeywords = keywords || 'مدارس أهلية ممتازة وتواصل واتساب أو شركات استثمارية';

    const systemPrompt = `أنت وكيل ذكاء اصطناعي متخصص في أبحاث السوق والتنقيب عن جهات الاتصال (B2B Lead Generation Agent).
مهمتك البحث في محركات البحث عن: ${targetType} في (${locationQuery}) المتعلقة بالكلمات المفتاحية: "${userKeywords}".

يجب استخراج معلومات حقيقية ودقيقة قدر الإمكان تشمل:
- الاسم الرسمي للمدرسة أو الشركة
- التصنيف (مدرسة أهلية / شركة دولية / مؤسسة تجارية)
- الدولة والمدينة
- رقم الهاتف ورقم الواتساب المخصص للتواصل
- البريد الإلكتروني الرسمي
- رابط الموقع الإلكتروني أو حساب لينكدإن / إنستغرام
- نبذة مختصرة عن نشاطها

هام جداً:
أعد النتيجة حصراً بصيغة JSON صالح ومباشر بدون نصوص تقديمية، على شكل مصفوفة كائنات وفق التنسيق التالي:
[
  {
    "name": "اسم المدرسة أو الشركة",
    "category": "school" | "company",
    "categoryLabel": "مدرسة أهلية / شركة استثمارية",
    "country": "${country || 'المملكة العربية السعودية'}",
    "city": "${city || 'الرياض'}",
    "rawPhone": "رقم الهاتف الأصلي مع مفتاح الدولة إن وجد",
    "email": "info@example.com",
    "website": "https://example.com",
    "address": "العنوان التقريبي أو الحي",
    "notes": "ملاحظات عن النشاط أو الخدمات"
  }
]`;

    const ai = getAI();
    const result = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: `ابحث عن أفضل ${count} جهات (${targetType}) في ${locationQuery} مع أرقام واتساب وإيميلات حقيقية ومفعلة للتواصل. الكلمات المفتاحية: ${userKeywords}`,
      config: {
        systemInstruction: systemPrompt,
        temperature: 0.2,
        tools: [{ googleSearch: {} }],
      },
    });

    const rawText = result.text || '';

    // Extract JSON block
    let parsedLeads: any[] = [];
    try {
      const jsonMatch = rawText.match(/\[[\s\S]*\]/);
      if (jsonMatch) {
        parsedLeads = JSON.parse(jsonMatch[0]);
      } else {
        parsedLeads = JSON.parse(rawText);
      }
    } catch (e) {
      console.warn('Could not parse direct JSON from search result, falling back to structured extraction');
      // If direct JSON extraction fails, request a formatting pass
      const formatPass = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: `حول النص التالي المستخرج من البحث إلى مصفوفة JSON صالحة تحتوي على:
name, category ('school' or 'company'), categoryLabel, country, city, rawPhone, email, website, address, notes.
النص المستخرج:
${rawText.slice(0, 4000)}`,
        config: {
          responseMimeType: 'application/json',
        },
      });
      try {
        parsedLeads = JSON.parse(formatPass.text || '[]');
      } catch (err) {
        parsedLeads = [];
      }
    }

    // Process and validate phone numbers and leads
    const processedLeads = parsedLeads.map((item: any, idx: number) => {
      const phoneValidation = cleanPhoneNumber(item.rawPhone || '', country || item.country || '');
      const emailValid = Boolean(
        item.email &&
        /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(item.email.trim()) &&
        !item.email.includes('example.com')
      );

      return {
        id: `lead_${Date.now()}_${idx}_${Math.random().toString(36).substring(2, 7)}`,
        name: item.name || `جهة تواصل ${idx + 1}`,
        category: item.category === 'school' ? 'school' : 'company',
        categoryLabel: item.categoryLabel || (item.category === 'school' ? 'مدرسة أهلية' : 'شركة عالمية'),
        country: item.country || country || 'المملكة العربية السعودية',
        city: item.city || city || 'الرياض',
        rawPhone: item.rawPhone || '',
        whatsappNumber: phoneValidation.cleaned,
        isWhatsappValid: phoneValidation.isValid,
        validationReason: phoneValidation.reason,
        email: item.email || '',
        isEmailValid: emailValid,
        website: item.website || '',
        address: item.address || '',
        notes: item.notes || '',
        status: 'new',
      };
    });

    res.json({
      success: true,
      count: processedLeads.length,
      leads: processedLeads,
    });
  } catch (error: any) {
    console.error('Lead search error:', error);
    res.status(500).json({
      success: false,
      error: error.message || 'حدث خطأ أثناء البحث عن المدارس والشركات',
    });
  }
});

// Generate Customized Outreach Pitch / Ad
app.post('/api/leads/pitch', async (req, res) => {
  try {
    const { lead, agencyProfile, tone = 'professional' } = req.body;

    const ai = getAI();
    const prompt = `أنت كاتب محتوى تسويقي ونسخ إعلانية محترف (Copywriter & B2B Sales Expert).
اكتب رسالة عرض أعمال وتسويق مخصصة يتم إرسالها عبر الواتساب إلى الجهة التالية:
الاسم: ${lead.name}
النوع: ${lead.categoryLabel || lead.category}
المدينة والدولة: ${lead.city}, ${lead.country}

بيانات وكالتنا وصاحب العمل:
- اسم الوكالة: ${agencyProfile.agencyName || 'وكالتنا للحلول الرقمية والتسويق'}
- رقم الواتساب الرسمي للتواصل: ${agencyProfile.myWhatsapp || '00667737219181'}
- الإيميل: ${agencyProfile.myEmail || ''}
- مجال التجارة والعمل: ${agencyProfile.businessDetails || agencyProfile.industry || 'تقديم خدمات التطوير الرقمي، التسويق الذكي، البرمجيات وإدارة الحملات'}
- عرض الأعمال والخدمات الرئيسية: ${agencyProfile.portfolioSummary || agencyProfile.keyOfferings || ''}
- نص إعلاني مقترح من صاحب الوكالة: ${agencyProfile.customAdCopy || ''}

المطلوب:
صياغة رسالة واتساب أنيقة ومؤثرة:
1. تحية راقية مع ذكر اسم المدرسة أو الشركة خصيصاً لتكون الرسالة شخصية وغير مزعجة.
2. توضيح القيمة المضافة وما نستطيع تقديمه لتطوير أعمالهم أو تعزيز تسجيل الطلاب/مبيعاتهم.
3. عرض أعمالنا وخبراتنا باختصار جذاب.
4. دعوة واضحة لاتخاذ إجراء (Call to Action) للرد ومحادثتنا مباشرة على الواتساب: ${agencyProfile.myWhatsapp || '00667737219181'}.
5. استخدام رموز تعبيرية مهنية منسقة وفواصل بصرية نظيفة.
6. لا تجعل الرسالة طويلة ومملة، بل مركزة وقوية التحويل.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        temperature: 0.7,
      },
    });

    res.json({
      success: true,
      pitch: response.text || '',
    });
  } catch (error: any) {
    console.error('Pitch generation error:', error);
    res.status(500).json({
      success: false,
      error: error.message || 'فشل توليد الرسالة الإعلانية',
    });
  }
});

// AI Auto-Responder: Represents the user on WhatsApp 00667737219181
app.post('/api/agency/ai-reply', async (req, res) => {
  try {
    const {
      incomingMessage,
      senderName = 'العميل',
      senderPhone = '',
      agencyProfile,
      conversationHistory = [],
    } = req.body;

    const myWhatsapp = agencyProfile?.myWhatsapp || '00667737219181';
    const businessDetails =
      agencyProfile?.businessDetails ||
      'وكالة متخصصة في الخدمات الرقمية والتسويقية وتطوير الأعمال وتقديم حلول تقنية مخصصة للمدارس والشركات العالمية والمحلية.';

    const systemInstruction = `أنت الوكيل الذكي والممثل الرسمي لخدمة العملاء والمبيعات لوكالة (${agencyProfile?.agencyName || 'وكالتنا'}).
أنت ترد نيابة عن صاحب الوكالة عبر رقمه المعتمد على الواتساب: ${myWhatsapp}.

معلومات نشاط صاحب العمل وتجارته:
${businessDetails}
الخدمات المعروضة وسابقة الأعمال:
${agencyProfile?.portfolioSummary || ''}
${agencyProfile?.keyOfferings || ''}

تعليمات الرد الصارمة:
1. الرد بأسلوب لبق، محترف، وودود باللغة العربية الفصحى أو لهجة مهنية بيضاء تناسب عملاء الخليج والعالم العربي.
2. الإجابة بدقة على استفسار العميل استناداً لمعلومات العمل المذكورة أعلاه. إذا سأل عن السعر أو التفاصيل الدقيقة التي تحتاج دراسة مشروع، اطلب منه برفق توضيح متطلباته لعرض أفضل حل، أو اعرض تحديد مكالمة سريعة عبر الواتساب.
3. التوقيع بلباقة في نهاية الرسالة بممثل الوكالة ورقم الواتساب الرسمي: ${myWhatsapp}.
4. حافظ على نبرة واثقة، مرحبة، وسريعة البديهة.`;

    const contents = [
      ...conversationHistory.map((m: any) => ({
        role: m.sender === 'me' ? 'model' : 'user',
        parts: [{ text: m.text }],
      })),
      {
        role: 'user',
        parts: [
          {
            text: `رسالة واردة جديدة من العميل (${senderName}${senderPhone ? ` - ${senderPhone}` : ''}):
"${incomingMessage}"

قم بالرد عليه باحترافية نيابة عن صاحب الوكالة.`,
          },
        ],
      },
    ];

    const ai = getAI();
    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: contents as any,
      config: {
        systemInstruction,
        temperature: 0.5,
      },
    });

    res.json({
      success: true,
      reply: response.text || '',
    });
  } catch (error: any) {
    console.error('Auto reply generation error:', error);
    res.status(500).json({
      success: false,
      error: error.message || 'فشل توليد الرد الذكي',
    });
  }
});

// AI Template Refinement & Optimization
app.post('/api/templates/refine', async (req, res) => {
  try {
    const {
      currentContent,
      category,
      tone = 'persuasive',
      agencyProfile,
      instruction = 'تحسين النبرة التسويقية ورفع معدل التحويل',
    } = req.body;

    const myWhatsapp = agencyProfile?.myWhatsapp || '00667737219181';
    const agencyName = agencyProfile?.agencyName || 'وكالتنا للحلول الرقمية';

    const prompt = `أنت خبير صياغة رسائل واتساب تسويقية وحملات B2B (Direct WhatsApp Copywriting Specialist).
المهمة: تحسين وتطوير قالب رسالة إعلانية موجهة لقطاع: (${category === 'schools' ? 'المدارس الأهلية والدولية' : category === 'companies' ? 'الشركات والمؤسسات' : 'العملاء المستهدفين'}).
النبرة المطلوبة: ${tone} (إقناعية، مختصرة، واضحة وقوية التحويل).
تعليمات المستخدم: ${instruction}

بيانات الوكالة:
- اسم الوكالة: ${agencyName}
- رقم الواتساب: ${myWhatsapp}

المتغيرات المتاحة التي يجب الحفاظ عليها أو إدراجها:
{اسم_الجهة}، {المدينة}، {النوع}، {رقم_الواتس}، {اسم_الوكالة}، {البريد_الإلكتروني}.

النص الحالي للقالب:
"""
${currentContent || ''}
"""

أعد صياغة الرسالة لتكون جذابة جداً على الواتساب، تبدأ بتحية محترمة، تعرض فائدة ملموسة مباشرة، وتختم بدعوة واضحة لاتخاذ إجراء (Call to Action) للرد أو محادثتنا على الواتساب.
أعد فقط نص الرسالة النهائي دون مقدمات أو شروحات.`;

    const ai = getAI();
    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        temperature: 0.6,
      },
    });

    res.json({
      success: true,
      refinedContent: response.text?.trim() || '',
    });
  } catch (error: any) {
    console.error('Template refinement error:', error);
    res.status(500).json({
      success: false,
      error: error.message || 'فشل تحسين القالب بالذكاء الاصطناعي',
    });
  }
});

// Autonomous B2B Sales, Pricing & Negotiation Agent (Sale vs. Lease Closing)
app.post('/api/agency/negotiate-sale', async (req, res) => {
  try {
    const {
      lead,
      incomingMessage,
      conversationHistory = [],
      agencyProfile,
      pricingConfig,
    } = req.body;

    const myWhatsapp = agencyProfile?.myWhatsapp || '00667737219181';
    const agencyName = agencyProfile?.agencyName || 'وكالتنا للحلول والبرمجيات';
    const formUrl = agencyProfile?.agencyFormUrl || 'https://myagency.com/join';

    const salePrice = pricingConfig?.salePrice || 15000;
    const saleTitle = pricingConfig?.saleTitle || 'شراء رخصة ملكية كاملة للنظام وحلول الواتساب مع التدريب والدعم الفني';
    const leasePriceMonthly = pricingConfig?.leasePriceMonthly || 1200;
    const leasePriceAnnual = pricingConfig?.leasePriceAnnual || 10800;
    const leaseTitle = pricingConfig?.leaseTitle || 'استئجار واشتراك دوري (شهري / سنوي) شامل الاستضافة والصيانة والتحديثات';
    const currency = pricingConfig?.currency || 'ريال';

    const systemPrompt = `أنت مدير المبيعات وكبير مفاوضي العقود الرقمية (Chief B2B Sales & Negotiation Officer) لوكالة "${agencyName}".
أنت تتواصل وتتفاوض مباشرة نيابة عن صاحب الوكالة عبر رقم الواتساب الرسمي المعتمد: ${myWhatsapp}.

بيانات العميل المستهدف:
- اسم الجهة: ${lead?.name || 'العميل'}
- نوع القطاع: ${lead?.categoryLabel || (lead?.category === 'school' ? 'مدرسة أهلية' : 'شركة عالمية')}
- المدينة والدولة: ${lead?.city || ''}, ${lead?.country || ''}
- ملاحظات النشاط: ${lead?.notes || ''}

خيارات وباقات الأسعار المعتمدة لديك للتفاوض:
1. [خيار البيع الكامل - Sale/Buyout]:
   - السعر الأساسي: ${salePrice.toLocaleString()} ${currency}
   - الوصف: ${saleTitle}
   - ميزته: امتلاك رخصة دائمة بدون رسوم شهرية متكررة، تدريب الفريق الإداري، ودعم فني متواصل لسنة كاملة.

2. [خيار الاستئجار والاشتراك الدوري - Rental/Lease SaaS]:
   - السعر الشهري: ${leasePriceMonthly.toLocaleString()} ${currency} / شهرياً
   - السعر السنوي الموفر: ${leasePriceAnnual.toLocaleString()} ${currency} / سنوياً (شامل خصم شهرين مجاناً)
   - الوصف: ${leaseTitle}
   - ميزته: تكلفة دخول منخفضة جداً وميسرة، استضافة سحابية مدارة بالكامل، وتحديثات دورية مجانية وتوفير مالي فوري.

3. رابط نموذج الانضمام الرسمي لتعبئة المتطلبات وتفعيل العقد:
   ${formUrl}

مهامك وتكتيكات التفاوض:
- الرد بدبلوماسية واحترافية وبشكل مخصص للعميل.
- إذا سأل العميل عن الأسعار أو التكلفة، اطرح الخيارين بوضوح وأناقة: خيار "البيع والشراء الدائم" وخيار "الاستئجار والاشتراك الدوري الميسر"، ووضح متى يكون الاستئجار أوفر لهم ومتى يكون الشراء أفضل.
- إذا كان العميل متردداً أو يرى السعر مرتفعاً، شجعه بخيار الاستئجار أو قدم خصماً تحفيزياً (حتى 10-15%) لإتمام وإغلاق الصفقة اليوم، وحثه على تعبئة رابط نموذج الانضمام: ${formUrl}.
- إذا أبدى العميل موافقة أو إيجابية، أعلن إغلاق الصفقة (Closed Deal) وحدد هل هي صفقة بيع أم استئجار مع خطوات البدء وتعبئة النموذج.

يجب أن تعيد النتيجة بصيغة JSON حصراً وفق النموذج التالي:
{
  "replyMessage": "نص الرد الذي سيتم إرساله للعميل عبر الواتساب بتنسيق جميل واحترافي ويحمل توقيع ممثل الوكالة ورقم الواتس ${myWhatsapp}",
  "dealStage": "pricing_offered" | "negotiating" | "closed_sale" | "closed_lease" | "pending_form",
  "dealType": "sale" | "lease" | "both" | "pending",
  "quotedAmount": number,
  "dealSummary": "ملخص باللغة العربية لما تم التوصل إليه في هذه المرحلة من التفاوض والخطوة التالية",
  "recommendedAction": "توصية سريعة لصاحب الوكالة (مثال: إرسال رابط النموذج فوراً، ترتيب اتصال لتوقيع العقد، إلخ)"
}`;

    const contents = [
      ...conversationHistory.map((m: any) => ({
        role: m.sender === 'me' || m.sender === 'ai' ? 'model' : 'user',
        parts: [{ text: m.text }],
      })),
      {
        role: 'user',
        parts: [
          {
            text: `رسالة واردة من (${lead?.name || 'العميل'}):
"${incomingMessage || 'مرحباً، وصلتنا رسالتكم الإعلانية ونود معرفة الأسعار وتفاصيل الانضمام وما إذا كان متاحاً بنظام البيع أو الاستئجار؟'}"

تفاوض معه واطرح خيارات الأسعار (بيع واستئجار) مع حثه على رابط النموذج ${formUrl} لإتمام البيع أو الاستئجار، وأعد النتيجة بصيغة JSON المطلوبة.`,
          },
        ],
      },
    ];

    const ai = getAI();
    const result = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: contents as any,
      config: {
        systemInstruction: systemPrompt,
        temperature: 0.4,
        responseMimeType: 'application/json',
      },
    });

    const parsed = JSON.parse(result.text || '{}');
    res.json({
      success: true,
      data: parsed,
    });
  } catch (error: any) {
    console.error('Negotiation error:', error);
    res.status(500).json({
      success: false,
      error: error.message || 'فشلت عملية التفاوض وطرح الأسعار',
    });
  }
});

// Autonomous Executive Closing & Progress Report Generation
app.post('/api/agency/generate-executive-report', async (req, res) => {
  try {
    const {
      leads = [],
      campaignLogs = [],
      agencyProfile,
      pricingConfig,
    } = req.body;

    const myWhatsapp = agencyProfile?.myWhatsapp || '00667737219181';
    const agencyName = agencyProfile?.agencyName || 'وكالتنا للحلول الرقمية';
    const formUrl = agencyProfile?.agencyFormUrl || 'https://myagency.com/join';
    const adAnnouncement = agencyProfile?.agencyAdAnnouncement || agencyProfile?.customAdCopy || '';

    // Synthesize quick numbers
    const totalLeads = leads.length;
    const schoolsCount = leads.filter((l: any) => l.category === 'school').length;
    const companiesCount = leads.filter((l: any) => l.category === 'company').length;
    const contactedLeads = leads.filter((l: any) => l.status === 'contacted' || l.status === 'replied' || l.status === 'converted').length;
    const repliedLeads = leads.filter((l: any) => l.status === 'replied' || l.status === 'converted' || l.replyText).length;
    const closedSaleDeals = leads.filter((l: any) => l.dealStage === 'closed_sale' || (l.dealType === 'sale' && l.status === 'converted')).length;
    const closedLeaseDeals = leads.filter((l: any) => l.dealStage === 'closed_lease' || (l.dealType === 'lease' && l.status === 'converted')).length;
    const negotiatingLeads = leads.filter((l: any) => l.dealStage === 'negotiating' || l.dealStage === 'pricing_offered').length;

    const totalRevenue = leads.reduce((acc: number, l: any) => {
      if (l.dealAmount && (l.dealStage === 'closed_sale' || l.dealStage === 'closed_lease' || l.status === 'converted')) {
        return acc + Number(l.dealAmount);
      }
      return acc;
    }, 0);

    const prompt = `أنت وكيل الذكاء الاصطناعي والمستشار التنفيذي للمبيعات (Executive AI Sales & Operations Agent).
المطلوب: إعداد تقرير شامل، مفصل، ودقيق جداً لتقديمه لصاحب الوكالة تحت عنوان:
"تقرير وكيل المبيعات والعمليات التنفيذي: ما تم إنجازه، وما حصل من تواصل وتفاوض، وعمليات البيع والاستئجار المبرمة".

بيانات الوكالة وصاحب العمل:
- اسم الوكالة: ${agencyName}
- رقم الواتساب المعتمد: ${myWhatsapp}
- رابط نموذج الانضمام المنشور: ${formUrl}
- نص رسالة الإعلان المنشورة: """${adAnnouncement.slice(0, 500)}..."""
- أسعار البيع المعتمدة: ${pricingConfig?.salePrice || 15000} ${pricingConfig?.currency || 'ريال'} (بيع كامل)
- أسعار الاستئجار المعتمدة: ${pricingConfig?.leasePriceMonthly || 1200} ريال/شهر، أو ${pricingConfig?.leasePriceAnnual || 10800} ريال/سنة

إحصائيات العمل الميدانية الفعلية:
- إجمالي قاعدة البيانات: ${totalLeads} جهة (${schoolsCount} مدارس أهلية، ${companiesCount} شركات عالمية).
- جهات تم إرسال الإعلان ورابط النموذج إليها: ${contactedLeads} جهة.
- الردود والاستفسارات الواردة: ${repliedLeads} جهة.
- عدد جولات التفاوض وعروض الأسعار الجارية: ${negotiatingLeads} جهة.
- صفقات البيع الكامل المغلقة والمؤكدة: ${closedSaleDeals} صفقة.
- صفقات الاستئجار والاشتراكات المغلقة: ${closedLeaseDeals} صفقة.
- إجمالي العوائد المالية المتوقعة والمحققة: ${totalRevenue > 0 ? totalRevenue.toLocaleString() : (closedSaleDeals * 15000 + closedLeaseDeals * 10800).toLocaleString()} ${pricingConfig?.currency || 'ريال'}.

عينة من الجهات المسجلة وتفاصيل التفاعل معها:
${JSON.stringify(
  leads.slice(0, 10).map((l: any) => ({
    name: l.name,
    category: l.categoryLabel || l.category,
    city: l.city,
    status: l.status,
    replyText: l.replyText || 'لا يوجد رد بعد',
    dealStage: l.dealStage || 'جديد',
    dealType: l.dealType,
    dealAmount: l.dealAmount,
    dealNotes: l.dealNotes,
  })),
  null,
  2
)}

يرجى كتابة التقرير باللغة العربية الفصحى الراقية والمهنية مقسماً إلى الأقسام التالية:
1. **المقدمة والملخص التنفيذي (Executive Summary)**: إيجاز واضح عن ما تم وما حصل، والنتيجة الإجمالية للحملة.
2. **عمليات الإرسال ونشر الإعلان ورابط الانضمام**: تفاصيل إرسال الرسالة الإعلانية ورابط الاستمارة للمدارس والشركات ومعدلات الوصول.
3. **تفاعل المدارس والشركات والردود الواردة**: تحليل نوعية الاستفسارات واهتمامات كل قطاع.
4. **جولات التفاوض وطرح الأسعار (البيع vs الاستئجار)**: كيف تم طرح باقات البيع الكامل وباقات الاستئجار الشهري/السنوي، وكيف تعامل الوكيل مع ميزانيات الجهات المختلفة.
5. **سجل الصفقات المنجزة والمغلقة (Deals Closed)**: تفصيل عمليات البيع والاستئجار التي تمت والمبالغ المحققة.
6. **التوصيات التنفيذية والخطوات القادمة (Next Actions)**: خطوات عملية لمتابعة بقية المهتمين وتعميد العقود عبر الواتساب ${myWhatsapp}.

اجعل التقرير منسقاً بعناية مع استخدام نقاط وجداول Markdown واضحة ومقنعة.`;

    const ai = getAI();
    const result = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        temperature: 0.3,
      },
    });

    res.json({
      success: true,
      reportMarkdown: result.text || '',
      metrics: {
        totalLeads,
        schoolsCount,
        companiesCount,
        contactedLeads,
        repliedLeads,
        negotiatingLeads,
        closedSaleDeals,
        closedLeaseDeals,
        totalRevenue: totalRevenue > 0 ? totalRevenue : closedSaleDeals * (pricingConfig?.salePrice || 15000) + closedLeaseDeals * (pricingConfig?.leasePriceAnnual || 10800),
      },
    });
  } catch (error: any) {
    console.error('Executive report generation error:', error);
    res.status(500).json({
      success: false,
      error: error.message || 'فشل توليد التقرير التنفيذي',
    });
  }
});

// Setup Vite middleware for development & static for production
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on port ${PORT}`);
  });
}

startServer();
